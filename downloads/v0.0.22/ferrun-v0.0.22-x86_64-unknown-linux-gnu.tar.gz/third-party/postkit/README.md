<!--
Copyright (c) 2026 Ferrun contributors. All rights reserved.

Responsibility: Record the provenance of the bundled Postkit SQL.
Connections: The adapter installs this pinned source and checks its digest.
-->

# Postkit authz source

Source: https://github.com/varunchopra/postkit

Revision: `4aec865d7ce53bc84acbd6394edaabd3b8d3f31a` (`v0.12.1`).

`authz.sql` concatenates the upstream schema, function and trigger SQL files,
in filename order within each group. It excludes the distribution's outer
transaction so installation can share the host's migration transaction.
SQL bodies are unchanged. The adjacent `LICENSE` retains the upstream licence.
