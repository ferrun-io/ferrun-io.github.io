<!--
Copyright (c) 2026 Ferrun contributors. All rights reserved.

Responsibility: Explain how to configure repeatable project qualification and CI
commands.
Connections: Connects maintained Make targets to GitHub workflows and the
qualification evidence contract.
-->

# Prepare private GitHub qualification credentials

This guide is for Ferrun maintainers or companies running compatibility qualification. Employees only need [executor setup](company-setup.md#connect-a-machine). The unprivileged native build workflow runs without these credentials. **Ferrun qualification** uses this protected environment; release claims must match the targets that passed.

## 1. Create the dedicated canary repository

On GitHub, use **+ → New repository**, select the intended company or personal owner, give the test repository a name, and choose **Private**. Create an initial README so there is a default branch. Click **Create repository**. Use a dedicated repository for qualification fixtures; automation will need to write and dispatch test workflows there.

Record `OWNER/REPO`. The canary repository is separate from Ferrun's source and CI repository.

## 2. Create and install the CI App

Follow [GitHub App setup](github-app-setup.md) under the owner of the canary repository. Choose a distinct name such as `Ferrun CI Acme`, disable webhooks, and leave user OAuth and device flow disabled.

Set these **Repository permissions** before choosing **Create GitHub App**:

| Permission     | Access         | Why qualification needs it                                                                    |
| -------------- | -------------- | --------------------------------------------------------------------------------------------- |
| Administration | Read and write | Register the candidate's repository runners.                                                  |
| Actions        | Read and write | Dispatch fixture workflows and read their jobs and logs.                                      |
| Checks         | Read-only      | Verify GitHub's stored check runs and annotations independently of Ferrun's own event stream. |
| Contents       | Read and write | Commit the exact fixture revision used by the qualification suite.                            |
| Workflows      | Read and write | Write the test workflow files under `.github/workflows`.                                      |
| Metadata       | Read-only      | GitHub's required baseline repository metadata access.                                        |

Open **Install App → Install** for the intended owner. Select **Only select repositories**, choose the dedicated private canary, and click **Install**. Do not include customer repositories or the Ferrun source repository unless they are themselves the explicitly designated canary.

Record the **App ID** from the App's **General** page and the installation ID from the installation settings URL: the number after `/installations/`. This ID differs from the App ID and OAuth client ID.

For an App that is already installed, open **Developer settings → GitHub Apps → Edit → Permissions & events**, change the required permission, and choose **Save changes**. Open the installation's **Configure** page and choose **Review request → Accept new permissions**. Confirm the review lists only your intended addition; for annotation verification this is **Checks: Read-only**. Saving the App form alone does not grant the existing installation its new permission. Keep **Only select repositories** and the dedicated canary selection intact.

## 3. Restrict the source repository's CI environment

In the repository containing Ferrun's workflows, open **Settings → Environments → New environment**, enter `ferrun-canary`, and choose **Configure environment**.

This requires repository administration. For private repositories, GitHub also requires a plan supporting environments, such as Pro or Team; if **Environments** is absent, check the [feature's availability](https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments) before proceeding.

Under **Deployment branches and tags**, choose **Selected branches and tags**. Use **Add deployment branch or tag rule**, select **Branch**, enter `main`, and save the rule. The hosted qualification workflow also checks for this exact branch. Remove obsolete development-branch rules and avoid wildcard branch names.

This environment holds the App key. The manual native-build workflow must not reference it, and the privileged workflow also enforces its event and ref. A branch rule alone does not make arbitrary workflow code safe to execute with that key.

## 4. Save the new key and identifiers

Return to **Developer settings → GitHub Apps → your App → General → Private keys**. Click **Generate a private key**. GitHub downloads a PEM. Keep it in the maintainer's approved secret store; do not put it in the repository or a build artifact.

Back in the source repository's `ferrun-canary` environment, use **Environment secrets → Add environment secret**. Enter `FERRUN_GITHUB_APP_PRIVATE_KEY` as the name, paste the entire PEM including its BEGIN/END lines into **Value**, and choose **Add secret**. GitHub may require **Confirm access** first; complete that verification in GitHub. Do not screenshot or log the populated secret input.

Under **Environment variables → Add environment variable**, add each nonsecret value:

| Name                                | Value                                                       |
| ----------------------------------- | ----------------------------------------------------------- |
| `FERRUN_GITHUB_APP_ID`              | Numeric App ID from **General**.                            |
| `FERRUN_GITHUB_APP_INSTALLATION_ID` | Numeric installation ID for the selected canary repository. |
| `FERRUN_CANARY_REPO`                | The dedicated canary's `OWNER/REPO`.                        |

Confirm the secret's **name** and the variable values in the environment listing. GitHub does not reveal a stored secret again. No personal access token, `gh auth token` export, or employee repository-admin credential is needed.

## 5. Run qualification and inspect the result

The App's installation settings should show only the canary repository. The source environment should show one App-key secret, the three variables above, and only `main`. **Ferrun validation** runs native builds and tests without access to this environment. All workflows are manually started; pushes, pull requests, and commit-message markers do not launch them.

Once the workflow is on the source repository's default branch, open **Actions → Ferrun qualification → Run workflow**, select `main` and the platform group, then click **Run workflow**. The [workflow](../.github/workflows/qualification.yml) defines the available targets.

For local checks, use `make test`; `make test-unit` omits database integration and
mutation checks. Use `make test-devtools` for the build, release, and setup tools;
the shared CI job calls the same checks once. The commands prepare pinned dependencies before execution and
select the compiler output and package caches through `bootstrap.sh`. Internal
environment-variable prefixes are unnecessary. Ordinary checkouts and worktrees
share compiler output under the repository's `.cache/build`; CI keeps it under
the worker's persistent tool cache.

Configure an external test database once through `ADMISSION_DATABASE_URL` in the
repository's `.cache/dev/settings.json`, or let `make test` create a disposable
PostgreSQL container through Docker. Worktrees read the same saved setting. The
runtime `DATABASE_URL` is never substituted for a test database. Local service
tests need permission to open sockets; dependency preparation needs network
access when pinned downloads are missing.

The manual [Ferrun validation workflow](../.github/workflows/ci.yml) runs shared
checks on `ferrun-linux-x64`, then platform checks on the Ferrun labels in its
matrix. Those workers must be enrolled and connected to the source repository
before dispatch. The matrix configures routing; successful jobs and live
comparison evidence establish execution.

`make build` dispatches that workflow for all configured platforms and waits for
the returned GitHub run ID. The checkout must be clean and its branch pushed.
Use `make build-linux-x64`, `make build-linux-arm64`, `make build-macos-arm64`, or
`make build-windows-arm64` to select one platform. GitHub retains each job's logs
and artifacts. These builds do not publish a release or update production.

Open the run. **Prepare qualification fixtures** verifies the installation and commits changed fixtures to the private canary's default branch. **Live checks** compares each selected native package with an official runner. Shared checks run database and mutation tests before qualification; each live job owns its controller and database fixtures.

For a successful target, open **Summary → Artifacts → qualified-RUNNER** for its qualification result and **native-RUNNER** for its package and reports. Private keys, executor state and service logs are excluded. Every claimed target must pass. Qualification does not change repository visibility or publish a release.

If the token action reports insufficient permission, verify both the App's permission selection and the installation's **Review request** approval described above. If it reports the wrong installation, check the recorded installation ID and canary owner. A failing gate remains a failing run; rerunning it does not turn an earlier candidate's evidence into proof for different bytes.

For GitHub UI changes, see [environment configuration](https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments) and [App installation](https://docs.github.com/en/apps/using-github-apps/installing-your-own-github-app).

## Evidence fields

These tables explain generated JSON fields. CI copies only completed evidence; downloaded verdict paths are relative to that verdict. A local verifier may retain absolute paths into its private working directory.

| `verdict.json` pointer       | Meaning                                                                                                            |
| ---------------------------- | ------------------------------------------------------------------------------------------------------------------ |
| `/target`                    | Native Rust host triple actually used to execute this archive.                                                     |
| `/reference_runner`          | Reference OS/architecture label used for the independent comparison.                                               |
| `/artifact_sha256`           | Digest of the exact compressed archive, including its guides and notices.                                          |
| `/cases`                     | Case names actually requested from the trusted suite.                                                              |
| `/live_qualification_passed` | True only for the complete required case inventory after validation and cleanup.                                   |
| `/evidence_directory`        | Location of independent per-run JSON observations; `observations` in downloaded CI evidence.                       |
| `/suite_sha256`              | Identity of the source, fixtures, assertions, dependency pins, and CI definition that produced this qualification. |
| `/workflow_sha`              | Immutable canary commit verified before dispatch and in each resulting GitHub run.                                 |
| `/mutation_evidence`         | Location of the separate regression-sensitivity proof; `mutations.json` in CI evidence.                            |

`mutations.json` records `/suite_sha256`, `/baseline_passed`, every required
regression under `/mutations`, `/complete`, and `/verified_at`. A `killed` result
means the deliberately faulty implementation failed its actual regression
assertion; compilation errors do not count. The timestamp is diagnostic, while
the source and artifact digests establish identity.

Each observation records its `/repository`, `/run_id`, `/url`, `/job_id`, `/case`, `/conclusion`, and actual `/step_results`; `/runner_kind` distinguishes candidate from reference. Its `/workflow_sha`, `/suite_sha256`, and `/artifact_sha256` bind it to the verdict. `/observations` contains case-specific facts compared between backends; `/reporting_evidence` holds nonsecret receipts described in the [reporting contract](reporting.md). `/claims` retains explicit limits on final logs, summary readback, and live visibility; `/verified_at` records observation time. Additional reference metadata describes the actual official runner from its logs and does not replace native candidate evidence.
