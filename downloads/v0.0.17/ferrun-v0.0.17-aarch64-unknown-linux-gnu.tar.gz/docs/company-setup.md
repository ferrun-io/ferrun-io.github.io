<!--
Copyright (c) 2026 Ferrun contributors. All rights reserved.

Responsibility: Explain company control-plane setup, machine enrollment, and
repository connections.
Connections: Follows the ferrun launcher and actual controller management and
browser routes.
-->

# Run a Ferrun control plane and connect machines

A control plane manages machines and reports their GitHub jobs. A pool groups
machines with shared workflow labels and an enrollment limit. A connection gives
a pool access to a GitHub repository or organization. One pool can serve several
connections, and each machine runs one job at a time across them.

You can set up the controller and machines before connecting GitHub. Self-hosted
installations use their own GitHub App. Its key stays on the controller; machines
receive only Ferrun enrollment and work credentials.

## Prepare the controller

[Download and verify a bundle](install.md) for the controller's operating system
and architecture. Supply a dedicated PostgreSQL 14 or newer database through `DATABASE_URL`,
or let the launcher manage PostgreSQL through an installed Docker service. The
[native Linux service installer](cloud-deployment.md) uses an existing database
and requires no Docker.

Run these commands from the extracted bundle:

```sh
# Create the controller and a pool admitting up to ten machines.
./ferrun setup --mode server --capacity 10
./ferrun run
```

In PowerShell, use `.\ferrun.exe`. Source builds also need `--runner-version
VERSION` when connecting GitHub; obtain it from the maintained compatibility
configuration. Release bundles supply their selection in `manifest.json`.

Open the localhost URL printed by the launcher. Sign in with `management_token`
from `settings.json` in the installation's state directory. Setup prints that
directory. Direct controller deployments use `CONTROL_PLANE_TOKEN`.

For remote access, provide HTTPS through your proxy and set the controller's
browser configuration:

```sh
# Use the public address and the actual proxy peers for this installation.
export CONTROL_PLANE_WEB_URL=https://console.example/
export CONTROL_PLANE_TRUSTED_PROXIES=127.0.0.1,::1
```

The proxy must preserve Host and Origin and overwrite `X-Forwarded-Proto` with
the client scheme. It must also overwrite `X-Forwarded-For` with one client IP.
Keep the backend listener private. For a URL prefix, include it in the public
URL and have the proxy strip it before forwarding.

Set `CONTROL_PLANE_DOWNLOAD_URL` to the page from which your users should obtain
worker bundles. These URLs are installation settings, not account names built
into Ferrun.

## Connect a machine

Choose the execution account and a persistent, private state directory before
enrollment. Run setup and the worker as that same account. A service, VM, or
container must retain that directory across restarts; a checkout or disposable
build cache is not suitable. Prepare VM images before enrollment and enroll each
clone separately so machines do not share an identity.

Open **Add machine**, choose its pool, and select **Generate setup command**.
Download the matching worker bundle, then use **Copy command** for Linux/macOS
or Windows PowerShell. Run it on the machine you want to connect.

The command supplies a one-use enrollment token valid for 24 hours. It uses the
machine's hostname as its display name. Setup starts the runner service and
configures startup after reboot. Repeating setup retains its machine identity.

For provisioning scripts, the operator supplies `FERRUN_ENROLLMENT_TOKEN`, the
server URL, and the pool ID:

```sh
# Enrollment uses the token supplied in the environment.
./ferrun setup --server SERVER_URL --pool POOL_ID --name MACHINE_NAME
unset FERRUN_ENROLLMENT_TOKEN
```

Use `.\ferrun.exe` in PowerShell and `Remove-Item Env:FERRUN_ENROLLMENT_TOKEN` to
remove the bootstrap token from that shell. Machines need outbound HTTPS to the
controller and no inbound job-delivery port.

Install the tools your workflows need. Checkout needs Git; JavaScript actions
need their declared Node runtime. `EXECUTOR_NODE24` and `EXECUTOR_NODE20` can
select those executables. Ferrun does not install an operating system or its
workflow dependencies when you assign labels. See [runtime support](runtime.md).

Workflows can install their own dependencies using setup actions and commands.
The execution account must have the permissions those commands require. Neither
enrollment nor a pool label grants host permissions; configure them through your
host's administration tools as described in [worker permissions](#worker-permissions).

### Worker permissions

Ferrun runs jobs with the execution account's permissions. It does not impose a
command or package allowlist. Configure those permissions once when preparing
the worker host; keep dependency installation in the workflow.

For a trusted Linux build worker that needs administrative setup, use
`sudo visudo -f /etc/sudoers.d/ferrun-runner` to configure passwordless sudo:

```sudoers
ferrun-runner ALL=(root) NOPASSWD: ALL
```

Replace `ferrun-runner` with your execution account. This grants workflows root
access to the worker host. Use it only where that access is intended, such as a
dedicated trusted build machine or disposable VM.

Customers who want a command whitelist can replace `ALL` after `NOPASSWD:` with
their allowed absolute command paths and arguments in this same file. That is
an optional host policy; workflows needing other commands will require a policy
change. Workers that need no privileged commands require no sudo grant.

For a local Docker daemon that uses the `docker` group, grant access with:

```sh
sudo usermod --append --groups docker ferrun-runner
```

Restart the worker session or service after changing its groups. Docker daemon
access gives jobs root-equivalent authority on that host. If you use rootless or
remote Docker, configure access to that daemon instead. The worker's supervisor
must also permit the selected permissions; see below.

## Start a worker under a supervisor

Run setup as the account that will execute jobs. Normal worker setup installs
and starts a native service, requesting administrator authorisation when needed.
That authorisation does not change the worker's execution account. Windows also
needs that account's service-logon password; automation can supply it on standard
input. Ferrun passes it to Windows without saving it in its settings.

Use the same CLI on Linux, macOS and Windows:

```sh
ferrun service status
ferrun service stop
ferrun service start
```

Add `--state-dir` for a custom installation. Stop prevents new execution, waits
for current jobs and native cleanup, and retains results awaiting delivery.
Start reuses that identity and enables boot startup. Service status describes
the local process; `ferrun status` describes its controller connection.

The native managers are systemd on Linux, launchd on macOS and Windows SCM.
On Linux, keep administrator policy in systemd drop-ins, which setup retains.
Controller installations on the same host remain independent.

For containers, Linux without systemd or an existing supervisor, use
`ferrun setup --supervisor external` with the normal enrollment arguments. Then
configure that supervisor to run `ferrun run` with the same account and persistent
state. This avoids installing a second supervisor. Unix termination signals and
Windows console stop signals request orderly shutdown; the surrounding platform
controls its final termination deadline.

Ferrun runs inside the environment you supply. Your infrastructure owns the VM,
host or container and its reboot policy. A suspended environment cannot execute
jobs; Ferrun reconnects and recovers saved results when it returns.

Worker permissions follow the workflows you intend to run. Do not copy the
control-plane daemon's restrictions onto a worker that needs package installation.
For example, `NoNewPrivileges=true` blocks `sudo` even when sudoers permits the
command, and `ProtectSystem=strict` prevents writes outside explicitly allowed
paths. A container or other supervisor can impose equivalent restrictions.
Keep such restrictions when they match the workload; otherwise use a worker
execution policy that permits the declared setup. Ferrun does not bypass it.

### Existing Linux worker installations

Keep the existing execution account, state and journals. After an explicit
`ferrun update`, run `ferrun service start --state-dir STATE_DIRECTORY` as that
account to adopt its worker unit. The CLI preserves systemd drop-ins and the
private `worker.env` file. The old bundle's `worker-service` entry point delegates
to this command; a separate Python worker-service implementation is no longer
required. No service command grants workflow sudo or Docker permissions.

## Connect GitHub

Follow the [GitHub App setup guide](github-app-setup.md). Repository connections
need Administration read/write permission. Organization connections need
organization Self-hosted runners read/write permission and use GitHub's default
runner group. Configure that group's repository-access policy in GitHub.

Stop the controller before adding the App credentials:

```sh
# Keep the existing database, pools, and machine identities.
./ferrun setup --state-dir STATE_DIRECTORY --app-id APP_ID --app-key APP_KEY_FILE
./ferrun run --state-dir STATE_DIRECTORY
```

Open **Connections → New connection**. Follow the link to approve access for your
configured App on GitHub. Return to Ferrun, enter the repository or organization,
select its machine pool, and choose **Check access and connect**. A failed access
check saves no connection. The controller reads the App's current name and
installation link from GitHub, so renaming or transferring that App needs no
code change.

Explicit setup can update the App ID, key path, or compatibility version.
Rotating the key file at its configured path does not require reenrolling
machines. Keep the App key, management token, and database credentials on the
controller.

### Manage connections and pools from the CLI

Management commands use `ferrun <resource> <action>`. Use `--help` at either
level to see the available commands and arguments. The CLI checks the controller's
read-only compatibility endpoint before selecting `/api/v2` or `/api/v1`.
Older controllers support their existing connection, binding, and machine
operations. Pool listing, connection lookup by ID, and listing a pool's
connections require the newer endpoints. A full 100-record list from a v1
controller fails explicitly because that API cannot return subsequent pages.

For a remote controller, configure the connection once:

```sh
./ferrun auth login --server https://CONTROLLER
```

Enter the management token at the hidden prompt, or pipe it from your secret
manager on standard input. Login verifies the token before saving one active
connection in Ferrun's private user-state directory, outside source checkouts.
Subsequent management commands reuse it from any directory. `auth status`
verifies the saved connection without displaying its token. `auth logout`
removes that local credential; it does not revoke the server token or alter an
enrolled worker's settings. A failed login preserves the previous connection.

Automation can still supply `CONTROL_PLANE_WEB_URL` and `CONTROL_PLANE_TOKEN`
together, or use `--server URL` with `CONTROL_PLANE_TOKEN`. These values override
the saved connection for that command without changing it. An explicit server
without a token can reuse the saved credential only when the full URL matches.
The CLI never combines a token-only environment override with a saved endpoint.
On the controller host, `--state-dir STATE_DIRECTORY` selects its local endpoint
and management credential independently of remote settings. Employee state has
no management authority.

```sh
./ferrun connection list
./ferrun connection create OWNER/REPO
./ferrun connection get CONNECTION_ID
./ferrun pool list
./ferrun pool get POOL_ID
./ferrun pool bind POOL_ID --connection CONNECTION_ID
./ferrun connection list --pool POOL_ID
./ferrun machine list --pool POOL_ID
./ferrun machine get MACHINE_ID
```

Connection creation checks access using the server's GitHub App. It cannot
grant the App access to a repository; approve that access in GitHub first.
For an organization connection, use `connection create OWNER --scope organization`.

`pool bind` allows an existing pool to serve another connection without
reenrolling its machines. `pool unbind POOL_ID --connection CONNECTION_ID`
stops new work from that connection and retains job history. Inspect bindings
with `connection list --pool POOL_ID`.

To create a pool, use `pool create NAME --label LABEL --capacity NUMBER`.
Repeat `--label` for additional workflow labels. Capacity defaults to one and
accepts values from 1 to 100. Creation returns a private enrollment token;
keep that output in your provisioning or secret-management system.

The control panel's **Pools → Create pool** form uses the same operation. Change
the machine limit on a pool's page, or run
`ferrun pool update POOL_ID --capacity NUMBER`. A lower limit must still cover
every enrolled machine, including machines awaiting removal. Changing the limit
does not stop jobs, rotate credentials or provision hardware.

Management commands return JSON, including `null` after a successful bind or
unbind. List commands retrieve every page before printing their result; a
failed page returns a failing exit code without partial output. `ferrun status`
continues to inspect the local enrolled machine using its saved credentials.

Ferrun registers `ferrun`, `self-hosted`, and each machine's OS and architecture
as GitHub labels. Pool labels add custom selectors. For Linux x64 jobs, use:

```yaml
runs-on: [ferrun, linux, x64]
```

A pool can contain several platforms; GitHub selects an individual machine
whose labels match the workflow. Already acquired jobs wait for that machine's
one shared slot and keep renewing their GitHub leases.

## Verify a workflow

Create `.github/workflows/ferrun-check.yml` in an authorized repository:

```yaml
name: Ferrun check
on: workflow_dispatch
jobs:
  check:
    runs-on: ferrun
    steps:
      - run: echo "hello from Ferrun"
```

Commit it through the repository's normal review process. In GitHub, open
**Actions → Ferrun check → Run workflow** and select the branch. Verify that the
job finishes successfully and its log contains `hello from Ferrun`. The manual
dispatch button needs the workflow on the default branch and an account with
workflow access. The worker itself needs no dispatch credential.

This small check proves job delivery and reporting, not build readiness. Before
using the worker for releases, run the intended workflow through its actual
supervisor. Its dependency setup, compiler invocations, and any Docker operations
must succeed under that account. Verify that the worker returns to idle and can
run the next job; an interactive administrator session is not equivalent evidence.

For an existing workflow, change `runs-on` to labels matching the intended
machines. Its actions and build tools must support those machines. Inspect the
job's actual log before changing dependencies; a successful enrollment does not
establish that the workflow can run there.

## Use the control panel

Overview shows connections, pool machine counts, runners, and unfinished jobs.
It reloads every 30 seconds. **Pause updates** stops automatic reloads; **Refresh**
loads current data. Heartbeats show elapsed time, with the exact UTC timestamp
in their tooltip.

Names open their detail pages. Connection pages show assigned pools and recent
jobs. **Job history** lists completed jobs across repositories, supports a
repository filter, and links to GitHub's workflow logs. Removing a machine keeps
its history.

A wrong management token blocks further logins from that client IP until the
controller restarts. Blocks stay in memory and do not expire. Sessions last
eight hours and end on sign-out or controller restart. Cookies contain opaque
session credentials, not the management token.

## Pause or remove a machine

Use its page to pause new jobs, resume them, or request removal. Assigned work
and reporting must finish before removal. The same operations are available
from the connected machine:

```sh
./ferrun status
./ferrun drain
./ferrun resume
```

To disconnect, drain the machine, wait for its job to finish reporting, stop
`ferrun run`, and run `ferrun leave`. Repeat `--state-dir` if setup used one.
If removal is still pending, retry `leave`; the controller keeps retrying GitHub
cleanup. Job workspaces and encrypted journals remain for investigation.

## Use the management API

`/openapi.json` documents the authenticated API under `/api/v2`. Create pools
with `POST /api/v2/pools`. Bind a connection with
`PUT /api/v2/pools/{pool}/connections/{connection}`; delete that binding to stop
new work without deleting history.

Use `POST /api/v2/pools/{id}/enrollment-token` to replace a pool's shared token,
or DELETE on the same path to disable new joins. These operations preserve
credentials already issued to machines. One-use setup commands are issued
through `POST /api/v2/pools/{id}/join-token`.

## Keep restart state

Default state locations are:

| Host    | Location                                             |
| ------- | ---------------------------------------------------- |
| Linux   | `$XDG_STATE_HOME/ferrun`, or `~/.local/state/ferrun` |
| macOS   | `~/Library/Application Support/Ferrun`               |
| Windows | `%LOCALAPPDATA%\Ferrun`                              |

Use `--state-dir` to choose another private directory. Keep the database's
encryption key with its backup and preserve worker credentials and journal
keys. [State and recovery](native-state.md) describes those records and the
explicit database upgrade.

For failures, check the controller's `control-plane.log` and the machine's
`executor.log`. Confirm App access, the selected pool, its capacity, and the
worker's HTTPS connection. A GitHub job also depends on that machine's tools;
inspect its workflow log before changing the host.
