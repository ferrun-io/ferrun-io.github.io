<!--
Copyright (c) 2026 Ferrun contributors. All rights reserved.

Responsibility: Define admitted event ordering and delivery of logs, diagnostics,
and results.
Connections: Connects executor journals to controller projections, reporting
workers, and GitHub service requests.
-->

# Execution reporting and reference parity

The target is GitHub's API. The pinned source reference is [`actions/runner@759385a`](https://github.com/actions/runner/tree/759385a3510197a58b5c08dc1f373b74b9f4643b). Source-derived behavior is tested locally before qualification compares the same immutable workflow revision on our executor and a GitHub-hosted runner. A local protocol receiver is not independent evidence of GitHub behavior.

## Ownership and durable data

The executor captures RFC3339 UTC timestamps when it receives stdout/stderr, before buffering or network delivery. One runtime interprets workflow commands, applies masks, and assigns each logical log a UUID. It renders groups and diagnostics once. Transport fragments carry that same record identity and timestamp; splitting inserts no newlines.

Pipe reads use bounded 16 KiB chunks, with separate 1 MiB budgets for read buffers and record metadata. Short records share encrypted files in groups of at most 128; each record keeps its own authenticated frames and byte range. Incomplete records spool under the attempt and machine storage budgets. Decoding replaces invalid UTF-8 while retaining subsequent valid output. Masking streams across chunks. Workflow commands and matcher input have a 64 KiB interpretation limit; exceeding it fails the step visibly. A failed invocation is terminated and its native membership and capture closure are verified before another step runs. Earlier job-scoped services retain their own process domains.

`Agent::emit_at` appends encrypted records to the executor's current attempt journal and returns after local durability. Its independent sender drains available records into batches of at most 100 events and 1 MiB of serialized JSON, including escaping and envelope overhead. It sends available output immediately without waiting to fill a batch. Each request has a five-second timeout and one-second transient retry interval; retries reuse the exact serialized batch. HTTP acknowledgment is awaited outside process supervision. A complete invalid receipt or permanent admission rejection stops delivery visibly; interrupted successful response bodies retry the unchanged batch without advancing acknowledgment. Executor restart replays pending events before polling for work, never reruns an uncertain started command, and preserves original capture times. Reserved control banks retain receipts and compact acknowledged state; bulk segments are reclaimed only after durable admission acknowledgement. The lost-receipt tests cover both a torn journal suffix and whole-batch replay after restart.

The controller's `api::event` authenticates the executor once, locks one job row, and validates every event in batch order. New events require that job to hold the machine's shared execution slot. Exact admitted retries remain valid after the slot moves to another job. It verifies owner/epoch/sequence and each event's keyed duplicate-request digest, applies masking revisions and projection changes, and commits the entire batch in one transaction. An invalid tail rolls back all new events, mask registrations, line numbering and lifecycle changes. Exact retries have no second effect; a duplicate prefix can precede a new valid suffix. A summary completion can validate chunks inserted earlier in the same transaction. Dynamic mask values enter only the encrypted envelope; the persisted event is redacted. Admission never contacts GitHub.

Database round trips are bounded per batch: one lookup loads the submitted duplicate prefix's MACs, one optional read loads only chunks for summaries being completed, and one bulk insert persists the validated new suffix. Per-event ownership, masking, projection, and MAC checks still run in order in memory. In-batch summary chunks join committed history for independent content verification before insertion. Exact replay performs no event or projection writes. This avoids repeatedly exceeding the sender's five-second deadline when PostgreSQL is hosted remotely. The database regression delays actual PostgreSQL query-completion responses by 60 ms and requires a singleton, a full new batch, an exact replay, a mixed prefix/suffix, and full batches of summary chunks/completions to meet the unchanged sender deadline with bounded database round trips.

`POST /api/v2/executors/{id}/events` accepts an `ExecutorEventBatch` object.
`/events` contains 1–100 consecutive `ExecutorEvent` envelopes for one job and
epoch; `/events/N` has the fields described below for each event. Empty batches,
mixed attempts and internal sequence gaps are rejected. The existing 1 MiB
request-body limit applies to the complete encoded object. `/accepted_sequence`
acknowledges the complete submitted batch only after commit. The sender persists
acknowledgement through its submitted final sequence and retains later records
for delivery. Before retiring a job's journal, the sender must deliver all its
events. It makes one request per batch instead of one per event.

Preserve the storage and protocol contracts of every active version. Optional
recovery observations extend polling without changing event identities or journal
records. Older peers may omit those observations. An upgrade that cannot read
saved records must stop without deleting them; matching package versions or fresh
state cannot substitute for a supported conversion.

Workers keep running their current jobs during a controller outage. Only native
cleanup evidence can establish that execution stopped. A lost admission receipt
replays the same events, while an uncertain provider completion remains recorded
without blindly repeating its external effect. The provider's final outcome,
executor outcome and reporting confirmation remain separate facts.

| Persisted field                                         | Current meaning                                                                                                                                              |
| ------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `job_events.event.observation`                          | Current `ExecutorEvent`: attempt identity, sequence, original timestamp, mask revision and typed event. Logs are no longer string-only records.              |
| `job_events.event.log`                                  | Optional admitted `LogLocation`: parent step ID, step number, first physical line, physical line count and global ordering.                                  |
| `job_events.request_mac`                                | HMAC of the original typed request before controller redaction; detects conflicting retries without exposing a guessable secret digest.                      |
| `jobs.report`                                           | `Projection`: step lifecycle, raw/adjusted outcomes, diagnostic locations, partial records and distinct attachment states. Payload text remains in events.   |
| Encrypted `jobs.envelope`                               | Acquired API payload, job authority, assignment masks/revision and selected `FeedStreamUrl`.                                                                 |
| Encrypted `jobs.delivery`                               | Upload identities, byte counts/digests, signed destinations, retry checkpoints, metadata and confirmed/uncertain outcomes.                                   |
| `last_sequence` / `reported_sequence` / `live_sequence` | Durable admission, final-report processing, and best-effort live consideration. None substitutes for another.                                                |
| `report_owner`                                          | Controller generation fencing delivery/live checkpoints in addition to the runner's database session lock.                                                   |
| Executor `events/*/control` / `bulk-*`                  | Reserved authenticated control banks, durable admission receipts, and reclaimable encrypted payload segments. The attempt directory hashes job ID and epoch. |

The row-lock transaction alone owns line numbering. A logical message containing `N` LF characters occupies `N+1` physical lines; final archives prepend one original timestamp and append one LF. A diagnostic and its rendered message are admitted together. `StepCompleted` seals the archive: both ordinary fragments and diagnostics are rejected afterward. Job-output evaluation runs under a fresh `Complete job` identity, so its later errors cannot mutate a published customer-step archive. Explicit source path/line/column ranges remain separate from fallback log coordinates. File-less diagnostics use their actual parent step number and first rendered physical line. The final job archive preserves admission order across steps. No upload-time timestamps or guessed zero line numbers are substituted.

## Acquisition recovery

An acquisition intent records the exact GitHub job reference before the request leaves the controller. A decoded response is encrypted and saved before job projection or unsupported-job reporting. Restart uses that saved response when available. Otherwise, it retries the original `jobMessageId`; it never admits a different job while the claim remains unresolved.

A complete first-request rejection is distinct from a lost response. After ambiguous success, a conflict cannot identify who acquired the resource, so the machine remains quarantined. A definitive missing or unprocessable resource closes the intent. Neither age nor replacement of the broker session clears ownership. Error classification follows the inspected [Run Service client](https://github.com/actions/runner/blob/67f01c276e0a91d967ba499ce4cdc9a95efa0262/src/Sdk/RSWebApi/RunServiceHttpClient.cs); this comparison and local source checks do not qualify the retry behavior against GitHub's live service.

The machine's executor token or the management token can read `GET /api/v2/executors/{id}/acquisition`. It returns the intent state, attempt count, last status, next retry time, and whether a response was saved. `POST /api/v2/executors/{id}/acquisition/reconcile` requests an immediate retry of that same resource. It does not override quarantine or erase a potentially successful claim. Resolve persistent conflicts through the backend before expecting new capacity.

## Event contracts

The actual Rust types are in `control-plane-core/src/lib.rs`; `/openapi.json` describes the same current consumer protocol. All event identities are scoped to one acquired job and epoch. The executor allocates record UUIDs and embedded attachment UUIDs. GitHub supplies top-level reporting-step UUIDs. An embedded action shares its parent's reporting-step ID but owns an independent summary attachment ID; pre/main/post invocations cannot overwrite one another's summary.

Representative `event` objects below sit inside an envelope with `job_id`, `epoch`, contiguous `sequence`, producer `observed_at` and `mask_revision`. `kind` selects the variant. Every `step_id` or `parent_step_id` identifies the reporting step; `attachment_id` identifies one file, not the enclosing composite.

```json
{"kind":"log","step_id":"11111111-1111-4111-8111-111111111111","record_id":"22222222-2222-4222-8222-222222222222","index":0,"last":true,"text":"masked output"}
```

`/record_id` is stable across fragments/replay; `/index` is a zero-based fragment index, not a byte offset; `/last` seals the logical record; `/text` contains already masked UTF-8 without a transport-added newline. Fragments are at most 64 KiB, contiguous, and must agree on parent and capture time. An incomplete mandatory log prevents step closure.

```json
{"kind":"diagnostic","step_id":"11111111-1111-4111-8111-111111111111","category":"process_exit","annotation":{"level":"failure","message":"Process completed with exit code 7.","title":null,"path":null,"start_line":null,"end_line":null,"start_column":null,"end_column":null},"rendered_log":"##[error]Process completed with exit code 7."}
```

`/category` distinguishes ordinary exit, cancellation/timeout, workflow-command, matcher and summary-file diagnostics. `/annotation` is independently structured severity and optional source attribution; `/rendered_log` establishes the matching physical log location. Severity does not change execution outcome: an error command with exit zero still succeeds, while `continue-on-error` retains both the raw failure diagnostic and adjusted successful conclusion.

```json
{"kind":"summary_chunk","parent_step_id":"11111111-1111-4111-8111-111111111111","attachment_id":"33333333-3333-4333-8333-333333333333","index":0,"utf8":"probe\n"}
{"kind":"summary_complete","parent_step_id":"11111111-1111-4111-8111-111111111111","attachment_id":"33333333-3333-4333-8333-333333333333","chunks":1,"original_bytes":6,"masked_bytes":6,"masked_sha256":"25be323556dad377abb57fe7ec8c4b99a6527f488dda28d0c9b686528659c909"}
```

`/index` is a zero-based chunk index; `/utf8` is masked content, at most 64 KiB. `/chunks` is the complete count. `/original_bytes` measures the original file for its 1 MiB allowance; `/masked_bytes` and `/masked_sha256` describe the exact outgoing normalized, masked UTF-8 body. The executor reads an admitted-size file, masks each complete line, adds the reference Unix LF line endings, then splits it. A secret crossing a future chunk boundary is removed before either fragment exists. Admission rejects any summary fragment its defensive mask would alter.

Summary input moves `Receiving → Ready` only after independent reconstruction verifies contiguous positions, lengths, hash and original size. An identical chunk duplicate adds no bytes; conflicting/missing/out-of-order/oversized chunks fail. A parent closing with unfinished input marks it `Incomplete`; later fragments cannot reopen it. Incomplete optional content never becomes an upload and does not prevent job completion. Two valid 600 KiB child files become two complete bodies, never one 1200 KiB parent body.

## Reporting workers, retries and uncertainty

The runner actor owns renewal and cancellation polling. Its independently scheduled reporter reconstructs admitted snapshots and closed archives. A separate live worker reads the same durable records, bounded by the sequence in its captured projection. Events committed after that projection are considered only on the next pass; the consideration cursor never moves backward. Dropping actor ownership aborts both workers; checkpoint fencing prevents an older owner overwriting the replacement's state. Final reporting and capacity release never await live delivery.

Each summary or log upload follows `Pending → Putting → BytesAccepted → Registering → Published`. Terminal alternatives are `Skipped` for a known exhausted/rejected optional operation and `Unconfirmed` when registration may have reached the service without a durable response.

- Signed-URL acquisition persists a finite attempt budget. It has no claimed publication effect. The service-returned summary allowance is applied per file.
- `Putting` persists the validated signed destination and immutable body identity before sending. A restart can repeat only those same bytes at that destination, using the reference raw-HTTP BlockBlob path. Storage acceptance and metadata acceptance are different checkpoints.
- `Registering` persists the exact metadata before POST. HTTP success also requires `ok: true`. No evidence establishes metadata-registration idempotency: recovery marks an interrupted registration unconfirmed instead of blindly repeating it or claiming success. Other attachments and completion still proceed. Qualification refuses an unconfirmed required attachment.
- Step snapshots retain their admission `change_order`, step IDs and timestamps on replay. Job completion retains the actual raw execution/adjusted step results and annotations. An uncertain completion can be retried against the same job. If GitHub later rejects its job credential, Ferrun cannot infer whether an earlier completion reached GitHub.

A rejected job credential is recorded across controller restarts. Ferrun requests
cancellation and retains the machine's slot until the executor reports completion.
It then records a reporting failure and releases the slot. The execution result,
saved events and reporting counters remain intact; the delivery record is not marked
successful. The job page shows the rejection status and unconfirmed completion.
This applies to HTTP 401 from job-authenticated services and HTTP 404 or 410 from
job renewal or completion. Other failures retain the retry path; a missing Results
endpoint does not establish that the job has expired.

Uploads get at most three persisted attempts and 30-second request bounds. Optional upload failures remain internal reporting health, matching the reference queue's best-effort behavior; they do not invent execution failures or additional workflow annotations. Genuine oversized individual files produce the reference's nonfatal user diagnostic before transport.

## Live-console contract

The selected endpoint is `/resources/endpoints[name=SystemVssConnection]/data/FeedStreamUrl` from the acquired job. Only `wss` on port 443/default, a `.actions.githubusercontent.com` host, and no user-info or fragment is allowed. This is a separate validator; existing HTTPS destination rules are unchanged. Missing/unsupported endpoints disable only live delivery. The handshake uses standard WebSocket upgrade headers plus the acquired job's bearer token and this implementation's User-Agent; redirects and guessed fallback endpoints are not used.

The pinned `TimelineRecordFeedLinesWrapper`, serialized through the reference camel-case formatter, is:

```json
{"count":2,"value":["first output","second output"],"stepId":"11111111-1111-4111-8111-111111111111","startLine":7}
```

`/count` counts strings; `/value` contains rendered masked preview messages without archive timestamps; `/stepId` is the actual parent reporting identity; `/startLine` is the first physical archive line. One JSON wrapper is one WebSocket message, split into 1024-byte frames with Text first, Continuation thereafter, and FIN only on the final frame. It is not one JSON document per frame.

Reference-derived limits are 1024 queued records, 1024 UTF-16 units plus `...` per preview, 100 strings per batch, and the last 200 strings per step in final draining. The adapter also bounds pending serialized data to 8 MiB and batches to 640 KiB. Connect timeout is 30 seconds; one batch has a 60-second total budget with three attempts and 100–500 ms reconnect jitter. Exhaustion starts a ten-minute cooldown. Capacity release aborts outstanding live work rather than waiting for its final flush.

Interrupted sends retry a complete wrapper with unchanged offsets, following the reference. The protocol supplies no application acknowledgment, and duplicate handling has not been independently established. `live_sequence` means considered, not confirmed delivered; restart does not replay an uncertain old preview queue. Dropped/truncated live copies remain complete in admitted events and final archives. The synchronized local WebSocket test observes output before releasing the producing subprocess, proving local streaming behavior; real GitHub visibility remains explicitly unverified.

## Regression entry points

| Fault   | Production path and fixture                                             | Required assertion / deliberate old behavior                                                                                                                                                      |
| ------- | ----------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| R10     | `Delivery::file`, `summary-probe/action.yml`, independent Rust receiver | Two complete 614400-byte PUTs and metadata registrations; collapsing target IDs must fail.                                                                                                        |
| R11     | `Runtime::script`, `directory-probe/action.yml`                         | Caller default applies only in `Workflow` scope; forcing it in `Embedded` scope must fail. Nested children retain embedded scope, explicit child directories win, missing embedded shell fails.   |
| R12     | `hash_files::hash`, semantics absolute/relative probes                  | Equivalent contained spellings match; unconditional absolute rejection must fail. Ordered exclusions/reinclusion, recursive patterns and file symlinks retain separate tests.                     |
| R13–R14 | `Runtime::process` and diagnostic emission                              | Preserve exit 7 and timeout/cancellation messages with raw/adjusted results; suppressing either diagnostic category must fail.                                                                    |
| R15–R16 | `report::log_bytes` / `annotation_json`                                 | Injected timestamps survive replay and multiline messages target actual physical lines; upload-time stamps or zero attribution must fail.                                                         |
| R17–R19 | Runtime command rendering and matcher registry                          | Render groups, match pinned checkout/setup-node fixtures, and preserve selected composite raw/adjusted markers; literal commands, discarded registrations or ignored feature selection must fail. |
| R20     | `Agent::emit_at`, blocked receipt + subprocess barrier                  | Cancellation completes while event acknowledgment remains withheld; synchronous network flush inside emission must fail.                                                                          |
| R21–R22 | `Delivery::file`, independent receiver/checkpoint                       | Accepted content survives lost metadata checkpoint without duplicate registration; false confirmation or ignoring `ok:false` must fail.                                                           |
| R24     | `Projection::writable_step`, finalization fixtures                      | Reject late log fragments/diagnostics after publication while a separate finalization error still completes the job.                                                                              |
| R25     | `spool::send`, truncated HTTP-200 receipt peer                          | A second byte-identical event request must obtain the complete receipt; decoding failure cannot kill recoverable delivery.                                                                        |
| R26     | `live::events_at`, PostgreSQL admission interleaving                    | A later committed event is excluded from the older snapshot and appears exactly once in the next read.                                                                                            |
| R23     | `live::send_message`, synchronized WebSocket/subprocess                 | Receive a complete valid frame contract while the producer remains running; sending no frames must fail.                                                                                          |

Existing R1–R9 cover publication inventory, nonfatal summary rejection, action Node identity, cleanup cancellation, step timeout scope, PATH propagation, annotation/outcome separation, recursive hashes and default shell semantics. The PostgreSQL stage independently checks concurrent exact replay, conflicting requests, failed-admission rollback, encrypted mask state and same-format restart. The executor crash probe checks exact encrypted replay and torn-tail recovery. Compiler failures are not accepted as mutation detection.

Pinned problem matcher fixtures are documented under `devtools/tests/fixtures/matchers/README.md`. The implementation supports owner replacement/removal, single and multiline captures, terminal looping, severity/source attribution and ANSI-stripped matching. It uses Rust's linear-time regex engine; compatibility with every .NET-only regex construct is not claimed.

The hash implementation follows the pinned bundled `@actions/glob` selection rules: normalize before expansion, preserve wildcard components and argument search-root order, prune redundant descendant roots, traverse entries in sorted depth-first order, apply ordered exclusions and reinclusions, and deduplicate lexical paths. The workspace boundary is lexical, as in the reference helper: direct outside matches are omitted; workspace file symlinks are followed, including targets outside the workspace. Directory symlinks are not descended by default; the explicit follow option uses cycle checks. This is parity, not a filesystem sandbox.
