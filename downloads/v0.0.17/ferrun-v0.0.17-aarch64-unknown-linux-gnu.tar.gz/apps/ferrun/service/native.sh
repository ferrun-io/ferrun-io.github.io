#!/bin/bash
# Copyright (c) 2026 Ferrun contributors. All rights reserved.
#
# Responsibility: Install optional Linux systemd units and maintain controller
# deployments through native.py.
# Connections: Cloud bundle entry points use this wrapper to invoke native.py under
# the selected interpreter.

# Install the same native server bundle on a customer host or Ferrun's host.
# The operator supplies PostgreSQL and an HTTPS proxy.
set -euo pipefail
native_bundle="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd -P)"
native_state="${FERRUN_STATE_DIR:-/var/lib/ferrun-control-plane}"
native_user=ferrun-control-plane
native_unit=/etc/systemd/system/ferrun-control-plane.service
native_operation="${1:?Expected install, reinstall, worker-service, start, status, backup, or remove}"
shift
[[ "$(id -u)" == 0 ]] || {
  printf '%s\n' 'Run the native service installer as root.' >&2
  exit 1
}
[[ "$(uname -s)" == Linux ]] && command -v systemctl > /dev/null || {
  printf '%s\n' 'This adapter requires Linux with systemd. Use ferrun run with your host supervisor.' >&2
  exit 1
}
[[ "$native_state" == /* && "$native_state" != / ]] || exit 2

# Existing worker-install commands delegate to the native CLI. Service policy
# and execution-account handling have one implementation on all platforms.
if [[ "$native_operation" == worker-service ]]; then
  [[ $# == 0 ]] || exit 2
  native_state="${FERRUN_STATE_DIR:-/var/lib/ferrun-runner}"
  (cd "$native_bundle" && sha256sum -c native-files.sha256)
  native_worker_user="$(stat -c %U -- "$native_state")"
  exec runuser -u "$native_worker_user" -- "$native_bundle/ferrun" service start --state-dir "$native_state" --bin-dir "$native_bundle"
fi

# Registration and GitHub keys are configured only by the company operator.
# DATABASE_URL prevents the launcher from selecting its Docker database fallback.
if [[ "$native_operation" == install ]]; then
  [[ ! -e /etc/systemd/system/ferrun-cloud.service ]] || {
    printf '%s\n' 'Use make deploy to migrate the existing ferrun-cloud controller service.' >&2
    exit 1
  }
  [[ $# == 0 || $# == 3 ]] || {
    printf '%s\n' 'Usage: native.sh install [OWNER/REPO APP_ID APP_KEY_FILE]' >&2
    exit 2
  }
  [[ -n "${DATABASE_URL:-}" ]] || {
    printf '%s\n' 'Set DATABASE_URL for this installation’s PostgreSQL database.' >&2
    exit 1
  }
  native_version="${FERRUN_RUNNER_VERSION:-}"
  if [[ -z "$native_version" && -f "$native_bundle/manifest.json" ]]; then
    native_version="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["runner_version"])' "$native_bundle/manifest.json")"
  fi
  # GitHub inputs are optional; validate them before installation creates resources.
  if [[ $# == 3 ]]; then
    [[ "$native_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || {
      printf '%s\n' 'Set FERRUN_RUNNER_VERSION to the selected release’s runner version.' >&2
      exit 1
    }
    [[ -f "$3" && -r "$3" ]] || {
      printf '%s\n' 'The GitHub App key must be a readable file.' >&2
      exit 1
    }
    [[ "$1" =~ ^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$ && "$2" =~ ^[1-9][0-9]*$ ]] || {
      printf '%s\n' 'Supply OWNER/REPO and a numeric GitHub App ID.' >&2
      exit 1
    }
  fi
  [[ -z "${CONTROL_PLANE_WEB_URL:-}" || -n "${CONTROL_PLANE_TRUSTED_PROXIES:-}" ]] || {
    printf '%s\n' 'Set CONTROL_PLANE_TRUSTED_PROXIES for the HTTPS proxy.' >&2
    exit 1
  }
  python3 "$native_bundle/apps/ferrun/service/native.py" paths "$native_bundle" "$native_state"
  # Verify the unpacked native package before copying keys or installing a service.
  (cd "$native_bundle" && sha256sum -c native-files.sha256)
  [[ ! -e "$native_unit" && ! -L "$native_unit" && ! -e "$native_state" && ! -L "$native_state" ]] || {
    printf '%s\n' 'Installation requires a new state directory and no existing service unit.' >&2
    exit 1
  }
  if id "$native_user" > /dev/null 2>&1; then
    printf '%s\n' 'The ferrun-control-plane account already exists; review it before installation.' >&2
    exit 1
  fi
  # A failed first installation must be retryable. Remove only resources created
  # by this attempt; preexisting accounts, state, and units were refused above.
  native_account_created=false
  native_state_created=false
  native_unit_created=false
  native_install_cleanup() {
    native_status="$?"
    trap - EXIT
    if [[ "$native_status" -ne 0 ]]; then
      if [[ "$native_unit_created" == true ]]; then
        rm -f -- "$native_unit"
        systemctl daemon-reload || true
      fi
      if [[ "$native_state_created" == true ]]; then
        rm -rf -- "$native_state"
      fi
      if [[ "$native_account_created" == true ]]; then
        userdel "$native_user" || true
      fi
    fi
    exit "$native_status"
  }
  trap native_install_cleanup EXIT
  useradd --system --user-group --home-dir "$native_state" --shell /usr/sbin/nologin "$native_user"
  native_account_created=true
  native_state_created=true
  install -d -m 700 -o "$native_user" -g "$native_user" "$native_state"
  chmod 755 "$native_bundle" "$native_bundle/ferrun" "$native_bundle/control-plane" "$native_bundle/executor"
  native_arguments=(--mode server --state-dir "$native_state" --bin-dir "$native_bundle")
  if [[ $# == 3 ]]; then
    install -m 600 -o "$native_user" -g "$native_user" "$3" "$native_state/github-app.pem"
    native_arguments+=(--repo "$1" --app-id "$2" --app-key "$native_state/github-app.pem" --runner-version "$native_version")
  elif [[ -n "$native_version" ]]; then
    native_arguments+=(--runner-version "$native_version")
  fi
  [[ -z "${FERRUN_LABEL:-}" ]] || native_arguments+=(--label "$FERRUN_LABEL")
  [[ -z "${FERRUN_API_PORT:-}" ]] || native_arguments+=(--port "$FERRUN_API_PORT")
  runuser -u "$native_user" -- "$native_bundle/ferrun" setup "${native_arguments[@]}"

  # Public URL and actual proxy peers control browser access; credentials are
  # already saved by the launcher in its private state directory.
  native_interface="$native_state/interface.env"
  if [[ -n "${CONTROL_PLANE_WEB_URL:-}" || -n "${CONTROL_PLANE_DOWNLOAD_URL:-}" ]]; then
    : > "$native_interface"
    [[ -z "${CONTROL_PLANE_WEB_URL:-}" ]] || printf 'CONTROL_PLANE_WEB_URL=%s\nCONTROL_PLANE_TRUSTED_PROXIES=%s\n' "$CONTROL_PLANE_WEB_URL" "${CONTROL_PLANE_TRUSTED_PROXIES:?Set the actual proxy source addresses}" >> "$native_interface"
    if [[ -n "${CONTROL_PLANE_DOWNLOAD_URL:-}" ]]; then
      printf 'CONTROL_PLANE_DOWNLOAD_URL=%s\n' "$CONTROL_PLANE_DOWNLOAD_URL" >> "$native_interface"
    fi
    chmod 600 "$native_interface"
    chown "$native_user:$native_user" "$native_interface"
  fi
  native_unit_created=true
  python3 "$native_bundle/apps/ferrun/service/native.py" service "$native_bundle" "$native_state"
  systemctl daemon-reload
  trap - EXIT
  printf '%s\n' 'Native service installed. Configure HTTPS, then run native.sh start.'
  exit
fi

# Maintenance always addresses this installation's saved state and systemd unit.
case "$native_operation" in
  reinstall)
    # Recreate only the owned unit. Saved keys, database selection, pool IDs,
    # and machine registrations are reused after service removal.
    [[ -f "$native_state/settings.json" ]] || exit 1
    [[ ! -e /etc/systemd/system/ferrun-cloud.service ]] || {
      printf '%s\n' 'Use make deploy to migrate the existing ferrun-cloud controller service.' >&2
      exit 1
    }
    (cd "$native_bundle" && sha256sum -c native-files.sha256)
    python3 "$native_bundle/apps/ferrun/service/native.py" service "$native_bundle" "$native_state"
    systemctl daemon-reload
    systemctl enable --now ferrun-control-plane.service
    ;;
  start)
    systemctl enable --now ferrun-control-plane.service
    ;;
  status)
    systemctl --no-pager status ferrun-control-plane.service
    ;;
  backup)
    python3 "$native_bundle/apps/ferrun/service/native.py" backup "$native_bundle" "$native_state"
    ;;
  remove)
    # Disable enrollment and refuse removal while runners or unfinished jobs remain.
    # The helper checks PostgreSQL without deleting job records.
    python3 "$native_bundle/apps/ferrun/service/native.py" empty "$native_bundle" "$native_state"
    "$0" backup
    systemctl disable --now ferrun-control-plane.service
    rm -- "$native_unit"
    systemctl daemon-reload
    printf 'Native service removed. State and backups remain at %s.\n' "$native_state"
    ;;
  *)
    printf '%s\n' 'Expected install, reinstall, worker-service, start, status, backup, or remove' >&2
    exit 2
    ;;
esac
