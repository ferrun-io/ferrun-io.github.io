# Third-party notices

License declarations and supplied notice texts for this native dependency graph. Build dependencies are included; external workflow tools and actions retain their own distributions.

| Package | Declared license | Supplied notices |
| --- | --- | --- |
| adler2 2.0.1 | 0BSD OR MIT OR Apache-2.0 | [LICENSE-0BSD](third-party/adler2-2.0.1/LICENSE-0BSD), [LICENSE-APACHE](third-party/adler2-2.0.1/LICENSE-APACHE), [LICENSE-MIT](third-party/adler2-2.0.1/LICENSE-MIT) |
| aead 0.5.2 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/aead-0.5.2/LICENSE-APACHE), [LICENSE-MIT](third-party/aead-0.5.2/LICENSE-MIT) |
| aes 0.8.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/aes-0.8.4/LICENSE-APACHE), [LICENSE-MIT](third-party/aes-0.8.4/LICENSE-MIT) |
| aes-gcm 0.10.3 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/aes-gcm-0.10.3/LICENSE-APACHE), [LICENSE-MIT](third-party/aes-gcm-0.10.3/LICENSE-MIT) |
| aho-corasick 1.1.5 | Unlicense OR MIT | [COPYING](third-party/aho-corasick-1.1.5/COPYING), [LICENSE-MIT](third-party/aho-corasick-1.1.5/LICENSE-MIT) |
| allocator-api2 0.2.21 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/allocator-api2-0.2.21/LICENSE-APACHE), [LICENSE-MIT](third-party/allocator-api2-0.2.21/LICENSE-MIT) |
| anyhow 1.0.104 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/anyhow-1.0.104/LICENSE-APACHE), [LICENSE-MIT](third-party/anyhow-1.0.104/LICENSE-MIT) |
| anymap3 1.1.0 | BlueOak-1.0.0 OR MIT OR Apache-2.0 | [COPYING](third-party/anymap3-1.1.0/COPYING) |
| async-trait 0.1.92 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/async-trait-0.1.92/LICENSE-APACHE), [LICENSE-MIT](third-party/async-trait-0.1.92/LICENSE-MIT) |
| atoi 2.0.0 | MIT | [LICENSE](third-party/atoi-2.0.0/LICENSE) |
| atomic-waker 1.1.2 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/atomic-waker-1.1.2/LICENSE-APACHE), [LICENSE-MIT](third-party/atomic-waker-1.1.2/LICENSE-MIT), [LICENSE-THIRD-PARTY](third-party/atomic-waker-1.1.2/LICENSE-THIRD-PARTY) |
| autocfg 1.5.1 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/autocfg-1.5.1/LICENSE-APACHE), [LICENSE-MIT](third-party/autocfg-1.5.1/LICENSE-MIT) |
| axum 0.8.9 | MIT | [LICENSE](third-party/axum-0.8.9/LICENSE) |
| axum-core 0.5.6 | MIT | [LICENSE](third-party/axum-core-0.5.6/LICENSE) |
| base64 0.22.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/base64-0.22.1/LICENSE-APACHE), [LICENSE-MIT](third-party/base64-0.22.1/LICENSE-MIT) |
| base64ct 1.8.3 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/base64ct-1.8.3/LICENSE-APACHE), [LICENSE-MIT](third-party/base64ct-1.8.3/LICENSE-MIT) |
| bitflags 2.13.2 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/bitflags-2.13.2/LICENSE-APACHE), [LICENSE-MIT](third-party/bitflags-2.13.2/LICENSE-MIT) |
| block-buffer 0.10.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/block-buffer-0.10.4/LICENSE-APACHE), [LICENSE-MIT](third-party/block-buffer-0.10.4/LICENSE-MIT) |
| block-buffer 0.12.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/block-buffer-0.12.1/LICENSE-APACHE), [LICENSE-MIT](third-party/block-buffer-0.12.1/LICENSE-MIT) |
| byteorder 1.5.0 | Unlicense OR MIT | [COPYING](third-party/byteorder-1.5.0/COPYING), [LICENSE-MIT](third-party/byteorder-1.5.0/LICENSE-MIT) |
| bytes 1.12.1 | MIT | [LICENSE](third-party/bytes-1.12.1/LICENSE) |
| cc 1.4.5 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/cc-1.4.5/LICENSE-APACHE), [LICENSE-MIT](third-party/cc-1.4.5/LICENSE-MIT) |
| cfg-if 1.0.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/cfg-if-1.0.4/LICENSE-APACHE), [LICENSE-MIT](third-party/cfg-if-1.0.4/LICENSE-MIT) |
| cfg_aliases 0.2.2 | MIT | [LICENSE](third-party/cfg_aliases-0.2.2/LICENSE), [NOTICES.md](third-party/cfg_aliases-0.2.2/NOTICES.md) |
| chacha20 0.10.2 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/chacha20-0.10.2/LICENSE-APACHE), [LICENSE-MIT](third-party/chacha20-0.10.2/LICENSE-MIT) |
| chrono 0.4.45 | MIT OR Apache-2.0 | [LICENSE.txt](third-party/chrono-0.4.45/LICENSE.txt) |
| cipher 0.4.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/cipher-0.4.4/LICENSE-APACHE), [LICENSE-MIT](third-party/cipher-0.4.4/LICENSE-MIT) |
| const-oid 0.10.2 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/const-oid-0.10.2/LICENSE-APACHE), [LICENSE-MIT](third-party/const-oid-0.10.2/LICENSE-MIT) |
| const-oid 0.9.6 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/const-oid-0.9.6/LICENSE-APACHE), [LICENSE-MIT](third-party/const-oid-0.9.6/LICENSE-MIT) |
| cpufeatures 0.2.17 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/cpufeatures-0.2.17/LICENSE-APACHE), [LICENSE-MIT](third-party/cpufeatures-0.2.17/LICENSE-MIT) |
| cpufeatures 0.3.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/cpufeatures-0.3.1/LICENSE-APACHE), [LICENSE-MIT](third-party/cpufeatures-0.3.1/LICENSE-MIT) |
| crc 3.4.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/crc-3.4.0/LICENSE-APACHE), [LICENSE-MIT](third-party/crc-3.4.0/LICENSE-MIT) |
| crc-catalog 2.5.0 | MIT OR Apache-2.0 | [Apache-2.0.txt](third-party/crc-catalog-2.5.0/Apache-2.0.txt), [MIT.txt](third-party/crc-catalog-2.5.0/MIT.txt) |
| crc32fast 1.5.2 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/crc32fast-1.5.2/LICENSE-APACHE), [LICENSE-MIT](third-party/crc32fast-1.5.2/LICENSE-MIT) |
| crossbeam-queue 0.3.14 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/crossbeam-queue-0.3.14/LICENSE-APACHE), [LICENSE-MIT](third-party/crossbeam-queue-0.3.14/LICENSE-MIT) |
| crossbeam-utils 0.8.23 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/crossbeam-utils-0.8.23/LICENSE-APACHE), [LICENSE-MIT](third-party/crossbeam-utils-0.8.23/LICENSE-MIT) |
| crypto-common 0.1.7 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/crypto-common-0.1.7/LICENSE-APACHE), [LICENSE-MIT](third-party/crypto-common-0.1.7/LICENSE-MIT) |
| crypto-common 0.2.2 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/crypto-common-0.2.2/LICENSE-APACHE), [LICENSE-MIT](third-party/crypto-common-0.2.2/LICENSE-MIT) |
| ctr 0.9.2 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/ctr-0.9.2/LICENSE-APACHE), [LICENSE-MIT](third-party/ctr-0.9.2/LICENSE-MIT) |
| data-encoding 2.11.1 | MIT | [LICENSE](third-party/data-encoding-2.11.1/LICENSE) |
| der 0.7.10 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/der-0.7.10/LICENSE-APACHE), [LICENSE-MIT](third-party/der-0.7.10/LICENSE-MIT) |
| digest 0.10.7 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/digest-0.10.7/LICENSE-APACHE), [LICENSE-MIT](third-party/digest-0.10.7/LICENSE-MIT) |
| digest 0.11.3 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/digest-0.11.3/LICENSE-APACHE), [LICENSE-MIT](third-party/digest-0.11.3/LICENSE-MIT) |
| displaydoc 0.2.7 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/displaydoc-0.2.7/LICENSE-APACHE), [LICENSE-MIT](third-party/displaydoc-0.2.7/LICENSE-MIT) |
| dotenvy 0.15.7 | MIT | [LICENSE](third-party/dotenvy-0.15.7/LICENSE) |
| either 1.18.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/either-1.18.0/LICENSE-APACHE), [LICENSE-MIT](third-party/either-1.18.0/LICENSE-MIT) |
| elsa 1.11.2 | MIT/Apache-2.0 | [LICENSE-APACHE](third-party/elsa-1.11.2/LICENSE-APACHE), [LICENSE-MIT](third-party/elsa-1.11.2/LICENSE-MIT) |
| equivalent 1.0.2 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/equivalent-1.0.2/LICENSE-APACHE), [LICENSE-MIT](third-party/equivalent-1.0.2/LICENSE-MIT) |
| errno 0.3.14 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/errno-0.3.14/LICENSE-APACHE), [LICENSE-MIT](third-party/errno-0.3.14/LICENSE-MIT) |
| event-listener 5.4.2 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/event-listener-5.4.2/LICENSE-APACHE), [LICENSE-MIT](third-party/event-listener-5.4.2/LICENSE-MIT) |
| filetime 0.2.29 | MIT/Apache-2.0 | [LICENSE-APACHE](third-party/filetime-0.2.29/LICENSE-APACHE), [LICENSE-MIT](third-party/filetime-0.2.29/LICENSE-MIT) |
| find-msvc-tools 0.1.12 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/find-msvc-tools-0.1.12/LICENSE-APACHE), [LICENSE-MIT](third-party/find-msvc-tools-0.1.12/LICENSE-MIT) |
| flate2 1.1.10 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/flate2-1.1.10/LICENSE-APACHE), [LICENSE-MIT](third-party/flate2-1.1.10/LICENSE-MIT) |
| flume 0.11.1 | Apache-2.0/MIT | [LICENSE-APACHE](third-party/flume-0.11.1/LICENSE-APACHE), [LICENSE-MIT](third-party/flume-0.11.1/LICENSE-MIT) |
| foldhash 0.1.5 | Zlib | [LICENSE](third-party/foldhash-0.1.5/LICENSE) |
| form_urlencoded 1.2.2 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/form_urlencoded-1.2.2/LICENSE-APACHE), [LICENSE-MIT](third-party/form_urlencoded-1.2.2/LICENSE-MIT) |
| futures-channel 0.3.34 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/futures-channel-0.3.34/LICENSE-APACHE), [LICENSE-MIT](third-party/futures-channel-0.3.34/LICENSE-MIT) |
| futures-core 0.3.34 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/futures-core-0.3.34/LICENSE-APACHE), [LICENSE-MIT](third-party/futures-core-0.3.34/LICENSE-MIT) |
| futures-executor 0.3.34 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/futures-executor-0.3.34/LICENSE-APACHE), [LICENSE-MIT](third-party/futures-executor-0.3.34/LICENSE-MIT) |
| futures-intrusive 0.5.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/futures-intrusive-0.5.0/LICENSE-APACHE), [LICENSE-MIT](third-party/futures-intrusive-0.5.0/LICENSE-MIT) |
| futures-io 0.3.34 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/futures-io-0.3.34/LICENSE-APACHE), [LICENSE-MIT](third-party/futures-io-0.3.34/LICENSE-MIT) |
| futures-macro 0.3.34 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/futures-macro-0.3.34/LICENSE-APACHE), [LICENSE-MIT](third-party/futures-macro-0.3.34/LICENSE-MIT) |
| futures-sink 0.3.34 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/futures-sink-0.3.34/LICENSE-APACHE), [LICENSE-MIT](third-party/futures-sink-0.3.34/LICENSE-MIT) |
| futures-task 0.3.34 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/futures-task-0.3.34/LICENSE-APACHE), [LICENSE-MIT](third-party/futures-task-0.3.34/LICENSE-MIT) |
| futures-util 0.3.34 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/futures-util-0.3.34/LICENSE-APACHE), [LICENSE-MIT](third-party/futures-util-0.3.34/LICENSE-MIT) |
| generic-array 0.14.7 | MIT | [LICENSE](third-party/generic-array-0.14.7/LICENSE) |
| getrandom 0.2.17 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/getrandom-0.2.17/LICENSE-APACHE), [LICENSE-MIT](third-party/getrandom-0.2.17/LICENSE-MIT) |
| getrandom 0.3.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/getrandom-0.3.4/LICENSE-APACHE), [LICENSE-MIT](third-party/getrandom-0.3.4/LICENSE-MIT) |
| getrandom 0.4.3 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/getrandom-0.4.3/LICENSE-APACHE), [LICENSE-MIT](third-party/getrandom-0.4.3/LICENSE-MIT) |
| ghash 0.5.1 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/ghash-0.5.1/LICENSE-APACHE), [LICENSE-MIT](third-party/ghash-0.5.1/LICENSE-MIT) |
| github-actions-expressions 1.30.1 | MIT | [LICENSE](third-party/github-actions-expressions-1.30.1/LICENSE) |
| glob 0.3.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/glob-0.3.4/LICENSE-APACHE), [LICENSE-MIT](third-party/glob-0.3.4/LICENSE-MIT) |
| hashbrown 0.15.5 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/hashbrown-0.15.5/LICENSE-APACHE), [LICENSE-MIT](third-party/hashbrown-0.15.5/LICENSE-MIT) |
| hashbrown 0.17.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/hashbrown-0.17.1/LICENSE-APACHE), [LICENSE-MIT](third-party/hashbrown-0.17.1/LICENSE-MIT) |
| hashlink 0.10.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/hashlink-0.10.0/LICENSE-APACHE), [LICENSE-MIT](third-party/hashlink-0.10.0/LICENSE-MIT) |
| heck 0.5.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/heck-0.5.0/LICENSE-APACHE), [LICENSE-MIT](third-party/heck-0.5.0/LICENSE-MIT) |
| hex 0.4.3 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/hex-0.4.3/LICENSE-APACHE), [LICENSE-MIT](third-party/hex-0.4.3/LICENSE-MIT) |
| hkdf 0.12.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/hkdf-0.12.4/LICENSE-APACHE), [LICENSE-MIT](third-party/hkdf-0.12.4/LICENSE-MIT) |
| hmac 0.12.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/hmac-0.12.1/LICENSE-APACHE), [LICENSE-MIT](third-party/hmac-0.12.1/LICENSE-MIT) |
| home 0.5.12 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/home-0.5.12/LICENSE-APACHE), [LICENSE-MIT](third-party/home-0.5.12/LICENSE-MIT) |
| http 1.5.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/http-1.5.0/LICENSE-APACHE), [LICENSE-MIT](third-party/http-1.5.0/LICENSE-MIT) |
| http-body 1.1.0 | MIT | [LICENSE](third-party/http-body-1.1.0/LICENSE) |
| http-body-util 0.1.5 | MIT | [LICENSE](third-party/http-body-util-0.1.5/LICENSE) |
| httparse 1.10.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/httparse-1.10.1/LICENSE-APACHE), [LICENSE-MIT](third-party/httparse-1.10.1/LICENSE-MIT) |
| httpdate 1.0.3 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/httpdate-1.0.3/LICENSE-APACHE), [LICENSE-MIT](third-party/httpdate-1.0.3/LICENSE-MIT) |
| hybrid-array 0.4.15 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/hybrid-array-0.4.15/LICENSE-APACHE), [LICENSE-MIT](third-party/hybrid-array-0.4.15/LICENSE-MIT) |
| hyper 1.11.1 | MIT | [LICENSE](third-party/hyper-1.11.1/LICENSE) |
| hyper-rustls 0.27.9 | Apache-2.0 OR ISC OR MIT | [LICENSE-APACHE](third-party/hyper-rustls-0.27.9/LICENSE-APACHE), [LICENSE-ISC](third-party/hyper-rustls-0.27.9/LICENSE-ISC), [LICENSE-MIT](third-party/hyper-rustls-0.27.9/LICENSE-MIT) |
| hyper-util 0.1.20 | MIT | [LICENSE](third-party/hyper-util-0.1.20/LICENSE) |
| iana-time-zone 0.1.65 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/iana-time-zone-0.1.65/LICENSE-APACHE), [LICENSE-MIT](third-party/iana-time-zone-0.1.65/LICENSE-MIT) |
| icu_collections 2.3.0 | Unicode-3.0 | [LICENSE](third-party/icu_collections-2.3.0/LICENSE) |
| icu_locale_core 2.3.0 | Unicode-3.0 | [LICENSE](third-party/icu_locale_core-2.3.0/LICENSE) |
| icu_normalizer 2.3.0 | Unicode-3.0 | [LICENSE](third-party/icu_normalizer-2.3.0/LICENSE) |
| icu_normalizer_data 2.3.0 | Unicode-3.0 | [LICENSE](third-party/icu_normalizer_data-2.3.0/LICENSE) |
| icu_properties 2.3.0 | Unicode-3.0 | [LICENSE](third-party/icu_properties-2.3.0/LICENSE) |
| icu_properties_data 2.3.0 | Unicode-3.0 | [LICENSE](third-party/icu_properties_data-2.3.0/LICENSE) |
| icu_provider 2.3.1 | Unicode-3.0 | [LICENSE](third-party/icu_provider-2.3.1/LICENSE) |
| idna 1.1.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/idna-1.1.0/LICENSE-APACHE), [LICENSE-MIT](third-party/idna-1.1.0/LICENSE-MIT) |
| idna_adapter 1.2.2 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/idna_adapter-1.2.2/LICENSE-APACHE), [LICENSE-MIT](third-party/idna_adapter-1.2.2/LICENSE-MIT) |
| indexmap 2.14.2 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/indexmap-2.14.2/LICENSE-APACHE), [LICENSE-MIT](third-party/indexmap-2.14.2/LICENSE-MIT) |
| inout 0.1.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/inout-0.1.4/LICENSE-APACHE), [LICENSE-MIT](third-party/inout-0.1.4/LICENSE-MIT) |
| ipnet 2.12.2 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/ipnet-2.12.2/LICENSE-APACHE), [LICENSE-MIT](third-party/ipnet-2.12.2/LICENSE-MIT) |
| itoa 1.0.18 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/itoa-1.0.18/LICENSE-APACHE), [LICENSE-MIT](third-party/itoa-1.0.18/LICENSE-MIT) |
| lazy_static 1.5.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/lazy_static-1.5.0/LICENSE-APACHE), [LICENSE-MIT](third-party/lazy_static-1.5.0/LICENSE-MIT) |
| libc 0.2.189 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/libc-0.2.189/LICENSE-APACHE), [LICENSE-MIT](third-party/libc-0.2.189/LICENSE-MIT) |
| libm 0.2.16 | MIT | [LICENSE.txt](third-party/libm-0.2.16/LICENSE.txt) |
| libsqlite3-sys 0.30.1 | MIT | [LICENSE](third-party/libsqlite3-sys-0.30.1/LICENSE) |
| linux-raw-sys 0.12.1 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [COPYRIGHT](third-party/linux-raw-sys-0.12.1/COPYRIGHT), [LICENSE-APACHE](third-party/linux-raw-sys-0.12.1/LICENSE-APACHE), [LICENSE-Apache-2.0_WITH_LLVM-exception](third-party/linux-raw-sys-0.12.1/LICENSE-Apache-2.0_WITH_LLVM-exception), [LICENSE-MIT](third-party/linux-raw-sys-0.12.1/LICENSE-MIT) |
| litemap 0.8.3 | Unicode-3.0 | [LICENSE](third-party/litemap-0.8.3/LICENSE) |
| lock_api 0.4.14 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/lock_api-0.4.14/LICENSE-APACHE), [LICENSE-MIT](third-party/lock_api-0.4.14/LICENSE-MIT) |
| log 0.4.34 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/log-0.4.34/LICENSE-APACHE), [LICENSE-MIT](third-party/log-0.4.34/LICENSE-MIT) |
| lru-slab 0.1.2 | MIT OR Apache-2.0 OR Zlib | [LICENSE-APACHE](third-party/lru-slab-0.1.2/LICENSE-APACHE), [LICENSE-MIT](third-party/lru-slab-0.1.2/LICENSE-MIT), [LICENSE-ZLIB](third-party/lru-slab-0.1.2/LICENSE-ZLIB) |
| matchit 0.8.4 | MIT AND BSD-3-Clause | [LICENSE](third-party/matchit-0.8.4/LICENSE), [LICENSE.httprouter](third-party/matchit-0.8.4/LICENSE.httprouter) |
| md-5 0.10.6 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/md-5-0.10.6/LICENSE-APACHE), [LICENSE-MIT](third-party/md-5-0.10.6/LICENSE-MIT) |
| memchr 2.8.3 | Unlicense OR MIT | [COPYING](third-party/memchr-2.8.3/COPYING), [LICENSE-MIT](third-party/memchr-2.8.3/LICENSE-MIT) |
| mime 0.3.17 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/mime-0.3.17/LICENSE-APACHE), [LICENSE-MIT](third-party/mime-0.3.17/LICENSE-MIT) |
| miniz_oxide 0.9.1 | MIT OR Zlib OR Apache-2.0 | [LICENSE](third-party/miniz_oxide-0.9.1/LICENSE), [LICENSE-APACHE.md](third-party/miniz_oxide-0.9.1/LICENSE-APACHE.md), [LICENSE-MIT.md](third-party/miniz_oxide-0.9.1/LICENSE-MIT.md), [LICENSE-ZLIB.md](third-party/miniz_oxide-0.9.1/LICENSE-ZLIB.md) |
| mio 1.2.3 | MIT | [LICENSE](third-party/mio-1.2.3/LICENSE) |
| num-bigint-dig 0.8.6 | MIT/Apache-2.0 | [LICENSE-APACHE](third-party/num-bigint-dig-0.8.6/LICENSE-APACHE), [LICENSE-MIT](third-party/num-bigint-dig-0.8.6/LICENSE-MIT) |
| num-integer 0.1.47 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/num-integer-0.1.47/LICENSE-APACHE), [LICENSE-MIT](third-party/num-integer-0.1.47/LICENSE-MIT) |
| num-iter 0.1.46 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/num-iter-0.1.46/LICENSE-APACHE), [LICENSE-MIT](third-party/num-iter-0.1.46/LICENSE-MIT) |
| num-traits 0.2.19 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/num-traits-0.2.19/LICENSE-APACHE), [LICENSE-MIT](third-party/num-traits-0.2.19/LICENSE-MIT) |
| once_cell 1.21.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/once_cell-1.21.4/LICENSE-APACHE), [LICENSE-MIT](third-party/once_cell-1.21.4/LICENSE-MIT) |
| opaque-debug 0.3.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/opaque-debug-0.3.1/LICENSE-APACHE), [LICENSE-MIT](third-party/opaque-debug-0.3.1/LICENSE-MIT) |
| parking 2.2.1 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/parking-2.2.1/LICENSE-APACHE), [LICENSE-MIT](third-party/parking-2.2.1/LICENSE-MIT), [LICENSE-THIRD-PARTY](third-party/parking-2.2.1/LICENSE-THIRD-PARTY) |
| parking_lot 0.12.5 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/parking_lot-0.12.5/LICENSE-APACHE), [LICENSE-MIT](third-party/parking_lot-0.12.5/LICENSE-MIT) |
| parking_lot_core 0.9.12 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/parking_lot_core-0.9.12/LICENSE-APACHE), [LICENSE-MIT](third-party/parking_lot_core-0.9.12/LICENSE-MIT) |
| pem-rfc7468 0.7.0 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/pem-rfc7468-0.7.0/LICENSE-APACHE), [LICENSE-MIT](third-party/pem-rfc7468-0.7.0/LICENSE-MIT) |
| percent-encoding 2.3.2 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/percent-encoding-2.3.2/LICENSE-APACHE), [LICENSE-MIT](third-party/percent-encoding-2.3.2/LICENSE-MIT) |
| pin-project-lite 0.2.17 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/pin-project-lite-0.2.17/LICENSE-APACHE), [LICENSE-MIT](third-party/pin-project-lite-0.2.17/LICENSE-MIT) |
| pkcs1 0.7.5 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/pkcs1-0.7.5/LICENSE-APACHE), [LICENSE-MIT](third-party/pkcs1-0.7.5/LICENSE-MIT) |
| pkcs8 0.10.2 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/pkcs8-0.10.2/LICENSE-APACHE), [LICENSE-MIT](third-party/pkcs8-0.10.2/LICENSE-MIT) |
| pkg-config 0.3.34 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/pkg-config-0.3.34/LICENSE-APACHE), [LICENSE-MIT](third-party/pkg-config-0.3.34/LICENSE-MIT) |
| polyval 0.6.2 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/polyval-0.6.2/LICENSE-APACHE), [LICENSE-MIT](third-party/polyval-0.6.2/LICENSE-MIT) |
| potential_utf 0.1.6 | Unicode-3.0 | [LICENSE](third-party/potential_utf-0.1.6/LICENSE) |
| ppv-lite86 0.2.21 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/ppv-lite86-0.2.21/LICENSE-APACHE), [LICENSE-MIT](third-party/ppv-lite86-0.2.21/LICENSE-MIT) |
| proc-macro-crate 3.5.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/proc-macro-crate-3.5.0/LICENSE-APACHE), [LICENSE-MIT](third-party/proc-macro-crate-3.5.0/LICENSE-MIT) |
| proc-macro2 1.0.107 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/proc-macro2-1.0.107/LICENSE-APACHE), [LICENSE-MIT](third-party/proc-macro2-1.0.107/LICENSE-MIT) |
| quinn 0.11.11 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/quinn-0.11.11/LICENSE-APACHE), [LICENSE-MIT](third-party/quinn-0.11.11/LICENSE-MIT) |
| quinn-proto 0.11.17 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/quinn-proto-0.11.17/LICENSE-APACHE), [LICENSE-MIT](third-party/quinn-proto-0.11.17/LICENSE-MIT) |
| quinn-udp 0.5.15 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/quinn-udp-0.5.15/LICENSE-APACHE), [LICENSE-MIT](third-party/quinn-udp-0.5.15/LICENSE-MIT) |
| quote 1.0.47 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/quote-1.0.47/LICENSE-APACHE), [LICENSE-MIT](third-party/quote-1.0.47/LICENSE-MIT) |
| rand 0.10.2 | MIT OR Apache-2.0 | [COPYRIGHT](third-party/rand-0.10.2/COPYRIGHT), [LICENSE-APACHE](third-party/rand-0.10.2/LICENSE-APACHE), [LICENSE-MIT](third-party/rand-0.10.2/LICENSE-MIT) |
| rand 0.8.8 | MIT OR Apache-2.0 | [COPYRIGHT](third-party/rand-0.8.8/COPYRIGHT), [LICENSE-APACHE](third-party/rand-0.8.8/LICENSE-APACHE), [LICENSE-MIT](third-party/rand-0.8.8/LICENSE-MIT) |
| rand 0.9.5 | MIT OR Apache-2.0 | [COPYRIGHT](third-party/rand-0.9.5/COPYRIGHT), [LICENSE-APACHE](third-party/rand-0.9.5/LICENSE-APACHE), [LICENSE-MIT](third-party/rand-0.9.5/LICENSE-MIT) |
| rand_chacha 0.3.1 | MIT OR Apache-2.0 | [COPYRIGHT](third-party/rand_chacha-0.3.1/COPYRIGHT), [LICENSE-APACHE](third-party/rand_chacha-0.3.1/LICENSE-APACHE), [LICENSE-MIT](third-party/rand_chacha-0.3.1/LICENSE-MIT) |
| rand_chacha 0.9.0 | MIT OR Apache-2.0 | [COPYRIGHT](third-party/rand_chacha-0.9.0/COPYRIGHT), [LICENSE-APACHE](third-party/rand_chacha-0.9.0/LICENSE-APACHE), [LICENSE-MIT](third-party/rand_chacha-0.9.0/LICENSE-MIT) |
| rand_core 0.10.1 | MIT OR Apache-2.0 | [COPYRIGHT](third-party/rand_core-0.10.1/COPYRIGHT), [LICENSE-APACHE](third-party/rand_core-0.10.1/LICENSE-APACHE), [LICENSE-MIT](third-party/rand_core-0.10.1/LICENSE-MIT) |
| rand_core 0.6.4 | MIT OR Apache-2.0 | [COPYRIGHT](third-party/rand_core-0.6.4/COPYRIGHT), [LICENSE-APACHE](third-party/rand_core-0.6.4/LICENSE-APACHE), [LICENSE-MIT](third-party/rand_core-0.6.4/LICENSE-MIT) |
| rand_core 0.9.5 | MIT OR Apache-2.0 | [COPYRIGHT](third-party/rand_core-0.9.5/COPYRIGHT), [LICENSE-APACHE](third-party/rand_core-0.9.5/LICENSE-APACHE), [LICENSE-MIT](third-party/rand_core-0.9.5/LICENSE-MIT) |
| rand_pcg 0.10.2 | MIT OR Apache-2.0 | [COPYRIGHT](third-party/rand_pcg-0.10.2/COPYRIGHT), [LICENSE-APACHE](third-party/rand_pcg-0.10.2/LICENSE-APACHE), [LICENSE-MIT](third-party/rand_pcg-0.10.2/LICENSE-MIT) |
| regex 1.13.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/regex-1.13.1/LICENSE-APACHE), [LICENSE-MIT](third-party/regex-1.13.1/LICENSE-MIT) |
| regex-automata 0.4.18 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/regex-automata-0.4.18/LICENSE-APACHE), [LICENSE-MIT](third-party/regex-automata-0.4.18/LICENSE-MIT) |
| regex-syntax 0.8.11 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/regex-syntax-0.8.11/LICENSE-APACHE), [LICENSE-MIT](third-party/regex-syntax-0.8.11/LICENSE-MIT) |
| reqwest 0.12.28 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/reqwest-0.12.28/LICENSE-APACHE), [LICENSE-MIT](third-party/reqwest-0.12.28/LICENSE-MIT) |
| ring 0.17.14 | Apache-2.0 AND ISC | [LICENSE](third-party/ring-0.17.14/LICENSE), [LICENSE-BoringSSL](third-party/ring-0.17.14/LICENSE-BoringSSL), [LICENSE-other-bits](third-party/ring-0.17.14/LICENSE-other-bits) |
| rsa 0.9.10 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/rsa-0.9.10/LICENSE-APACHE), [LICENSE-MIT](third-party/rsa-0.9.10/LICENSE-MIT) |
| rustc-hash 2.1.3 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/rustc-hash-2.1.3/LICENSE-APACHE), [LICENSE-MIT](third-party/rustc-hash-2.1.3/LICENSE-MIT) |
| rustix 1.1.4 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [COPYRIGHT](third-party/rustix-1.1.4/COPYRIGHT), [LICENSE-APACHE](third-party/rustix-1.1.4/LICENSE-APACHE), [LICENSE-Apache-2.0_WITH_LLVM-exception](third-party/rustix-1.1.4/LICENSE-Apache-2.0_WITH_LLVM-exception), [LICENSE-MIT](third-party/rustix-1.1.4/LICENSE-MIT) |
| rustls 0.23.44 | Apache-2.0 OR ISC OR MIT | [LICENSE-APACHE](third-party/rustls-0.23.44/LICENSE-APACHE), [LICENSE-ISC](third-party/rustls-0.23.44/LICENSE-ISC), [LICENSE-MIT](third-party/rustls-0.23.44/LICENSE-MIT) |
| rustls-pki-types 1.15.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/rustls-pki-types-1.15.1/LICENSE-APACHE), [LICENSE-MIT](third-party/rustls-pki-types-1.15.1/LICENSE-MIT) |
| rustls-webpki 0.103.15 | ISC | [LICENSE](third-party/rustls-webpki-0.103.15/LICENSE) |
| ryu 1.0.23 | Apache-2.0 OR BSL-1.0 | [LICENSE-APACHE](third-party/ryu-1.0.23/LICENSE-APACHE), [LICENSE-BOOST](third-party/ryu-1.0.23/LICENSE-BOOST) |
| scopeguard 1.2.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/scopeguard-1.2.0/LICENSE-APACHE), [LICENSE-MIT](third-party/scopeguard-1.2.0/LICENSE-MIT) |
| serde 1.0.229 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/serde-1.0.229/LICENSE-APACHE), [LICENSE-MIT](third-party/serde-1.0.229/LICENSE-MIT) |
| serde_core 1.0.229 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/serde_core-1.0.229/LICENSE-APACHE), [LICENSE-MIT](third-party/serde_core-1.0.229/LICENSE-MIT) |
| serde_derive 1.0.229 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/serde_derive-1.0.229/LICENSE-APACHE), [LICENSE-MIT](third-party/serde_derive-1.0.229/LICENSE-MIT) |
| serde_json 1.0.151 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/serde_json-1.0.151/LICENSE-APACHE), [LICENSE-MIT](third-party/serde_json-1.0.151/LICENSE-MIT) |
| serde_path_to_error 0.1.20 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/serde_path_to_error-0.1.20/LICENSE-APACHE), [LICENSE-MIT](third-party/serde_path_to_error-0.1.20/LICENSE-MIT) |
| serde_spanned 1.1.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/serde_spanned-1.1.1/LICENSE-APACHE), [LICENSE-MIT](third-party/serde_spanned-1.1.1/LICENSE-MIT) |
| serde_urlencoded 0.7.1 | MIT/Apache-2.0 | [LICENSE-APACHE](third-party/serde_urlencoded-0.7.1/LICENSE-APACHE), [LICENSE-MIT](third-party/serde_urlencoded-0.7.1/LICENSE-MIT) |
| serde_yaml_ng 0.10.0 | MIT | [LICENSE](third-party/serde_yaml_ng-0.10.0/LICENSE) |
| sha1 0.10.7 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/sha1-0.10.7/LICENSE-APACHE), [LICENSE-MIT](third-party/sha1-0.10.7/LICENSE-MIT) |
| sha2 0.10.9 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/sha2-0.10.9/LICENSE-APACHE), [LICENSE-MIT](third-party/sha2-0.10.9/LICENSE-MIT) |
| sha2 0.11.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/sha2-0.11.0/LICENSE-APACHE), [LICENSE-MIT](third-party/sha2-0.11.0/LICENSE-MIT) |
| shlex 2.0.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/shlex-2.0.1/LICENSE-APACHE), [LICENSE-MIT](third-party/shlex-2.0.1/LICENSE-MIT) |
| signal-hook-registry 1.4.8 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/signal-hook-registry-1.4.8/LICENSE-APACHE), [LICENSE-MIT](third-party/signal-hook-registry-1.4.8/LICENSE-MIT) |
| signature 2.2.0 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/signature-2.2.0/LICENSE-APACHE), [LICENSE-MIT](third-party/signature-2.2.0/LICENSE-MIT) |
| simd-adler32 0.3.10 | MIT | [LICENSE.md](third-party/simd-adler32-0.3.10/LICENSE.md) |
| siphasher 1.0.4 | MIT OR Apache-2.0 | [COPYING](third-party/siphasher-1.0.4/COPYING), [LICENSE-APACHE](third-party/siphasher-1.0.4/LICENSE-APACHE), [LICENSE-MIT](third-party/siphasher-1.0.4/LICENSE-MIT) |
| slab 0.4.12 | MIT | [LICENSE](third-party/slab-0.4.12/LICENSE) |
| smallvec 1.16.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/smallvec-1.16.1/LICENSE-APACHE), [LICENSE-MIT](third-party/smallvec-1.16.1/LICENSE-MIT) |
| socket2 0.6.5 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/socket2-0.6.5/LICENSE-APACHE), [LICENSE-MIT](third-party/socket2-0.6.5/LICENSE-MIT) |
| spin 0.9.9 | MIT | [LICENSE](third-party/spin-0.9.9/LICENSE) |
| spki 0.7.3 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/spki-0.7.3/LICENSE-APACHE), [LICENSE-MIT](third-party/spki-0.7.3/LICENSE-MIT) |
| sqlx 0.8.6 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/sqlx-0.8.6/LICENSE-APACHE), [LICENSE-MIT](third-party/sqlx-0.8.6/LICENSE-MIT) |
| sqlx-core 0.8.6 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/sqlx-core-0.8.6/LICENSE-APACHE), [LICENSE-MIT](third-party/sqlx-core-0.8.6/LICENSE-MIT) |
| sqlx-macros 0.8.6 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/sqlx-macros-0.8.6/LICENSE-APACHE), [LICENSE-MIT](third-party/sqlx-macros-0.8.6/LICENSE-MIT) |
| sqlx-macros-core 0.8.6 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/sqlx-macros-core-0.8.6/LICENSE-APACHE), [LICENSE-MIT](third-party/sqlx-macros-core-0.8.6/LICENSE-MIT) |
| sqlx-mysql 0.8.6 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/sqlx-mysql-0.8.6/LICENSE-APACHE), [LICENSE-MIT](third-party/sqlx-mysql-0.8.6/LICENSE-MIT) |
| sqlx-postgres 0.8.6 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/sqlx-postgres-0.8.6/LICENSE-APACHE), [LICENSE-MIT](third-party/sqlx-postgres-0.8.6/LICENSE-MIT) |
| sqlx-sqlite 0.8.6 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/sqlx-sqlite-0.8.6/LICENSE-APACHE), [LICENSE-MIT](third-party/sqlx-sqlite-0.8.6/LICENSE-MIT) |
| stable_deref_trait 1.2.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/stable_deref_trait-1.2.1/LICENSE-APACHE), [LICENSE-MIT](third-party/stable_deref_trait-1.2.1/LICENSE-MIT) |
| stringprep 0.1.5 | MIT/Apache-2.0 | [LICENSE-APACHE](third-party/stringprep-0.1.5/LICENSE-APACHE), [LICENSE-MIT](third-party/stringprep-0.1.5/LICENSE-MIT) |
| subfeature 1.30.1 | MIT | [LICENSE](third-party/subfeature-1.30.1/LICENSE) |
| subtle 2.6.1 | BSD-3-Clause | [LICENSE](third-party/subtle-2.6.1/LICENSE) |
| syn 2.0.119 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/syn-2.0.119/LICENSE-APACHE), [LICENSE-MIT](third-party/syn-2.0.119/LICENSE-MIT) |
| syn 3.0.6 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/syn-3.0.6/LICENSE-APACHE), [LICENSE-MIT](third-party/syn-3.0.6/LICENSE-MIT) |
| sync_wrapper 1.0.2 | Apache-2.0 | [LICENSE](third-party/sync_wrapper-1.0.2/LICENSE) |
| synstructure 0.13.2 | MIT | [LICENSE](third-party/synstructure-0.13.2/LICENSE) |
| tar 0.4.46 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/tar-0.4.46/LICENSE-APACHE), [LICENSE-MIT](third-party/tar-0.4.46/LICENSE-MIT) |
| thiserror 2.0.20 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/thiserror-2.0.20/LICENSE-APACHE), [LICENSE-MIT](third-party/thiserror-2.0.20/LICENSE-MIT) |
| thiserror-impl 2.0.20 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/thiserror-impl-2.0.20/LICENSE-APACHE), [LICENSE-MIT](third-party/thiserror-impl-2.0.20/LICENSE-MIT) |
| tinystr 0.8.4 | Unicode-3.0 | [LICENSE](third-party/tinystr-0.8.4/LICENSE) |
| tinyvec 1.13.2 | Zlib OR Apache-2.0 OR MIT | [LICENSE-APACHE.md](third-party/tinyvec-1.13.2/LICENSE-APACHE.md), [LICENSE-MIT.md](third-party/tinyvec-1.13.2/LICENSE-MIT.md), [LICENSE-ZLIB.md](third-party/tinyvec-1.13.2/LICENSE-ZLIB.md) |
| tinyvec_macros 0.1.1 | MIT OR Apache-2.0 OR Zlib | [LICENSE-APACHE.md](third-party/tinyvec_macros-0.1.1/LICENSE-APACHE.md), [LICENSE-MIT.md](third-party/tinyvec_macros-0.1.1/LICENSE-MIT.md), [LICENSE-ZLIB.md](third-party/tinyvec_macros-0.1.1/LICENSE-ZLIB.md) |
| tokio 1.53.1 | MIT | [LICENSE](third-party/tokio-1.53.1/LICENSE) |
| tokio-macros 2.7.2 | MIT | [LICENSE](third-party/tokio-macros-2.7.2/LICENSE) |
| tokio-rustls 0.26.5 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/tokio-rustls-0.26.5/LICENSE-APACHE), [LICENSE-MIT](third-party/tokio-rustls-0.26.5/LICENSE-MIT) |
| tokio-stream 0.1.19 | MIT | [LICENSE](third-party/tokio-stream-0.1.19/LICENSE) |
| tokio-tungstenite 0.28.0 | MIT | [LICENSE](third-party/tokio-tungstenite-0.28.0/LICENSE) |
| tokio-util 0.7.19 | MIT | [LICENSE](third-party/tokio-util-0.7.19/LICENSE) |
| toml 1.1.6+spec-1.1.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/toml-1.1.6_spec-1.1.0/LICENSE-APACHE), [LICENSE-MIT](third-party/toml-1.1.6_spec-1.1.0/LICENSE-MIT) |
| toml_datetime 1.1.1+spec-1.1.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/toml_datetime-1.1.1_spec-1.1.0/LICENSE-APACHE), [LICENSE-MIT](third-party/toml_datetime-1.1.1_spec-1.1.0/LICENSE-MIT) |
| toml_edit 0.25.15+spec-1.1.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/toml_edit-0.25.15_spec-1.1.0/LICENSE-APACHE), [LICENSE-MIT](third-party/toml_edit-0.25.15_spec-1.1.0/LICENSE-MIT) |
| toml_parser 1.1.3+spec-1.1.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/toml_parser-1.1.3_spec-1.1.0/LICENSE-APACHE), [LICENSE-MIT](third-party/toml_parser-1.1.3_spec-1.1.0/LICENSE-MIT) |
| toml_writer 1.1.2+spec-1.1.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/toml_writer-1.1.2_spec-1.1.0/LICENSE-APACHE), [LICENSE-MIT](third-party/toml_writer-1.1.2_spec-1.1.0/LICENSE-MIT) |
| topcoat 0.9.0 | MIT | [LICENSE](third-party/topcoat-0.9.0/LICENSE) |
| topcoat-asset 0.9.0 | MIT | [LICENSE](third-party/topcoat-asset-0.9.0/LICENSE) |
| topcoat-core 0.9.0 | MIT | [LICENSE](third-party/topcoat-core-0.9.0/LICENSE) |
| topcoat-core-grammar 0.9.0 | MIT | [LICENSE](third-party/topcoat-core-grammar-0.9.0/LICENSE) |
| topcoat-core-macro 0.9.0 | MIT | [LICENSE](third-party/topcoat-core-macro-0.9.0/LICENSE) |
| topcoat-font 0.9.0 | MIT | [LICENSE](third-party/topcoat-font-0.9.0/LICENSE) |
| topcoat-view 0.9.0 | MIT | [LICENSE](third-party/topcoat-view-0.9.0/LICENSE) |
| topcoat-view-grammar 0.9.0 | MIT | [LICENSE](third-party/topcoat-view-grammar-0.9.0/LICENSE) |
| topcoat-view-macro 0.9.0 | MIT | [LICENSE](third-party/topcoat-view-macro-0.9.0/LICENSE) |
| tower 0.5.3 | MIT | [LICENSE](third-party/tower-0.5.3/LICENSE) |
| tower-http 0.6.11 | MIT | [LICENSE](third-party/tower-http-0.6.11/LICENSE) |
| tower-layer 0.3.3 | MIT | [LICENSE](third-party/tower-layer-0.3.3/LICENSE) |
| tower-service 0.3.3 | MIT | [LICENSE](third-party/tower-service-0.3.3/LICENSE) |
| tracing 0.1.44 | MIT | [LICENSE](third-party/tracing-0.1.44/LICENSE) |
| tracing-attributes 0.1.31 | MIT | [LICENSE](third-party/tracing-attributes-0.1.31/LICENSE) |
| tracing-core 0.1.36 | MIT | [LICENSE](third-party/tracing-core-0.1.36/LICENSE) |
| try-lock 0.2.5 | MIT | [LICENSE](third-party/try-lock-0.2.5/LICENSE) |
| tungstenite 0.28.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/tungstenite-0.28.0/LICENSE-APACHE), [LICENSE-MIT](third-party/tungstenite-0.28.0/LICENSE-MIT) |
| typenum 1.20.1 | MIT OR Apache-2.0 | [LICENSE](third-party/typenum-1.20.1/LICENSE), [LICENSE-APACHE](third-party/typenum-1.20.1/LICENSE-APACHE), [LICENSE-MIT](third-party/typenum-1.20.1/LICENSE-MIT) |
| unicode-bidi 0.3.18 | MIT OR Apache-2.0 | [COPYRIGHT](third-party/unicode-bidi-0.3.18/COPYRIGHT), [LICENSE-APACHE](third-party/unicode-bidi-0.3.18/LICENSE-APACHE), [LICENSE-MIT](third-party/unicode-bidi-0.3.18/LICENSE-MIT) |
| unicode-ident 1.0.24 | (MIT OR Apache-2.0) AND Unicode-3.0 | [LICENSE-APACHE](third-party/unicode-ident-1.0.24/LICENSE-APACHE), [LICENSE-MIT](third-party/unicode-ident-1.0.24/LICENSE-MIT), [LICENSE-UNICODE](third-party/unicode-ident-1.0.24/LICENSE-UNICODE) |
| unicode-normalization 0.1.25 | MIT OR Apache-2.0 | [COPYRIGHT](third-party/unicode-normalization-0.1.25/COPYRIGHT), [LICENSE-APACHE](third-party/unicode-normalization-0.1.25/LICENSE-APACHE), [LICENSE-MIT](third-party/unicode-normalization-0.1.25/LICENSE-MIT) |
| unicode-properties 0.1.4 | MIT/Apache-2.0 | [COPYRIGHT](third-party/unicode-properties-0.1.4/COPYRIGHT), [LICENSE-APACHE](third-party/unicode-properties-0.1.4/LICENSE-APACHE), [LICENSE-MIT](third-party/unicode-properties-0.1.4/LICENSE-MIT) |
| universal-hash 0.5.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/universal-hash-0.5.1/LICENSE-APACHE), [LICENSE-MIT](third-party/universal-hash-0.5.1/LICENSE-MIT) |
| unsafe-libyaml 0.2.11 | MIT | [LICENSE-MIT](third-party/unsafe-libyaml-0.2.11/LICENSE-MIT) |
| untrusted 0.9.0 | ISC | [LICENSE.txt](third-party/untrusted-0.9.0/LICENSE.txt) |
| url 2.5.8 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/url-2.5.8/LICENSE-APACHE), [LICENSE-MIT](third-party/url-2.5.8/LICENSE-MIT) |
| utf-8 0.7.6 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/utf-8-0.7.6/LICENSE-APACHE), [LICENSE-MIT](third-party/utf-8-0.7.6/LICENSE-MIT) |
| utf8_iter 1.0.4 | Apache-2.0 OR MIT | [COPYRIGHT](third-party/utf8_iter-1.0.4/COPYRIGHT), [LICENSE-APACHE](third-party/utf8_iter-1.0.4/LICENSE-APACHE), [LICENSE-MIT](third-party/utf8_iter-1.0.4/LICENSE-MIT) |
| utoipa 5.5.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/utoipa-5.5.0/LICENSE-APACHE), [LICENSE-MIT](third-party/utoipa-5.5.0/LICENSE-MIT) |
| utoipa-gen 5.5.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/utoipa-gen-5.5.0/LICENSE-APACHE), [LICENSE-MIT](third-party/utoipa-gen-5.5.0/LICENSE-MIT) |
| uuid 1.26.1 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/uuid-1.26.1/LICENSE-APACHE), [LICENSE-MIT](third-party/uuid-1.26.1/LICENSE-MIT) |
| vcpkg 0.2.15 | MIT/Apache-2.0 | [LICENSE-APACHE](third-party/vcpkg-0.2.15/LICENSE-APACHE), [LICENSE-MIT](third-party/vcpkg-0.2.15/LICENSE-MIT) |
| version_check 0.9.5 | MIT/Apache-2.0 | [LICENSE-APACHE](third-party/version_check-0.9.5/LICENSE-APACHE), [LICENSE-MIT](third-party/version_check-0.9.5/LICENSE-MIT) |
| want 0.3.1 | MIT | [LICENSE](third-party/want-0.3.1/LICENSE) |
| webpki-roots 0.26.11 | CDLA-Permissive-2.0 | [LICENSE](third-party/webpki-roots-0.26.11/LICENSE) |
| webpki-roots 1.0.9 | CDLA-Permissive-2.0 | [LICENSE](third-party/webpki-roots-1.0.9/LICENSE) |
| whoami 1.6.1 | Apache-2.0 OR BSL-1.0 OR MIT | [LICENSE_APACHE](third-party/whoami-1.6.1/LICENSE_APACHE), [LICENSE_BOOST](third-party/whoami-1.6.1/LICENSE_BOOST), [LICENSE_MIT](third-party/whoami-1.6.1/LICENSE_MIT) |
| winnow 1.0.4 | MIT | [LICENSE-MIT](third-party/winnow-1.0.4/LICENSE-MIT) |
| writeable 0.6.4 | Unicode-3.0 | [LICENSE](third-party/writeable-0.6.4/LICENSE) |
| xattr 1.6.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/xattr-1.6.1/LICENSE-APACHE), [LICENSE-MIT](third-party/xattr-1.6.1/LICENSE-MIT) |
| yoke 0.8.3 | Unicode-3.0 | [LICENSE](third-party/yoke-0.8.3/LICENSE) |
| yoke-derive 0.8.2 | Unicode-3.0 | [LICENSE](third-party/yoke-derive-0.8.2/LICENSE) |
| zerocopy 0.8.57 | BSD-2-Clause OR Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/zerocopy-0.8.57/LICENSE-APACHE), [LICENSE-BSD](third-party/zerocopy-0.8.57/LICENSE-BSD), [LICENSE-MIT](third-party/zerocopy-0.8.57/LICENSE-MIT) |
| zerofrom 0.1.8 | Unicode-3.0 | [LICENSE](third-party/zerofrom-0.1.8/LICENSE) |
| zerofrom-derive 0.1.7 | Unicode-3.0 | [LICENSE](third-party/zerofrom-derive-0.1.7/LICENSE) |
| zeroize 1.9.0 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/zeroize-1.9.0/LICENSE-APACHE), [LICENSE-MIT](third-party/zeroize-1.9.0/LICENSE-MIT) |
| zerotrie 0.2.5 | Unicode-3.0 | [LICENSE](third-party/zerotrie-0.2.5/LICENSE) |
| zerovec 0.11.8 | Unicode-3.0 | [LICENSE](third-party/zerovec-0.11.8/LICENSE) |
| zerovec-derive 0.11.6 | Unicode-3.0 | [LICENSE](third-party/zerovec-derive-0.11.6/LICENSE) |
| zlib-rs 0.6.7 | Zlib | [LICENSE](third-party/zlib-rs-0.6.7/LICENSE) |
| zmij 1.0.23 | MIT | [LICENSE-MIT](third-party/zmij-1.0.23/LICENSE-MIT) |
