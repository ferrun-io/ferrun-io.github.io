# Security

Ferrun v0.0.1 is an early preview. It executes workflow code with the executor account's OS permissions and provides no workload sandbox. Use trusted workflows and machines appropriate for the repository's code and secrets. Qualifying one native archive does not establish compatibility or isolation for arbitrary workflows, providers, or later builds.

## Report a vulnerability privately

Use this repository's **Security → Advisories → Report a vulnerability** flow when private reporting is enabled. Include the affected commit or release, platform, a minimal reproduction, and the impact. If that control is unavailable, do not put credential exposure details in a public issue; request a private reporting channel first.

Do not attach real App keys, enrollment tokens, executor credentials, database URLs, signing keys, or customer workflow secrets. Sanitized status codes and the smallest necessary reproduction are sufficient to start a report.

## Credential boundaries

The company App key and Ferrun management authority belong on the trusted control-plane server. Employees receive only credentials for pools the company permits them to use. A pool credential can admit machines up to that pool's capacity; it is bearer authority, not an individual employee login or an identity-provider policy.

Executors receive separate machine credentials and retain private restart state. Protect that state like other service credentials. Use HTTPS between machines and control planes; plaintext HTTP is permitted only for actual loopback endpoints. The server's TLS endpoint is provided by the operator's hosting environment.

The GitHub App installation limits repository access. An employee's independent control plane needs separately approved GitHub authority for its own repositories. Running a personal control plane does not turn an employer's pool credential into an App key or repository-administration permission.

For setup and key rotation, use the [App guide](docs/github-app-setup.md) and [company setup guide](docs/company-setup.md). This preview has no automatic protocol repair or general in-place state migration. Follow the [recovery contract](docs/reporting.md) before replacing a deployment or retrying an uncertain interrupted job.
