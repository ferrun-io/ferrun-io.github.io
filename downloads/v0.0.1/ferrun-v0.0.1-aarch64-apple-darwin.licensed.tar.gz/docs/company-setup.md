# Company servers and employee executors

This guide describes the `v0.0.1` setup flow. Choose a release whose qualification evidence matches your native platform; compilation alone does not establish GitHub compatibility.

A company administrator authorizes a company-owned GitHub App. The company control plane keeps its key and registers runners automatically. Employees receive only Ferrun pool credentials and run executors; they need no GitHub repository administrator role. Independent personal deployments use separately authorized Apps and repositories.

## 1. Administrator: authorize GitHub and prepare the server

Follow the complete [GitHub App click-through guide](github-app-setup.md). Install the App on **Only select repositories**, choosing the repositories approved for these machines. Ordinary server operation needs **Administration: Read and write** and GitHub's mandatory metadata access. Keep the downloaded private key in the company's server-side secret storage.

Follow [Download and install](install.md) for the server's OS and architecture, including the checksum check. The server needs PostgreSQL: supply `DATABASE_URL` in the service environment before first setup, or let setup start PostgreSQL using an already installed Docker service. The database must be dedicated to this Ferrun installation, with a role allowed to create its tables. A server-only installation does not need Git, Node, or the GitHub CLI.

Provide an HTTPS endpoint through your existing hosting environment or TLS reverse proxy. Ferrun's local API defaults to `127.0.0.1:8788`; the proxy forwards to that loopback listener and must preserve the `Authorization` header. Employees use the HTTPS address. Check `https://YOUR_SERVER/health` from an employee network: a healthy server returns HTTP 204 with no body. TLS and domain provisioning belong to your hosting environment; Ferrun does not request a certificate. Customer machines need outbound connections and do not need a public inbound job-delivery port.

## 2. Administrator: configure and run the control plane

On Linux or macOS, run these commands from the extracted bundle:

```sh
./ferrun setup --mode server --repo acme/service --app-id 12345 --app-key /private/secrets/ferrun.pem --label ferrun-company-test --capacity 10 # Configure the company App and a pool admitting up to ten employee executors.
./ferrun run # Keep only the control plane running in the foreground while employee machines provide execution capacity.
```

On Windows, use the matching `.exe` programs:

```powershell
.\ferrun.exe setup --mode server --repo acme/service --app-id 12345 --app-key C:\Private\Secrets\ferrun.pem --label ferrun-company-test --capacity 10 # Configure the company-owned App using its private server key file.
.\ferrun.exe run # Run the control plane without starting an executor or requiring an employee GitHub login.
```

Replace the repository, App ID, and key path with the approved values. Keep the key file readable only by the service account and authorized administrators. Ferrun records its logical path so a secret manager can rotate the file at that path. Never give this key or the Ferrun management token to an employee executor.

The release bundle supplies its tested GitHub runner compatibility version. Source builds must additionally supply `--runner-version VERSION`. Use `--port` and `--database-port` when the default local listeners are already in use.

Successful `setup` saves configuration and checks the local controller and database; it does not register a GitHub runner. First `run` creates the repository connection and pool through the management API and prints the pool ID and routing labels. GitHub registration follows when an employee executor is admitted.

The enrollment credential is retained in private `settings.json` at `/pool/enrollment_token`; it is not printed into ordinary logs. The pool ID is at `/pool/pool/id`. The operator's provisioning process reads those fields and delivers only the pool credential, ID, and public HTTPS URL through the company's secret-sharing system. For a manual handoff, open this file in a local editor on the server and copy only those pool fields. Do not share the whole file: it also contains management and database credentials.

Additional pools can be created with `POST /v1/pools` using management authority and the bundled `openapi.json`; a pool can be limited to one machine with `capacity: 1`. A pool credential is shared bootstrap authority, not an individual employee identity. Keep it within the group permitted to attach executors to that repository.

## 3. Employee: connect a machine

The company supplies three values: the HTTPS server URL, pool ID, and pool enrollment credential. The employee needs the matching Ferrun bundle, Git, and Node 24. Set `EXECUTOR_NODE24` when the required Node executable is not the `node` on PATH. Workflows using Node 20 actions also need `EXECUTOR_NODE20` or a matching installed runtime.

Have the company provisioning system supply `FERRUN_ENROLLMENT_TOKEN` to setup as an environment variable. No GitHub token, App key, management token, database, or Docker database is required on the employee's machine. For manual setup, read the credential without putting it in shell history:

```sh
printf 'Pool enrollment credential: ' # Prompt locally without including the actual credential in command history.
read -r -s FERRUN_ENROLLMENT_TOKEN # Read the company-issued value without echoing it in Bash or Zsh.
printf '\n' # Restore a readable terminal after the hidden input.
export FERRUN_ENROLLMENT_TOKEN # Supply bootstrap authority to this setup process through its environment.
```

```powershell
$env:FERRUN_ENROLLMENT_TOKEN = [System.Net.NetworkCredential]::new('', (Read-Host 'Pool enrollment credential' -AsSecureString)).Password # Read hidden input and provide only the company-issued pool token to setup.
```

From the extracted bundle, replace `POOL_ID` and the server URL with the company's values:

```sh
./ferrun setup --server https://ferrun.example.com --pool POOL_ID --name employee-laptop # Use only the company's pool-scoped credential from FERRUN_ENROLLMENT_TOKEN.
unset FERRUN_ENROLLMENT_TOKEN # Setup has saved private restart state, so the interactive shell no longer needs bootstrap authority.
./ferrun run # Start this machine's executor and reuse its privately saved identity after an ordinary restart.
```

```powershell
.\ferrun.exe setup --server https://ferrun.example.com --pool POOL_ID --name employee-laptop # Enroll using the company-provided environment credential without requesting GitHub administration access.
Remove-Item Env:FERRUN_ENROLLMENT_TOKEN # Keep the bootstrap credential out of later unrelated programs launched from this shell.
.\ferrun.exe run # Connect outward to the company control plane and retain the executor identity locally.
```

Use a distinct name per machine. Setup rejects a credential for another pool and remote plaintext HTTP. The first `run` enrolls the executor and can fail if pool capacity is exhausted. Repeating `run` reuses the existing executor credential rather than consuming another slot. A different company or pool needs another `--state-dir`.

## 4. Verify a real workflow

In the authorized GitHub repository, select **Code → Add file → Create new file**. Name it `.github/workflows/ferrun-check.yml` and paste the following, using the label printed by your server. Choose **Commit changes** and follow the repository's normal review process to put the file on its default branch:

```yaml
name: Ferrun company check # Identify the first end-to-end execution check for this installation.
on: workflow_dispatch # Run only when an authorized repository user explicitly requests the check.
jobs: # Let GitHub assign the job through the company's registered runner capacity.
  hello: # Keep the first check independent of platform-specific build tools.
    runs-on: ferrun-company-test # Match the pool label approved and configured by the company administrator.
    steps: # Exercise real command execution and reporting back to GitHub.
      - run: echo "hello from Ferrun" # Use a command understood by the supported default shells on all three operating systems.
```

Open **Actions → Ferrun company check → Run workflow**, select the branch, and click **Run workflow** in the menu. Open the new run, select the **hello** job, and expand its command step. Confirm that it finishes successfully and its logs contain `hello from Ferrun`. The dispatch button requires a `workflow_dispatch` file on the default branch and repository write access; this is distinct from repository administration. A teammate with workflow access can dispatch the check for an employee who only operates a machine. See [GitHub's manual dispatch instructions](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow).

For existing automation with workflow-dispatch authority, `gh workflow run ferrun-check.yml --repo acme/service` triggers the same check. The executor does not need that CLI or dispatch credential. Process startup and enrollment alone do not establish GitHub compatibility.

Workflow code executes as the executor's OS user. Use trusted workflows and machines appropriate for the repository's code and secrets; this preview provides no workload sandbox.

## 5. Restart, private state, and troubleshooting

Default state lives outside source checkouts:

| Host | Default location |
| --- | --- |
| Linux | `$XDG_STATE_HOME/ferrun`, or `~/.local/state/ferrun` when unset. |
| macOS | `~/Library/Application Support/Ferrun`. |
| Windows | `%LOCALAPPDATA%\Ferrun`. |

Use an explicitly private `--state-dir` for another installation or a service account without a user profile. Keep its database encryption key with its PostgreSQL data and retain executor credentials and encrypted journals for restart. [Native state fields](native-state.md) explain what is stored and which values must remain private.

Stop while idle. Ctrl-C stops only the processes started by that invocation; PostgreSQL and private state remain. The executor conservatively refuses to rerun an uncertain interrupted attempt. Review the [recovery contract](reporting.md) before restoring or replacing state.

For setup failures, check the selected App installation/repository, the server App ID/key pairing, HTTPS connectivity, the employee's pool credential, and pool capacity. Server diagnostics are in `control-plane.log`; machine diagnostics are in `executor.log`. An employee enrollment failure should be resolved through the Ferrun operator, not by granting that employee GitHub repository administration permission.

### Web dashboard

1. Keep `ferrun run` active and open **http://127.0.0.1:8788/** on the same machine. If setup used `--port`, use that port. A directly launched `control-plane` defaults to 8787.
2. Find the private `settings.json` in the state directory listed above, or your explicit `--state-dir`.
3. Sign in with only its `management_token` field. Direct controller deployments use `CONTROL_PLANE_TOKEN`. Pool and executor credentials cannot grant this access.

The dashboard is read-only: counts, up to 50 executors ordered by heartbeat, and up to 50 unfinished jobs. **Refresh** reads a new snapshot. Heartbeats and version information do not establish current connectivity or GitHub compatibility. Topcoat and CSS are embedded in the binary; no separate frontend service or JavaScript build is needed.

To browse a remote machine through SSH:

```sh
ssh -L 8788:127.0.0.1:8788 USER@LINUX_HOST # Forward the private listener to your browser's localhost without exposing the HTTP dashboard publicly.
```

Open the same local URL after connecting. Direct HTTP dashboard access requires both a loopback client connection and a loopback browser address.

For an HTTPS reverse proxy, set these values in the controller's service environment, or before `ferrun run`, on every start:

```sh
export CONTROL_PLANE_WEB_URL=https://console.example/team/ # Keep links, forms, redirects, and cookie paths under this public HTTPS mount.
export CONTROL_PLANE_TRUSTED_PROXIES=127.0.0.1,::1 # Trust only the actual proxy socket peers to report the external transport.
```

Replace the URL and source IPs with your deployment's values. For a root mount, use an HTTPS URL ending in `/`. The proxy must strip the mount prefix, preserve the original `Host` including its port and the browser's `Origin`, and **overwrite** `X-Forwarded-Proto` with the actual client scheme. Do not pass through or append a client-supplied value. Keep the backend listener private. Remote HTTP and untrusted proxy requests receive HTTP 403 before a token form is served; an HTTPS-looking `Origin` header does not authorize transport.

Sessions last eight hours and end on sign-out or controller restart. Cookie names and paths distinguish separate ports and proxy mounts; cookies never contain the management token. Browser sign-out leaves database credentials, journals, and executor identities unchanged.
