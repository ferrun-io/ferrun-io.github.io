# Test Ferrun on the local farm

Run `make test-farm` on an Apple Silicon Mac with macOS 27+, Homebrew, `uv`, and UTM installed. It installs missing controller tools, recreates missing media settings and credentials, prepares missing or stale images, and runs each target's full Rust, Python, and PostgreSQL suite sequentially. Guest shutdown and disposable storage cleanup are part of each run. The command also compares each base disk's SHA-256 before and after testing and fails if it changed.

Use `make test-farm TARGET=macos-arm64` (or `linux-arm64` / `windows-arm64`) for a focused run. Both forms share the same automatic preparation path as `make release`. No GitHub authentication is needed for these local suites. Detailed commands for ad hoc scripts, runner setup, and live comparisons remain available through `scripts/farm-test.sh --help`; `scripts/utm-test.sh` is an alias.

Linux defaults to the pinned Canonical Ubuntu 24.04 ARM64 cloud image; macOS defaults to the previously qualified Apple macOS 27 restore image. Downloads are checksum-verified. For Windows, download **English (United States) ARM64** from [Microsoft's ARM64 page](https://www.microsoft.com/en-us/software-download/windows11arm64) into `Downloads`, retaining Microsoft's filename. The script checks the supplier's English checksum, reads the actual ARM64 Pro edition index from the ISO, and downloads the signed NetKVM driver automatically. English x64 and Russian media are never selected as defaults. This browser download is necessary when Microsoft's automated ISO-link service rejects a request; it replaces manual farm configuration, checksum entry, and driver extraction.

New farm installations live in `~/Library/Application Support/Ferrun/farm`, so removing a source worktree does not remove their VM disks or credentials. `FERRUN_FARM_DIR` selects another location. An existing checkout-local `.cache/farm` is reused for compatibility. The shell wrapper and Python controller resolve the same directory. Saved custom media selections remain authoritative; an empty farm reconstructs defaults.

The harness starts an installed guest, connects through SSH or WinRM, transfers the current checkout, runs the selected operation, and collects its results. Runner operations also unpack and verify the native Ferrun bundle, configure it against your control plane, and supervise its executor. The guest receives a Ferrun pool credential. GitHub authentication stays on the Mac.

All workflow runs are manual. GitHub-hosted execution requires `--workflow-ref main` in the canary repository, regardless of the controller checkout's branch. A local hosted-reference request requires both `--reference-kind github-hosted` and `--allow-hosted`. Saved observations can be reused when their workflow, suite, OS, and architecture match. Native tests and ad hoc commands do not contact GitHub.

## Publish a GitHub release

Run `make release` on the configured farm controller. It uses every entry in `scripts/farm/targets.json`: currently Linux ARM64, macOS ARM64, and Windows ARM64. Each archive includes `ferrun`, `control-plane`, and `executor`, plus API documentation and licenses. x64 qualification exists separately; x64 binaries are not included until native x64 capacity and image recipes are added to the farm inventory. `TARGET` is rejected for releases so a diagnostic selection cannot silently omit platforms.

1. Set a new `[workspace.package].version` in `Cargo.toml`, commit the release changes, and push that commit. The checkout must be clean, including untracked files; move unrelated files outside it. The release tag is `v` followed by this version.
2. Keep the Windows English ARM64 ISO in `Downloads` for first preparation, and authenticate `gh` with write access to the source repository. `make release` prepares the farm automatically. `RELEASE_REPO=OWNER/REPOSITORY` selects a different destination that already contains the commit; runtime `REPO` does not change release destination.
3. Run `make release`. `RUNNER_VERSION` optionally overrides the existing GitHub compatibility pin. Guests run sequentially with a four-hour limit per guest, using one frozen source archive and disposable PostgreSQL. Python, Rust workspace, database, comment-coverage, optimized build, API export, and package checks must all pass. Guest shutdown and base-image preservation are required before publication.

The command verifies each downloaded package's native identity, clean source commit, payload digests, archive checksum, and full-suite evidence. It creates a GitHub draft with every archive, checksum, per-target test report, and `release.json`, checks GitHub's received asset sizes and SHA-256 digests, then publishes it. Existing releases, drafts, and tags are rejected; assets are never overwritten. Publication uses the CLI's [draft creation](https://cli.github.com/manual/gh_release_create) and [draft publication](https://cli.github.com/manual/gh_release_edit) operations.

An upload or verification failure leaves the draft for inspection and exits nonzero. Check the draft in GitHub before retrying; the command never deletes it automatically. Local artifacts remain under the printed `.cache/releases/vVERSION-UUID/` path, while private guest logs stay in `.cache/utm-tests/`. Build failures create no release. Versions with a prerelease suffix become GitHub prereleases. This native release does not claim live GitHub compatibility or promote a signed update channel; those remain separate qualification and promotion operations.

For a single-platform packaging check without GitHub publication, use `scripts/farm-test.sh test --profile "$(python3 -B scripts/farm_paths.py)/macos-arm64/profile.json" --suite all --package-output /path/to/new/output`. The output directory must not exist. The same packaging, full-suite, and native identity checks run before collection.

## Custom media and Packer preparation

Ordinary release and test commands obtain their default settings automatically. The commands below are optional overrides for operators selecting different verified installation media. `farm_paths.py` prints the actual selected directory, including overrides or an existing checkout-local farm.

The controller needs Homebrew and `uv`. Windows preparation also uses the ARM Secure Boot firmware supplied by an installed UTM application; ordinary Homebrew QEMU firmware was rejected by Windows Setup. `tools` installs Packer, Ansible, their pinned plugins, and missing QEMU/TPM dependencies. Linux and Windows use QEMU with native hardware virtualization; macOS uses Tart and Apple's restore image. Ansible installs the guest prerequisites. macOS preparation requires both a macOS 27+ host and guest: Apple's `VZMacGuestProvisioningOptions` creates the account and enables SSH on the first boot after restore. The recipe disables VNC and needs no desktop interaction, screen capture, or audio access.

Apple documents the [first-boot provisioning API](https://developer.apple.com/documentation/virtualization/vzmacguestprovisioningoptions), and [Tart checks the host version](https://github.com/openai/tart/blob/2.39.0/Sources/tart/Commands/Run.swift) before starting it. Older guest versions ignore these provisioning options, so this recipe does not support them.

```sh
scripts/farm-test.sh tools # Install the controller tools once and reuse them on later runs.
scripts/farm-test.sh prepare --target linux-arm64 --source-image /path/to/ubuntu-arm64.img --source-sha256 SUPPLIER_SHA256 # Verify Canonical media and prepare the guest unattended.
scripts/farm-test.sh prepare --target windows-arm64 --source-image /path/to/windows-arm64.iso --source-sha256 SUPPLIER_SHA256 --windows-driver /path/to/NetKVM --windows-language en-US --windows-image-index 3 # Use the language and Pro image index present in your Microsoft ISO.
scripts/farm-test.sh prepare --target macos-arm64 --source-image https://updates.cdn-apple.com/2026FallFCS/afcfc88e-bbe6-44bf-a5da-07c56eebc06c/UniversalMac_27.0_26A428_Restore.ipsw --source-sha256 2a5d3c695d501022b7fad9adaffcf2627bcb867d993fb5662dcd41bac99a2836 # Verify Apple's published content digest before restoring macOS 27 and creating its account through the first-boot API.
scripts/farm-test.sh test --profile "$(python3 -B scripts/farm_paths.py)/linux-arm64/profile.json" --suite all # Resolve the selected farm's saved connection and execute native tests with a private PostgreSQL cluster.
```

Windows media and its WIM index must agree; the index is not interchangeable between ISO releases. The `NetKVM` directory contains the signed ARM64 network driver from UTM's driver media. It is the only driver installed from that package. The guest agent is not installed.

The Windows recipe sets PowerShell execution policy to `RemoteSigned` for the generated guest account. Windows 11's default `Restricted` policy prevents locally generated workflow scripts from running. Machine and domain policies remain in effect. Both runner implementations use the same guest account and prerequisites.

Preparation creates its account, SSH key or WinRM certificate, and profile under `FARM_DIR/TARGET`, where `FARM_DIR` is the directory selected above. Keep that directory private. No GitHub token or Ferrun pool credential is baked into an image. `prepare --validate-only` checks a recipe without booting; other operations reject that flag; `--rebuild` explicitly replaces that target's prepared image. A completed manifest permits reuse only when the media and recipe still match. An image-build success does not mean its native tests or runner comparisons passed.

macOS installer downloads resume from `FARM_DIR/downloads/` after an interrupted connection. The script verifies the complete SHA-256 before handing the local file to Packer; Apple Virtualization also verifies the restore signature. To change media, supply both source arguments with `--rebuild`.

Automatic refresh replaces an interrupted owned disk that has no completed-image receipt. A verified macOS installer already in storage reduces the future-download part of the space estimate; the ten-GiB reserve remains required. Space failures report the requested target, available GiB, and required GiB, so an interrupted attempt does not unnecessarily demand room for a second copy of its retained installer.

Prepared-image fingerprints include executable recipes, firmware, and Windows locale/edition choices; Markdown edits do not request a new OS installation. Legacy receipts migrate only when their complete original hash matches those same inputs, including the observed pre-Windows-checksum-note README variant. The migrated Packer `/builds/*/custom_data/legacy_recipe_sha256` retains the original build fingerprint; `/recipe_sha256` records the equivalent identity without documentation. Migration preserves the completed build, source-media identity, and disk; an actual recipe, firmware, locale, or edition change still requires refresh.

To recover physical storage from a **stopped, successfully prepared Linux or Windows image**, run `scripts/farm-test.sh compact --target windows-arm64` (or `linux-arm64`). It stages a compressed QCOW2 copy, checks its structure and virtual size, compares every logical sector, and replaces the original only if it uses less physical storage. Verification failures preserve the original disk. Credentials, image receipts, and installers remain available. Run this only after its guest has stopped; [QEMU documents that offline image tools must not modify disks used by running VMs](https://www.qemu.org/docs/master/tools/qemu-img.html).

To install missing prerequisites, run `scripts/farm-test.sh provision --target windows-arm64` (or the Linux/macOS target). This boots the existing image, reruns the same Ansible playbook used by Packer, and shuts it down. It preserves existing installations and the original image-build receipt. Package-version, installation-media, firmware, or unattended-setup changes require `prepare --rebuild`. Run the native tests afterward to check the updated image.

For the two Windows review fixes, run `scripts/farm-test.sh test --profile "$(python3 -B scripts/farm_paths.py)/windows-arm64/profile.json" --suite review`. It installs the pinned test dependencies, checks the selected tests against the unmodified scratch copy, then restores each old fault in an isolated source copy. A real JavaScript action must fail with the old path check; nested composite execution must fail with the old environment merge. Compilation errors do not count. The collected `mutations.json` is supplemental review proof, not the full release gate.

Run one guest workload at a time on the initial Mac. The three initial targets are ARM64; x64 qualification remains separate. Available disk space is checked before image creation. Prepared images stop after each invocation; `--keep-vm` applies only to existing UTM profiles.

On macOS, the command holds temporary sleep-prevention assertions through `caffeinate -is`. They end with the command and do not change system power settings. Keep the laptop open and connected to power during image creation and tests; forced sleep can interrupt the guest.

On prepared laptop images, `test` and `exec` use disposable storage. Linux and Windows write to a temporary disk layer under `FARM_DIR/runs/`; macOS uses a temporary local Tart clone. After collecting reports, the harness stops the VM and deletes that run's storage, including build outputs and test databases. The prepared image stays unchanged, and logs remain in `.cache/utm-tests/`. `provision` deliberately updates the prepared image. Enrolled `runner` and `integration` sessions preserve their existing pool identity, and existing UTM profiles keep their current behavior.


## Use an existing UTM guest

Existing UTM VMs can use the same execution commands without rebuilding their images. Use a disposable guest with a dedicated test account and put its UUID in a profile. Keep Linux, macOS, and Windows profiles separate, including separate profiles for ARM64 and x64.

The base guest needs Git, tar, and native Python. For parity with the CI interpreter, use Python 3.13. Tests also need the repository's Rust toolchain, Node 24, native build tools, and the Python dependencies in `scripts/requirements-tools.lock`. Windows tests need PowerShell 7, Git Bash, and Clang on PATH; the ARM64 `ring` dependency invokes Clang alongside MSVC. Mac tests need Xcode command line tools. An optional `bootstrap` script installs your image's prerequisites before source transfer; it runs on every invocation and should be safe to repeat. A Windows bootstrap is PowerShell; a Unix bootstrap is Bash. Use your existing image provisioning recipe here instead of maintaining another package manager inside the test harness.

1. **Linux:** enable OpenSSH in the guest, install the test account's public key, and add a host SSH config alias. Verify its host key once. The harness uses `BatchMode=yes` and `StrictHostKeyChecking=yes`, so automation cannot stop at an interactive password or unknown-host prompt.
2. **macOS:** in the guest, open **System Settings → General → Sharing → Remote Login**, enable it for the test account, and configure the same SSH key and host alias. Use a macOS version compatible with the host's UTM virtualization support.
3. **Windows:** enable WinRM for the dedicated guest account. Limit its inbound firewall rule to the Mac's address on the VM network. Keep Basic authentication and `AllowUnencrypted` disabled. The harness uses NTLM with `message_encryption='always'`; HTTPS certificates are verified when an HTTPS endpoint is supplied. Use a native ARM64 Python on an ARM64 Windows VM, not an x64 interpreter under emulation.

On the Mac, Windows support uses the pinned Ansible and pywinrm installation for transfers and command execution:

```sh
scripts/farm-test.sh tools # Install the isolated controller dependencies; the wrapper selects its Python automatically.
```

There is no dependency on UTM's guest agent, screen recording, audio recording, or a shared host directory. UTM controls lifecycle through its [documented CLI](https://docs.getutm.app/updates/v4.1/); [pywinrm documents encrypted NTLM transport](https://github.com/diyan/pywinrm#encryption).

## Machine profiles

Put profiles in the ignored `.cache/utm/` directory. The following Unix example works for Linux; change `os`, `ssh`, and guest paths for macOS:

```json
{
  "vm": "YOUR-UTM-VM-UUID",
  "os": "Linux",
  "arch": "arm64",
  "root": "/home/ferrun/ferrun-lab",
  "ssh": "ferrun-linux",
  "python": "/usr/bin/python3.13",
  "path": ["/home/ferrun/.cargo/bin", "/opt/node24/bin"]
}
```

For Windows:

```json
{
  "vm": "YOUR-WINDOWS-VM-UUID",
  "os": "Windows",
  "arch": "arm64",
  "root": "C:/FerrunLab",
  "endpoint": "http://WINDOWS-GUEST-IP:5985/wsman",
  "user_env": "FERRUN_WINRM_USER",
  "password_env": "FERRUN_WINRM_PASSWORD",
  "python": "C:/Program Files/Python313/python.exe",
  "path": ["C:/Users/FerrunTest/.cargo/bin", "C:/Program Files/nodejs", "C:/Program Files/Git/cmd", "C:/Program Files/Git/bin", "C:/Program Files/PowerShell/7"]
}
```

Supply the two WinRM values through your provisioning or secret manager environment. They are guest account credentials, not GitHub credentials. Use a stable DHCP reservation or a maintained SSH alias; the harness does not guess an IP address from an unrelated VM.

Every profile field has a specific purpose:

| JSON pointer | Meaning |
| --- | --- |
| `/vm` | Exact UTM UUID or name. UUIDs avoid ambiguity after renaming a VM. |
| `/os` | Expected native OS: `Linux`, `macOS`, or `Windows`. The worker checks its own OS. |
| `/arch` | Expected native interpreter architecture: `arm64` or `x64`. |
| `/root` | Dedicated absolute guest scratch directory. Use forward slashes and ordinary path components. |
| `/ssh` | Unix SSH destination or host-config alias; SSH config owns ports, keys, and host verification. |
| `/ssh_config` | Optional local OpenSSH config for the lab's dedicated key and known-host file. Relative paths resolve beside the profile; the operator's global SSH config is untouched. |
| `/endpoint` | Windows WinRM URL, ending in `/wsman`, without embedded credentials. |
| `/user_env`, `/password_env` | Names of host environment variables holding the dedicated Windows account login. |
| `/python` | Native guest Python executable; defaults to `python3` on Unix and `python` on Windows. |
| `/path` | Optional guest tool directories to prepend for tests and Ferrun. It never copies the Mac's PATH. |
| `/bootstrap` | Optional local prerequisite script. Relative paths resolve beside the profile. Its output is saved as `bootstrap.log`. |
| `/farm` | Optional private Packer preparation directory. Selects the prepared-image lifecycle and generated guest account instead of UTM. |
| `/ca_trust_path` | Optional PEM certificate bundle for verified WinRM HTTPS. Preparation pins the new guest's public certificate. |

## Ad hoc commands and native tests

```sh
bash scripts/utm-test.sh exec --profile .cache/utm/linux.json --script /path/to/check.sh # Run an existing Bash diagnostic in the transferred source checkout and retain its exit status.
bash scripts/utm-test.sh exec --profile .cache/utm/windows.json --script /path/to/check.ps1 # Run a PowerShell diagnostic through encrypted WinRM without desktop automation.
bash scripts/utm-test.sh test --profile .cache/utm/macos.json --suite unit # Run the same Rust workspace and Python test commands used by native CI.
bash scripts/utm-test.sh test --profile .cache/utm/linux.json --suite database --database-env FERRUN_TEST_DATABASE_URL # Run the normally ignored database integration tests against an explicitly supplied disposable guest database.
bash scripts/utm-test.sh test --profile .cache/utm/windows.json --suite mutations --database-env FERRUN_TEST_DATABASE_URL # Run the existing deliberate-fault gate on the Windows guest rather than copying its test logic.
```

`--suite all` runs unit and database tests. `unit` reports database tests as `not_run`. Database suites create a private loopback PostgreSQL cluster when no `--database-env` is supplied; the image must have `initdb` and `pg_ctl` on its configured path. The worker generates a password and stops its cluster after the test. An explicit database URL is interpreted inside the guest, so `127.0.0.1` refers to the guest. The worker leaves an explicitly supplied database running.

Run the same command once per OS profile from your own script or CI scheduler. Run at most one invocation per VM at a time; on a memory-limited Mac, run the profiles sequentially too. `--timeout` bounds the test suite or guest runner lifetime, with a maximum of four hours. Shell failures remain failures: Bash scripts run with `-e`; PowerShell scripts must explicitly throw or exit nonzero when a native program fails.

### Diagnose macOS dependency connections

Use the maintained probes before changing dependency acquisition or guest networking:

```sh
scripts/farm-test.sh exec --profile "$(python3 -B scripts/farm_paths.py)/macos-arm64/profile.json" --script scripts/farm-network-check.sh --timeout 240 # Compare guest DNS, routes, TCP, TLS, and the exact failed public resource paths in a disposable clone.
scripts/farm-test.sh exec --profile "$(python3 -B scripts/farm_paths.py)/macos-arm64/profile.json" --script scripts/farm-dependency-check.sh --timeout 600 # Reproduce the hash-pinned online pip install and native locked Cargo fetch without changing host network settings.
```

Read `guest.log` in the printed evidence directory. The network script records failed probes and continues; a successful `exec` result means the diagnostic finished, not that every connection passed. The dependency script stops on an actual acquisition failure. Its shorter diagnostic retry limits do not change ordinary test or release commands. Both commands discard guest writes and retain the prepared image.

A connection timeout does not establish an invalid dependency pin. Successful DNS or a TLS handshake also does not establish that the package manager can download its required resources. Compare the exact online acquisition commands and capture the failing guest's state before assigning a cause; working fresh clones do not prove which event interrupted an earlier VM.

## Set up a runner and compare integration cases

Use the [company setup flow](company-setup.md) to obtain the HTTPS control-plane URL, pool ID, and pool enrollment credential. Give the test VM a dedicated `ferrun-*` pool label and enough capacity for its one persistent identity. The pool's repository must match `--repo` below. An employee operating the VM needs no repository administration role. The Mac's `gh` identity needs workflow dispatch and observation access to the private canary repository.

A trusted farm controller can add `--install-reference` to an integration command with `--reference-kind official-self-hosted` and a `ferrun-reference-*` label. This downloads the official native runner, verifies its published checksum, configures it beside Ferrun, and removes its registration afterward. This optional operation needs repository runner-administration authority on the controller. It mints a short-lived registration token through GitHub's API; it does not export the controller's existing token. Employee-only commands can continue using an already provisioned reference.

For a standalone executor session:

```sh
bash scripts/utm-test.sh runner --profile .cache/utm/windows.json --artifact artifacts/native/ferrun-v0.0.1-aarch64-pc-windows-msvc.zip --server https://ferrun.example.com --pool POOL_ID --timeout 1800 # Verify and install the archive, configure the guest with FERRUN_ENROLLMENT_TOKEN, and supervise a thirty-minute runner session.
```

Setup reads `FERRUN_ENROLLMENT_TOKEN` from the Mac's environment, or the variable named by `--token-env`. It transmits only that pool credential. Each VM/server/pool combination reuses its private runner identity between runs so repeated tests do not consume new pool slots. Concurrent sessions using that identity are rejected by Ferrun's existing installation lock. Ctrl-C stops the supervised session.

For a candidate comparison against saved hosted observations:

```sh
bash scripts/utm-test.sh integration --profile .cache/utm/windows.json --artifact artifacts/native/ferrun-v0.0.1-aarch64-pc-windows-msvc.zip --server https://ferrun.example.com --pool POOL_ID --repo acme/ferrun-canary --candidate-label ferrun-windows-test --workflow-ref canary-fixtures --reference-dir /path/to/hosted/evidence --case semantics # Start the guest runner and compare this case without dispatching another hosted reference.
```

Omit `--case` to run all ten existing integration cases, or repeat it for a focused selection. Both runners receive the same fixture commit. The harness checks every workflow and nested action against the local fixture bytes before dispatch and rejects branch movement afterward. The candidate observer checks the actual GitHub runner name against the guest's enrolled executor identity.

Existing evidence must contain the native and environment fields emitted by the updated `live-canary.py`. Older or stale evidence is rejected before any candidate dispatch. This is intentional: renaming an old JSON file cannot establish that two runs tested the same code.

When a new hosted baseline is authorized, replace `--reference-dir` with `--reference-label windows-11-arm --reference-kind github-hosted --allow-hosted`. This dispatches paid hosted work. Matching labels for the other profiles are `windows-2025`, `ubuntu-22.04`, `ubuntu-22.04-arm`, `macos-15`, and `macos-15-intel`, as defined by the existing qualification matrix. No hosted runs were required to test the harness itself.

An already registered official runner can be used with `--reference-label ferrun-reference-NAME --reference-kind official-self-hosted`. It must match the profile's OS and architecture. This path does not install the official runner or claim that its environment is a GitHub-hosted image. The report labels it separately.

Compare saved results again without starting a VM or contacting GitHub:

```sh
bash scripts/utm-test.sh compare --candidate-dir .cache/utm-tests/RUN/candidate/evidence --reference-dir /path/to/hosted/evidence --case semantics # Reject mismatched identity or outputs and return a nonzero exit status when comparison fails.
```

## Results and cleanup

Each invocation prints its private `.cache/utm-tests/run-UUID` output directory. It contains the worker result, command logs, and available executor diagnostics. Integration runs also retain GitHub's raw logs and job metadata, normalized observations from the existing canary oracle, dispatch ownership receipts, and `comparison.json`.

Comparison checks source, suite, OS, architecture, expected conclusions, and normalized semantic observations. It retains both observation values when they differ. Raw log byte equality is not meaningful across independent run IDs, timestamps, and OS paths, so the unchanged canary oracle defines the comparison. A failing observer leaves raw diagnostics and a nonzero command exit; it does not manufacture passing evidence.

These reports are diagnostic results. They do not replace `verify-local.py`, its mutation requirements, or its candidate transport-receipt checks. A passing UTM comparison does not authorize a release.

The harness cancels only its recorded, still-active GitHub runs and stops its supervised Ferrun process. Existing UTM guests that were already running stay running; `--keep-vm` retains a UTM guest started by the command. Prepared-image runs own their hypervisor process and request a guest shutdown before waiting for it to exit. If management is unavailable during failed startup, cleanup terminates that owned process. Source and logs remain in the guest scratch directory. Pool credentials remain under `root/runners/IDENTITY` and are never collected as evidence. Recreating that identity also requires server-side enrollment cleanup because pool capacity counts durable enrollments.

### Generated data fields

The private guest `request.json` is deleted as soon as the worker reads it. Its `/operation`, `/suite`, and `/timeout` select bounded work; `/os` and `/arch` declare the required native host; `/source_commit` and `/source_sha256` identify the committed revision and exact transferred archive; `/suite_sha256` binds the transferred verifier and fixtures to the host's frozen expectations; `/path` selects guest tools. `/environment` contains only the explicitly requested pool or test-database variable. Runner requests additionally carry `/server`, `/pool`, `/name`, `/state_dir`, and `/artifact_sha256` to bind enrollment, private restart state, and the installed native archive. In the separate `runner-ready` JSON, `/runner_name` is the public GitHub registration name derived from the enrolled executor ID, and `/pool_labels` confirms the configured routing labels. Neither field contains an executor token.

`result.json` records `/operation`, `/os`, `/arch`, `/source_commit`, `/source_sha256`, `/suite_sha256`, `/artifact_sha256`, and optional `/suite`. Native test results additionally include `/rustc` and `/node`, which record the compiler identity and Node version after checking the native compiler target and required Node major. `/passed` becomes true only after the requested commands and process cleanup succeed. `/database_tests` distinguishes `not_run`, `requested`, and `passed`. `/error` describes an execution failure without serializing the request environment. A missing report is an infrastructure failure, not a passing test.

Packaging requests add `/package` (requires the complete `all` suite) and `/runner_version` (the explicit GitHub compatibility version passed to the existing builder). Successful packaging results add `/release_archive`, the single native archive's basename, and set `/artifact_sha256` to its compressed bytes. The release's `TARGET-tests.json` assets use this same result schema and exclude private logs.

An explicitly installed reference adds private request `/reference` fields: `/url` and `/sha256` select verified supplier bytes; `/token` supplies short-lived runner registration; `/repository`, `/name`, and `/label` bind its routing and cleanup identity. The worker deletes the request after reading it and gives the setup token only to the official configuration process. Result `/reference_artifact_sha256` records the binary actually verified. Credential files are not collected.

`comparison.json` uses `/kind: utm-diagnostic-comparison` and `/release_qualification: false`. `/matched` is the aggregate result; `/reference_environment` distinguishes hosted and official self-hosted execution; `/suite_sha256` identifies the current comparison policy. `/cases/*` records `/case`, `/matched`, independent `/candidate_run` and `/reference_run` IDs, and both `/candidate_observations` and `/reference_observations` from the existing oracle. The live records' additional `/runner_os`, `/runner_arch`, and `/execution_environment` declare the requested native environment; `/runner_name` and `/runner_labels` preserve GitHub's observed scheduling metadata. These declarations do not assert identical preinstalled software images.
