# Native Ferrun installation state

`ferrun setup` stores private JSON under the platform-native state directory or the explicit `--state-dir`. These keyed explanations keep JSON valid while documenting each generated entry. Do not commit or distribute the directory as source or a release artifact.

## Operator local and server settings

| JSON pointer | Meaning and necessity |
| --- | --- |
| `/mode` | `local` starts the controller and an owned executor; `server` starts only the company control plane. |
| `/selection/repository` | Approved GitHub owner/repository; prevents restart from silently targeting another repository. |
| `/selection/label` | Stable GitHub workflow routing label for the configured pool. |
| `/selection/port` | Loopback consumer API port used by this installation. |
| `/selection/database_port` | Loopback port used only for managed PostgreSQL. |
| `/selection/capacity` | Pool admission quota; defaults to one for local mode and ten for server mode. |
| `/database_password` | Random credential for the installation's managed PostgreSQL role. |
| `/database_url` | Connection string for the selected PostgreSQL database; may contain credentials. |
| `/managed_database` | Whether Ferrun owns the selected Docker database lifecycle; external databases remain operator-owned. |
| `/container` | Stable installation-owned Docker container name, checked against its ownership label before reuse. |
| `/runner_version` | Explicit or packaged GitHub compatibility version advertised during registration. |
| `/encryption_key` | Base64-encoded 32-byte key required to read this controller's encrypted database records. |
| `/management_token` | Ferrun administrator credential; never an employee or executor credential. |
| `/executor_name` | Persisted random local executor name, avoiding collisions between hosts with identical filesystem layouts. |
| `/github_app/id` | Administrator-configured App identity; present only for App-authorized setup. |
| `/github_app/private_key_file` | Logical absolute path to the server's private PEM, allowing secret-manager replacement without changing the installation. The PEM is not copied into JSON. |
| `/connection_id` | Server-issued repository connection checkpoint, written only after creation succeeds. |
| `/pool/pool/id` | Server-issued pool identity used for executor enrollment. |
| `/pool/pool/connection_id` | Connection through which GitHub work reaches this pool. |
| `/pool/pool/name` | Operator-visible pool name, initialized from the routing label. |
| `/pool/pool/labels` | GitHub routing labels registered for this pool's execution capacity. |
| `/pool/pool/capacity` | Maximum admitted executor count, selected when the pool is created. |
| `/pool/enrollment_token` | Pool-scoped bootstrap credential for authorized employee machines; kept privately for provisioning and recovery. |

A GitHub App connection stores its credential kind under the database's existing encryption; its signing key remains in the operator-managed file.

## Employee settings

| JSON pointer | Meaning and necessity |
| --- | --- |
| `/remote/url` | Company control-plane HTTPS endpoint, revalidated before credentials are sent. |
| `/remote/pool_id` | The only pool selected by this installation's bootstrap authority. |
| `/remote/enrollment_token` | Company-issued Ferrun enrollment credential; not a GitHub token. |
| `/remote/name` | Persisted name of this machine, chosen explicitly or generated uniquely during setup. |
| `/labels` | Nonsecret routing labels read from the authorized pool. |

Employee settings contain no App key, database URL, or management credential.

## Executor state and recovery

`executor-state/credentials.json` retains the server-issued `/executor_id` and scoped `/access_token`. Reusing them prevents a restart from consuming another pool slot. Each attempt retains an encrypted append-only journal under `executor-state/events/`; complete unacknowledged records replay with their original sequence and capture timestamp. Keep the private `events/key` with its journals so they remain decryptable. An `.ack` file records the controller's durable sequence receipt. Recovery removes only an uncommitted torn journal suffix. Attempt markers prevent uncertain execution from being repeated; legacy `pending-event.json` is rejected.

Deploy the controller and executor from the same artifact with a fresh database and executor-state directory when changing from the earlier reporting format. Its aggregated summaries cannot recover individual invocation boundaries. Drain unfinished jobs with their old binaries first. Startup rejects application tables without the current schema marker; restarting the same current format is supported. See [reporting state and recovery](reporting.md) for the protocol guarantees.

`postgres/` holds the managed database's persistent data. Private `*.next-UUID` files are temporary atomic JSON replacements. `control-plane.log` and `executor.log` retain service diagnostics across restarts.

`launcher.lock` prevents concurrent launchers from sharing one installation. Private log files retain operational errors across restarts. Windows uses a protected owner ACL; Unix uses owner-only modes. Keep operator private state on the trusted server, separately from employee-controlled machines.
