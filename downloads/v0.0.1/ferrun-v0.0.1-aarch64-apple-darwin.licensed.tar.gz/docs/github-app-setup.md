# Authorize a company Ferrun control plane

An authorized company administrator completes this setup once. Employees connect their executors to the resulting Ferrun server with pool enrollment credentials; they do not need GitHub repository administration permission or the App private key.

Use a separate company-owned App for each independently managed deployment. An employee's personal Ferrun deployment should use its own App and repositories in an account or organization that the employee controls.

## 1. Create the App under the correct owner

From your GitHub profile menu, choose **Your organizations**, then **Settings** beside the company. Open **Developer settings → GitHub Apps → New GitHub App**. For a personal deployment, use **profile menu → Settings → Developer settings → GitHub Apps → New GitHub App**. Confirm the intended owner before creating the App. GitHub documents both [registration paths](https://docs.github.com/en/apps/creating-github-apps/registering-a-github-app/registering-a-github-app).

GitHub may show **Confirm access**. Complete its verification-code or password prompt in GitHub; it may recur when the administrator's verified session expires. Employees do not need this administrator setup. Ferrun cannot grant itself permissions that the account or organization has not approved.

Fill the creation form:

| Screen label | Value |
| --- | --- |
| **GitHub App name** | A unique deployment name, for example `Ferrun Acme`. |
| Description | Identify the company-controlled runner service. |
| **Homepage URL** | Your deployment's information page or this project's GitHub repository URL. |
| **Callback URL** (also shown as **Redirect URI**) and **Setup URL** | Leave empty; executor enrollment does not use GitHub user OAuth. |
| **Request user authorization (OAuth) during installation** and **Enable Device Flow** | Leave unchecked. |
| **Webhook → Active** | Uncheck. The current control plane polls for work and does not need a webhook receiver. |
| **Where can this GitHub App be installed?** | Select **Only on this account** for a company-owned or personal deployment. |

## 2. Grant the permissions actually required

Expand **Repository permissions**, open **Access: No access** beside **Administration**, and choose **Read and write**. GitHub requires this permission for its repository runner-registration API. **Metadata** becomes **Read-only** automatically. Leave other repository, organization, account, and enterprise permissions at **No access**.

Click **Create GitHub App**. Record the **App ID** shown on the resulting **General** page. The control plane will use the App's authority; an employee's GitHub role remains unchanged.

The project's private canary CI has additional duties: deploying test fixtures and dispatching and inspecting test workflows. Its separate CI App also needs **Actions**, **Contents**, and **Workflows** set to **Read and write**, plus **Checks: Read-only** to verify stored annotations. Install it only on the dedicated private canary repository. These extra CI permissions are not required for ordinary company executor enrollment; the full [CI setup guide](ci-setup.md) documents installation and permission-update clicks.

## 3. Install only on approved repositories

In the App's left sidebar, click **Install App**, then **Install** beside the intended account or organization.

On **Repository access**, select **Only select repositories**. GitHub initially selects **All repositories**, so change this explicitly. Open the repository selector, choose only the approved testing repositories, and check the selected list before clicking the final **Install** button.

The final page must show the expected owner, selected repositories, and permissions. Organization policy may require an organization owner to approve the installation. Do not resolve a permissions failure by granting access to every repository. See GitHub's [installation instructions](https://docs.github.com/en/apps/using-github-apps/installing-your-own-github-app) if the page differs.

## 4. Generate and protect the server key

Return to the App's **General** page. Under **Private keys**, click **Generate a private key** and save the downloaded PEM using the company's secret-management process. Provide the key only to the trusted control-plane service. Do not distribute it to employees, place it in a workflow repository, or include it in an executor configuration.

Continue with the [native server commands](company-setup.md#2-administrator-configure-and-run-the-control-plane): `--app-id` takes the numeric **App ID**, not the client ID; `--app-key` takes the downloaded PEM's path. No OAuth client secret is needed. When deploying the `control-plane` executable directly instead of the launcher, configure these values:

| Server setting | Meaning |
| --- | --- |
| `FERRUN_GITHUB_APP_ID` | The App ID from **General**. |
| `FERRUN_GITHUB_APP_PRIVATE_KEY_FILE` | A private local file containing the PEM key, readable by the control-plane service account. |
| GitHub connection `token_kind` | Set to `github_app` when creating the managed repository connection. |
| GitHub connection `access_token` | Omit it for `github_app`; Ferrun uses the server-owned key. |

Ferrun signs a short-lived App assertion, looks up the installation for the configured repository, and requests an installation token narrowed to that repository and runner-registration permission. New runner registrations obtain fresh tokens automatically. Neither App assertions nor installation tokens are sent to employee executors.

## 5. Give employees Ferrun access

The company administrator creates a pool for an approved repository connection. Deliver its server URL, pool ID, and enrollment credential through the company's normal secrets or machine-provisioning system. An enrollment credential permits access only to its pool, and enrollment returns a separate executor credential.

Employees follow [Connect a machine](company-setup.md#3-employee-connect-a-machine) using the server URL and pool ID. Their machine needs the executor's workflow tools, but no GitHub administrator credential, App key, management token, PostgreSQL server, or Docker database. The company control plane handles GitHub registration and reporting.

After starting an executor, dispatch a trusted workflow using the pool's labels and verify the completed job and logs in GitHub. A listening Ferrun process or successful enrollment alone does not prove GitHub compatibility.

If setup fails, first check the selected App installation and repository, the server's App ID/key pairing, the employee's pool credential, and available pool capacity. Employees should contact the Ferrun operator rather than request GitHub repository administration permission.

## What is automatic after authorization?

The App owner approves installation and repository access in GitHub. Server setup and employee setup can then run without prompts from provisioning scripts. Ferrun creates short-lived GitHub credentials through GitHub's API as needed; customers do not create a personal access token or export an existing GitHub CLI login for this company flow.

Ferrun v0.0.1 authenticates employees' machines with pool bearer credentials. It does not provide a human login page, an identity-provider integration, or a separate employee-to-repository directory. The company decides access by distributing credentials for selected pools; each pool belongs to a repository connection. Treat anyone holding a pool credential as authorized to attach a machine to that pool.

## Change approved repositories or rotate the key

To adjust repositories, open the owning account or organization's **Settings → GitHub Apps / Installed GitHub Apps**, choose **Configure** beside the App, update **Repository access**, and click **Save**. App registration settings are separately under **Developer settings → GitHub Apps → Edit**. Keep the installation limited to approved repositories.

To rotate the server key, open the App's **General → Private keys**, choose **Generate a private key**, and replace the file at the configured server path through your secret manager. Ferrun reads that path for new registrations. Verify a new registration before deleting the old key using its **Delete** control. Existing executor enrollment is a separate Ferrun credential; key rotation does not revoke it.
