# Install Ferrun v0.0.1

**No release bundles are published yet.** Use [Build and run from source](https://github.com/varunchopra/github-api-control-plane/blob/main/README.md#build-and-run-from-source) to try the preview. The download steps below apply when a qualified native release is available; a CI candidate alone is not a supported release.

Native bundle installations need neither Rust nor Python. Check the [Releases page](https://github.com/varunchopra/github-api-control-plane/releases) for publication status.

## Windows runtime prerequisite

The Windows programs import `VCRUNTIME140.dll`. Install Microsoft's current Visual C++ v14 Redistributable matching the Ferrun executable's architecture before running the bundle. A company can deploy this prerequisite through its normal software-management system; employees do not need GitHub repository administration permission. Microsoft publishes the [supported runtime downloads](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist).

1. Open that Microsoft page and select **X64** for an x64 Ferrun bundle or **ARM64** for an ARM64 bundle.
2. Open the downloaded `vc_redist` installer, review and accept its license terms, and choose **Install**. Use your normal Windows administrator or IT approval process if prompted.
3. Follow any restart instruction, then continue with the Ferrun checksum and extraction steps below. If your company already supplies a current matching runtime, another installation is unnecessary.

For a company provisioning process running with the required Windows privileges, Microsoft's installer also supports unattended installation. Use the matching downloaded installer name:

```powershell
$installation = Start-Process .\vc_redist.arm64.exe -ArgumentList '/install', '/quiet', '/norestart' -Wait -PassThru # Install the matching Microsoft prerequisite through an already authorized provisioning process without an interactive wizard.
if ($installation.ExitCode -notin @(0, 3010)) { throw "Visual C++ runtime setup failed with code $($installation.ExitCode)" } # Preserve installation errors instead of starting Ferrun with a missing runtime.
if ($installation.ExitCode -eq 3010) { Write-Output 'A Windows restart is required before continuing.' } # Make the deferred restart explicit rather than silently treating it as a fully completed prerequisite.
```

Microsoft documents the [unattended switches and installed-version checks](https://learn.microsoft.com/en-us/cpp/windows/redistributing-visual-cpp-files#command-line-options-for-the-redistributable-packages). A newer installed runtime should be retained; do not downgrade it to repeat setup.

## Download and check the bundle

1. Open the project's [Releases page](https://github.com/varunchopra/github-api-control-plane/releases). Select **v0.0.1** and expand **Assets**.
2. Download the archive for your machine from the table below, together with its matching `.sha256` file. Keep both in the same folder. GitHub's **Source code** downloads do not contain the executables.
3. Verify the checksum using the command for your OS below. Stop if verification fails.
4. Extract the archive into a directory where your account can run programs. Keep `ferrun`, `control-plane`, `executor`, and `manifest.json` together; Windows names end in `.exe`.
5. Open a terminal in that directory and run `./ferrun --version`, or `.\ferrun.exe --version` in PowerShell. Expect `ferrun 0.0.1`.

| Machine | Archive |
| --- | --- |
| Linux x64 | `ferrun-v0.0.1-x86_64-unknown-linux-gnu.tar.gz` |
| Linux ARM64 | `ferrun-v0.0.1-aarch64-unknown-linux-gnu.tar.gz` |
| macOS Intel | `ferrun-v0.0.1-x86_64-apple-darwin.tar.gz` |
| macOS Apple Silicon | `ferrun-v0.0.1-aarch64-apple-darwin.tar.gz` |
| Windows x64 | `ferrun-v0.0.1-x86_64-pc-windows-msvc.zip` |
| Windows ARM64 | `ferrun-v0.0.1-aarch64-pc-windows-msvc.zip` |

On Linux, `uname -m` reports `x86_64` for x64 and `aarch64` or `arm64` for ARM64. On macOS, open **Apple menu → About This Mac**: an Apple chip uses the Apple Silicon bundle; an Intel processor uses the Intel bundle. On Windows, open **Settings → System → About → System type**. Select the machine's native architecture even if your terminal runs under emulation.

Linux example; substitute your archive's exact name for ARM64:

```sh
sha256sum -c ferrun-v0.0.1-x86_64-unknown-linux-gnu.tar.gz.sha256 # Check the downloaded archive against the separately published digest before extraction.
mkdir ferrun-0.0.1 # Keep the matching executable set separate from an older installation.
tar -xzf ferrun-v0.0.1-x86_64-unknown-linux-gnu.tar.gz -C ferrun-0.0.1 # Extract the checked bundle while retaining Unix executable permissions.
cd ferrun-0.0.1 # Run the launcher beside the controller, executor, and compatibility manifest.
./ferrun --version # Confirm the launcher identity without starting services or enrolling a machine.
```

macOS example; substitute `x86_64-apple-darwin` for Intel:

```sh
shasum -a 256 -c ferrun-v0.0.1-aarch64-apple-darwin.tar.gz.sha256 # Use macOS's installed checksum tool to check the release download.
mkdir ferrun-0.0.1 # Extract into a distinct folder so component versions remain together.
tar -xzf ferrun-v0.0.1-aarch64-apple-darwin.tar.gz -C ferrun-0.0.1 # Preserve the native programs' executable permissions.
cd ferrun-0.0.1 # Select the checked bundle before invoking its launcher.
./ferrun --version # Confirm the release identity without creating private installation state.
```

Windows PowerShell example; substitute `aarch64-pc-windows-msvc` for ARM64:

```powershell
$archive = 'ferrun-v0.0.1-x86_64-pc-windows-msvc.zip' # Select exactly the native archive downloaded for this machine.
$expected = ((Get-Content "$archive.sha256" -Raw).Trim() -split '\s+')[0] # Read only the published digest from the checksum file.
if ((Get-FileHash $archive -Algorithm SHA256).Hash -ne $expected) { throw 'Archive checksum does not match' } # Refuse extraction when the downloaded bytes differ from the release digest.
Expand-Archive -Path $archive -DestinationPath ferrun-0.0.1 # Extract with Windows's built-in ZIP support into a separate version directory.
Set-Location ferrun-0.0.1 # Keep all matching executables and manifest beside the launcher.
.\ferrun.exe --version # Check the native launcher before configuring repository access.
```

If the OS or your company endpoint policy blocks a downloaded executable, ask the machine's administrator to approve the verified release through its normal process. The preview does not claim Apple notarization or Windows publisher signing. Do not disable endpoint protection to make setup pass.

## Choose the role

| You are setting up… | Tools needed | Continue with… |
| --- | --- | --- |
| A company control-plane server | PostgreSQL, or Docker for Ferrun's managed PostgreSQL; company App key; an HTTPS endpoint | [Company server](company-setup.md#1-administrator-authorize-github-and-prepare-the-server) |
| An employee executor | Git, Node 24, and the company's server URL, pool ID, and pool credential | [Connect a machine](company-setup.md#3-employee-connect-a-machine) |
| Both services for your own repository | Git, Node 24, PostgreSQL or Docker, plus your own authorized App or GitHub CLI login | Personal setup below |

Use your organization's normal tool installation process. Set `EXECUTOR_NODE24` to the Node 24 executable if `node` on PATH has a different major version. Workflows declaring Node 20 actions need a separate Node 20 runtime through `EXECUTOR_NODE20`. Shells and build tools used by a workflow must also exist on that executor; Ferrun does not install them automatically. Windows defaults to PowerShell, while explicit Bash steps need Bash installed.

## Personal setup

Use a repository you administer in your own account or organization. A personal control plane does not inherit access from an employer's Ferrun server or from an employee enrollment credential.

For unattended registration, follow [GitHub App setup](github-app-setup.md) under your own owner, then run:

```sh
./ferrun setup --repo YOUR_OWNER/YOUR_REPO --app-id YOUR_APP_ID --app-key /private/path/ferrun.pem # Store personal deployment settings while keeping its App key separate from employee pool authority.
./ferrun run # Start the controller and local executor with automatically refreshed App registration authority.
```

Use `.\ferrun.exe` in PowerShell and a Windows key path. Local mode is the default; `--mode server` is for a control plane whose executors run elsewhere.

An optional interactive alternative uses the GitHub CLI installed and authenticated on your own machine:

```sh
gh auth login # Complete your personal GitHub authorization locally with repository runner-administration access.
./ferrun setup --repo YOUR_OWNER/YOUR_REPO # Preflight the local services without exporting your login to GitHub Actions or another machine.
./ferrun run # Obtain a repository runner-registration token locally and start both native services.
```

This personal alternative requires a login permitted to administer that repository's self-hosted runners. The company employee flow does not use it. Keep the computer awake and connected; use the printed `runs-on` label in the [first workflow check](company-setup.md#4-verify-a-real-workflow).

By default, local/server setup creates its own Docker PostgreSQL container. To use your own dedicated database, supply `DATABASE_URL` in the setup process's environment first. Setup saves that choice privately for subsequent runs. Use `--state-dir` for another independent installation; default locations and restart behavior are in [Private state](company-setup.md#5-restart-private-state-and-troubleshooting).
