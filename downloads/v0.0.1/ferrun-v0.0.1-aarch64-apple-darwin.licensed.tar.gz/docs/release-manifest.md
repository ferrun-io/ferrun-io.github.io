# Native release manifest

Each native archive includes `manifest.json`. These JSON-pointer explanations document its generated fields without adding illegal JSON comments.

| JSON pointer | Meaning and necessity |
| --- | --- |
| `/format` | Manifest schema version; currently `1`. Consumers must not assume an unknown format has identical meaning. |
| `/version` | Ferrun version reported by the packaged launcher. |
| `/target` | Rust host triple identifying the actual native OS and architecture used for the build. |
| `/runner_version` | Explicit GitHub runner compatibility version advertised by the controller; not Ferrun's own version. |
| `/source_commit` | Source checkout's commit at build time, for identifying the candidate. |
| `/source_dirty` | Whether tracked or untracked changes were present; a commit alone cannot identify a dirty build's source. |
| `/checks/rust_tests_passed` | The required Rust test invocation completed successfully before packaging. Explicitly ignored database tests are not established by this field. |
| `/checks/source_comment_coverage_passed` | The lexical line-comment audit passed. Human review must still verify meaningful explanations. |
| `/checks/consumer_openapi_exported` | The packaged controller exported a parseable consumer API containing the expected connection endpoint. |
| `/checks/live_qualification_passed` | The builder sets this to `false`; compilation and unit tests do not prove live GitHub compatibility. Separate qualification evidence must identify the exact archive. |
| `/sha256/<relative-path>` | SHA-256 of each declared payload file, excluding the manifest itself. This binds extraction to the package inventory. |

The adjacent `<archive>.sha256` file covers the completed archive, including its manifest. A checksum detects different bytes; release provenance and live qualification are separate evidence. Do not edit a built archive or manifest after qualification and retain its old verdict.

`make release` also attaches a `release.json` index to the GitHub release. Its fields describe the complete configured VM matrix:

| JSON pointer | Meaning and necessity |
| --- | --- |
| `/format` | Index schema version, currently `1`. |
| `/repository`, `/tag` | Selected GitHub destination and tag derived from the workspace version. |
| `/source_commit` | Clean, pushed commit shared by all native builds. |
| `/source_sha256` | SHA-256 of the single frozen source archive transferred to every guest. |
| `/runner_version` | Explicit GitHub compatibility pin shared by the native manifests. |
| `/live_qualification_passed` | Always `false` for this build/test release; signed update promotion requires separate live evidence. |
| `/targets/*/id`, `/targets/*/target` | Complete farm inventory entry and its native Rust target. |
| `/targets/*/archive`, `/targets/*/sha256` | Release asset basename and independently verified compressed archive digest. |
| `/targets/*/tests` | Matching public guest result asset, documented in the farm guide. |
