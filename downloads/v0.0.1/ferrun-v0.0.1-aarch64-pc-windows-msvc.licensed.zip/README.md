# Ferrun

Start with [installation](docs/install.md), [company and employee setup](docs/company-setup.md), or [GitHub App authorization](docs/github-app-setup.md).

[Manifest fields](docs/release-manifest.md) explain what this candidate establishes. Live qualification is separate from compilation and packaging.

Read the [security boundaries](SECURITY.md), [project license](LICENSE), [upstream notice](NOTICE), and [dependency notices](THIRD_PARTY.md).
