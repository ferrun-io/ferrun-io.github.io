# Ferrun

Start with [installation](docs/install.md), [company and employee setup](docs/company-setup.md), or [GitHub App authorization](docs/github-app-setup.md).

[Manifest fields](docs/release-manifest.md) describe the package contents and recorded checks. Building a package does not establish live compatibility.

Read the [security boundaries](SECURITY.md), [project license](LICENSE), [upstream notice](NOTICE), and [dependency notices](THIRD_PARTY.md).
