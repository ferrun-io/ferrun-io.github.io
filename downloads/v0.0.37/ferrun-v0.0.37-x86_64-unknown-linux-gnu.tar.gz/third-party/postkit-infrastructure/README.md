<!--
Copyright (c) 2026 Ferrun contributors. All rights reserved.

Responsibility: Record the source and construction of bundled Postkit modules.
Connections: The installer checks each module digest before using shared schemas.
-->

# Postkit source

Source: https://github.com/varunchopra/postkit

Revision: `4aec865d7ce53bc84acbd6394edaabd3b8d3f31a` (`v0.12.1`).

Each module concatenates its upstream schema, functions and triggers in filename
order within each group. SQL bodies are unchanged. The adjacent license retains
the upstream Apache 2.0 terms. Installation runs within the host transaction.
