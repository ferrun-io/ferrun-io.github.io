# Third-party notices

Licences and notices for the programs' dependencies, including build dependencies. Workflow tools and actions are distributed separately.

| Package | Declared license | Supplied notices |
| --- | --- | --- |
| aead 0.5.2 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/aead-0.5.2/LICENSE-APACHE), [LICENSE-MIT](third-party/aead-0.5.2/LICENSE-MIT) |
| aes 0.8.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/aes-0.8.4/LICENSE-APACHE), [LICENSE-MIT](third-party/aes-0.8.4/LICENSE-MIT) |
| aes-gcm 0.10.3 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/aes-gcm-0.10.3/LICENSE-APACHE), [LICENSE-MIT](third-party/aes-gcm-0.10.3/LICENSE-MIT) |
| anyhow 1.0.104 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/anyhow-1.0.104/LICENSE-APACHE), [LICENSE-MIT](third-party/anyhow-1.0.104/LICENSE-MIT) |
| autocfg 1.5.1 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/autocfg-1.5.1/LICENSE-APACHE), [LICENSE-MIT](third-party/autocfg-1.5.1/LICENSE-MIT) |
| base64 0.22.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/base64-0.22.1/LICENSE-APACHE), [LICENSE-MIT](third-party/base64-0.22.1/LICENSE-MIT) |
| block-buffer 0.10.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/block-buffer-0.10.4/LICENSE-APACHE), [LICENSE-MIT](third-party/block-buffer-0.10.4/LICENSE-MIT) |
| bytes 1.12.1 | MIT | [LICENSE](third-party/bytes-1.12.1/LICENSE) |
| cfg-if 1.0.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/cfg-if-1.0.4/LICENSE-APACHE), [LICENSE-MIT](third-party/cfg-if-1.0.4/LICENSE-MIT) |
| chrono 0.4.45 | MIT OR Apache-2.0 | [LICENSE.txt](third-party/chrono-0.4.45/LICENSE.txt) |
| cipher 0.4.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/cipher-0.4.4/LICENSE-APACHE), [LICENSE-MIT](third-party/cipher-0.4.4/LICENSE-MIT) |
| const-oid 0.9.6 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/const-oid-0.9.6/LICENSE-APACHE), [LICENSE-MIT](third-party/const-oid-0.9.6/LICENSE-MIT) |
| cpufeatures 0.2.17 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/cpufeatures-0.2.17/LICENSE-APACHE), [LICENSE-MIT](third-party/cpufeatures-0.2.17/LICENSE-MIT) |
| crypto-common 0.1.7 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/crypto-common-0.1.7/LICENSE-APACHE), [LICENSE-MIT](third-party/crypto-common-0.1.7/LICENSE-MIT) |
| ctr 0.9.2 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/ctr-0.9.2/LICENSE-APACHE), [LICENSE-MIT](third-party/ctr-0.9.2/LICENSE-MIT) |
| digest 0.10.7 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/digest-0.10.7/LICENSE-APACHE), [LICENSE-MIT](third-party/digest-0.10.7/LICENSE-MIT) |
| displaydoc 0.2.7 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/displaydoc-0.2.7/LICENSE-APACHE), [LICENSE-MIT](third-party/displaydoc-0.2.7/LICENSE-MIT) |
| equivalent 1.0.2 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/equivalent-1.0.2/LICENSE-APACHE), [LICENSE-MIT](third-party/equivalent-1.0.2/LICENSE-MIT) |
| errno 0.3.14 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/errno-0.3.14/LICENSE-APACHE), [LICENSE-MIT](third-party/errno-0.3.14/LICENSE-MIT) |
| form_urlencoded 1.2.2 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/form_urlencoded-1.2.2/LICENSE-APACHE), [LICENSE-MIT](third-party/form_urlencoded-1.2.2/LICENSE-MIT) |
| generic-array 0.14.7 | MIT | [LICENSE](third-party/generic-array-0.14.7/LICENSE) |
| getrandom 0.2.17 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/getrandom-0.2.17/LICENSE-APACHE), [LICENSE-MIT](third-party/getrandom-0.2.17/LICENSE-MIT) |
| getrandom 0.4.3 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/getrandom-0.4.3/LICENSE-APACHE), [LICENSE-MIT](third-party/getrandom-0.4.3/LICENSE-MIT) |
| ghash 0.5.1 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/ghash-0.5.1/LICENSE-APACHE), [LICENSE-MIT](third-party/ghash-0.5.1/LICENSE-MIT) |
| hashbrown 0.17.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/hashbrown-0.17.1/LICENSE-APACHE), [LICENSE-MIT](third-party/hashbrown-0.17.1/LICENSE-MIT) |
| heck 0.5.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/heck-0.5.0/LICENSE-APACHE), [LICENSE-MIT](third-party/heck-0.5.0/LICENSE-MIT) |
| iana-time-zone 0.1.65 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/iana-time-zone-0.1.65/LICENSE-APACHE), [LICENSE-MIT](third-party/iana-time-zone-0.1.65/LICENSE-MIT) |
| icu_collections 2.3.0 | Unicode-3.0 | [LICENSE](third-party/icu_collections-2.3.0/LICENSE) |
| icu_locale_core 2.3.0 | Unicode-3.0 | [LICENSE](third-party/icu_locale_core-2.3.0/LICENSE) |
| icu_normalizer 2.3.0 | Unicode-3.0 | [LICENSE](third-party/icu_normalizer-2.3.0/LICENSE) |
| icu_normalizer_data 2.3.0 | Unicode-3.0 | [LICENSE](third-party/icu_normalizer_data-2.3.0/LICENSE) |
| icu_properties 2.3.0 | Unicode-3.0 | [LICENSE](third-party/icu_properties-2.3.0/LICENSE) |
| icu_properties_data 2.3.0 | Unicode-3.0 | [LICENSE](third-party/icu_properties_data-2.3.0/LICENSE) |
| icu_provider 2.3.1 | Unicode-3.0 | [LICENSE](third-party/icu_provider-2.3.1/LICENSE) |
| idna 1.1.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/idna-1.1.0/LICENSE-APACHE), [LICENSE-MIT](third-party/idna-1.1.0/LICENSE-MIT) |
| idna_adapter 1.2.2 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/idna_adapter-1.2.2/LICENSE-APACHE), [LICENSE-MIT](third-party/idna_adapter-1.2.2/LICENSE-MIT) |
| indexmap 2.14.2 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/indexmap-2.14.2/LICENSE-APACHE), [LICENSE-MIT](third-party/indexmap-2.14.2/LICENSE-MIT) |
| inout 0.1.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/inout-0.1.4/LICENSE-APACHE), [LICENSE-MIT](third-party/inout-0.1.4/LICENSE-MIT) |
| itoa 1.0.18 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/itoa-1.0.18/LICENSE-APACHE), [LICENSE-MIT](third-party/itoa-1.0.18/LICENSE-MIT) |
| libc 0.2.189 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/libc-0.2.189/LICENSE-APACHE), [LICENSE-MIT](third-party/libc-0.2.189/LICENSE-MIT) |
| libm 0.2.16 | MIT | [LICENSE.txt](third-party/libm-0.2.16/LICENSE.txt) |
| litemap 0.8.3 | Unicode-3.0 | [LICENSE](third-party/litemap-0.8.3/LICENSE) |
| lock_api 0.4.14 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/lock_api-0.4.14/LICENSE-APACHE), [LICENSE-MIT](third-party/lock_api-0.4.14/LICENSE-MIT) |
| memchr 2.8.3 | Unlicense OR MIT | [COPYING](third-party/memchr-2.8.3/COPYING), [LICENSE-MIT](third-party/memchr-2.8.3/LICENSE-MIT) |
| mio 1.2.3 | MIT | [LICENSE](third-party/mio-1.2.3/LICENSE) |
| num-traits 0.2.19 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/num-traits-0.2.19/LICENSE-APACHE), [LICENSE-MIT](third-party/num-traits-0.2.19/LICENSE-MIT) |
| once_cell 1.21.4 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/once_cell-1.21.4/LICENSE-APACHE), [LICENSE-MIT](third-party/once_cell-1.21.4/LICENSE-MIT) |
| opaque-debug 0.3.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/opaque-debug-0.3.1/LICENSE-APACHE), [LICENSE-MIT](third-party/opaque-debug-0.3.1/LICENSE-MIT) |
| parking_lot 0.12.5 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/parking_lot-0.12.5/LICENSE-APACHE), [LICENSE-MIT](third-party/parking_lot-0.12.5/LICENSE-MIT) |
| parking_lot_core 0.9.12 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/parking_lot_core-0.9.12/LICENSE-APACHE), [LICENSE-MIT](third-party/parking_lot_core-0.9.12/LICENSE-MIT) |
| percent-encoding 2.3.2 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/percent-encoding-2.3.2/LICENSE-APACHE), [LICENSE-MIT](third-party/percent-encoding-2.3.2/LICENSE-MIT) |
| pin-project-lite 0.2.17 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/pin-project-lite-0.2.17/LICENSE-APACHE), [LICENSE-MIT](third-party/pin-project-lite-0.2.17/LICENSE-MIT) |
| polyval 0.6.2 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/polyval-0.6.2/LICENSE-APACHE), [LICENSE-MIT](third-party/polyval-0.6.2/LICENSE-MIT) |
| potential_utf 0.1.6 | Unicode-3.0 | [LICENSE](third-party/potential_utf-0.1.6/LICENSE) |
| proc-macro2 1.0.107 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/proc-macro2-1.0.107/LICENSE-APACHE), [LICENSE-MIT](third-party/proc-macro2-1.0.107/LICENSE-MIT) |
| pyo3 0.29.3 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/pyo3-0.29.3/LICENSE-APACHE), [LICENSE-MIT](third-party/pyo3-0.29.3/LICENSE-MIT) |
| pyo3-build-config 0.29.3 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/pyo3-build-config-0.29.3/LICENSE-APACHE), [LICENSE-MIT](third-party/pyo3-build-config-0.29.3/LICENSE-MIT) |
| pyo3-ffi 0.29.3 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/pyo3-ffi-0.29.3/LICENSE-APACHE), [LICENSE-MIT](third-party/pyo3-ffi-0.29.3/LICENSE-MIT) |
| pyo3-macros 0.29.3 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/pyo3-macros-0.29.3/LICENSE-APACHE), [LICENSE-MIT](third-party/pyo3-macros-0.29.3/LICENSE-MIT) |
| pyo3-macros-backend 0.29.3 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/pyo3-macros-backend-0.29.3/LICENSE-APACHE), [LICENSE-MIT](third-party/pyo3-macros-backend-0.29.3/LICENSE-MIT) |
| quote 1.0.47 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/quote-1.0.47/LICENSE-APACHE), [LICENSE-MIT](third-party/quote-1.0.47/LICENSE-MIT) |
| rand_core 0.10.1 | MIT OR Apache-2.0 | [COPYRIGHT](third-party/rand_core-0.10.1/COPYRIGHT), [LICENSE-APACHE](third-party/rand_core-0.10.1/LICENSE-APACHE), [LICENSE-MIT](third-party/rand_core-0.10.1/LICENSE-MIT) |
| rand_core 0.6.4 | MIT OR Apache-2.0 | [COPYRIGHT](third-party/rand_core-0.6.4/COPYRIGHT), [LICENSE-APACHE](third-party/rand_core-0.6.4/LICENSE-APACHE), [LICENSE-MIT](third-party/rand_core-0.6.4/LICENSE-MIT) |
| scopeguard 1.2.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/scopeguard-1.2.0/LICENSE-APACHE), [LICENSE-MIT](third-party/scopeguard-1.2.0/LICENSE-MIT) |
| serde 1.0.229 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/serde-1.0.229/LICENSE-APACHE), [LICENSE-MIT](third-party/serde-1.0.229/LICENSE-MIT) |
| serde_core 1.0.229 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/serde_core-1.0.229/LICENSE-APACHE), [LICENSE-MIT](third-party/serde_core-1.0.229/LICENSE-MIT) |
| serde_derive 1.0.229 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/serde_derive-1.0.229/LICENSE-APACHE), [LICENSE-MIT](third-party/serde_derive-1.0.229/LICENSE-MIT) |
| serde_json 1.0.151 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/serde_json-1.0.151/LICENSE-APACHE), [LICENSE-MIT](third-party/serde_json-1.0.151/LICENSE-MIT) |
| sha2 0.10.9 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/sha2-0.10.9/LICENSE-APACHE), [LICENSE-MIT](third-party/sha2-0.10.9/LICENSE-MIT) |
| signal-hook-registry 1.4.8 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/signal-hook-registry-1.4.8/LICENSE-APACHE), [LICENSE-MIT](third-party/signal-hook-registry-1.4.8/LICENSE-MIT) |
| smallvec 1.16.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/smallvec-1.16.1/LICENSE-APACHE), [LICENSE-MIT](third-party/smallvec-1.16.1/LICENSE-MIT) |
| socket2 0.6.5 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/socket2-0.6.5/LICENSE-APACHE), [LICENSE-MIT](third-party/socket2-0.6.5/LICENSE-MIT) |
| stable_deref_trait 1.2.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/stable_deref_trait-1.2.1/LICENSE-APACHE), [LICENSE-MIT](third-party/stable_deref_trait-1.2.1/LICENSE-MIT) |
| subtle 2.6.1 | BSD-3-Clause | [LICENSE](third-party/subtle-2.6.1/LICENSE) |
| syn 2.0.119 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/syn-2.0.119/LICENSE-APACHE), [LICENSE-MIT](third-party/syn-2.0.119/LICENSE-MIT) |
| syn 3.0.6 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/syn-3.0.6/LICENSE-APACHE), [LICENSE-MIT](third-party/syn-3.0.6/LICENSE-MIT) |
| synstructure 0.13.2 | MIT | [LICENSE](third-party/synstructure-0.13.2/LICENSE) |
| target-lexicon 0.13.5 | Apache-2.0 WITH LLVM-exception | [LICENSE](third-party/target-lexicon-0.13.5/LICENSE) |
| tinystr 0.8.4 | Unicode-3.0 | [LICENSE](third-party/tinystr-0.8.4/LICENSE) |
| tokio 1.53.1 | MIT | [LICENSE](third-party/tokio-1.53.1/LICENSE) |
| tokio-macros 2.7.2 | MIT | [LICENSE](third-party/tokio-macros-2.7.2/LICENSE) |
| typenum 1.20.1 | MIT OR Apache-2.0 | [LICENSE](third-party/typenum-1.20.1/LICENSE), [LICENSE-APACHE](third-party/typenum-1.20.1/LICENSE-APACHE), [LICENSE-MIT](third-party/typenum-1.20.1/LICENSE-MIT) |
| unicode-ident 1.0.24 | (MIT OR Apache-2.0) AND Unicode-3.0 | [LICENSE-APACHE](third-party/unicode-ident-1.0.24/LICENSE-APACHE), [LICENSE-MIT](third-party/unicode-ident-1.0.24/LICENSE-MIT), [LICENSE-UNICODE](third-party/unicode-ident-1.0.24/LICENSE-UNICODE) |
| universal-hash 0.5.1 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/universal-hash-0.5.1/LICENSE-APACHE), [LICENSE-MIT](third-party/universal-hash-0.5.1/LICENSE-MIT) |
| url 2.5.8 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/url-2.5.8/LICENSE-APACHE), [LICENSE-MIT](third-party/url-2.5.8/LICENSE-MIT) |
| utf8_iter 1.0.4 | Apache-2.0 OR MIT | [COPYRIGHT](third-party/utf8_iter-1.0.4/COPYRIGHT), [LICENSE-APACHE](third-party/utf8_iter-1.0.4/LICENSE-APACHE), [LICENSE-MIT](third-party/utf8_iter-1.0.4/LICENSE-MIT) |
| utoipa 5.5.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/utoipa-5.5.0/LICENSE-APACHE), [LICENSE-MIT](third-party/utoipa-5.5.0/LICENSE-MIT) |
| utoipa-gen 5.5.0 | MIT OR Apache-2.0 | [LICENSE-APACHE](third-party/utoipa-gen-5.5.0/LICENSE-APACHE), [LICENSE-MIT](third-party/utoipa-gen-5.5.0/LICENSE-MIT) |
| uuid 1.26.1 | Apache-2.0 OR MIT | [LICENSE-APACHE](third-party/uuid-1.26.1/LICENSE-APACHE), [LICENSE-MIT](third-party/uuid-1.26.1/LICENSE-MIT) |
| version_check 0.9.5 | MIT/Apache-2.0 | [LICENSE-APACHE](third-party/version_check-0.9.5/LICENSE-APACHE), [LICENSE-MIT](third-party/version_check-0.9.5/LICENSE-MIT) |
| writeable 0.6.4 | Unicode-3.0 | [LICENSE](third-party/writeable-0.6.4/LICENSE) |
| yoke 0.8.3 | Unicode-3.0 | [LICENSE](third-party/yoke-0.8.3/LICENSE) |
| yoke-derive 0.8.2 | Unicode-3.0 | [LICENSE](third-party/yoke-derive-0.8.2/LICENSE) |
| zerofrom 0.1.8 | Unicode-3.0 | [LICENSE](third-party/zerofrom-0.1.8/LICENSE) |
| zerofrom-derive 0.1.7 | Unicode-3.0 | [LICENSE](third-party/zerofrom-derive-0.1.7/LICENSE) |
| zerotrie 0.2.5 | Unicode-3.0 | [LICENSE](third-party/zerotrie-0.2.5/LICENSE) |
| zerovec 0.11.8 | Unicode-3.0 | [LICENSE](third-party/zerovec-0.11.8/LICENSE) |
| zerovec-derive 0.11.6 | Unicode-3.0 | [LICENSE](third-party/zerovec-derive-0.11.6/LICENSE) |
| zmij 1.0.23 | MIT | [LICENSE-MIT](third-party/zmij-1.0.23/LICENSE-MIT) |
