# Copyright (c) 2026 Ferrun contributors. All rights reserved.
#
# Responsibility: Write optional Linux service units for controllers and workers,
# and back up or restore controller database state.
# Connections: Deployment commands call these OS and PostgreSQL operations with
# explicit bundle paths and saved settings.

"""Provide optional systemd integration and controller database maintenance."""

# Use private files and child environments for credentials; neither systemd
# command lines nor database command arguments contain their values.
import datetime
import json
import os
import shutil
import pathlib
import subprocess
import sys
import tempfile
import tarfile
import urllib.parse


def validate_paths(bundle, state):
    for path in (bundle, state):
        if any(character.isspace() or character in '"%' for character in str(path)):
            raise ValueError(
                "Installation paths contain unsupported systemd characters"
            )


def service(bundle, state):
    """Bind the controller to one bundle and the account owning its saved state."""
    import pwd

    validate_paths(bundle, state)
    settings = json.loads((state / "settings.json").read_text())
    if settings.get("mode") != "server" or settings.get("remote") is not None:
        raise ValueError("Control-plane service requires server state")
    account = pwd.getpwuid(state.stat().st_uid)
    if account.pw_uid == 0:
        raise ValueError("Control-plane state must belong to its service account")
    unit = f'''# Ferrun owns this unit; customer database and proxy services are independent.
[Unit]
Description=Ferrun control plane
After=network-online.target
Wants=network-online.target

# Keep the launcher and its controller in one process group for service shutdown.
[Service]
User={account.pw_name}
WorkingDirectory={state}
ExecStart="{bundle}/ferrun" run --state-dir "{state}" --bin-dir "{bundle}"
EnvironmentFile=-{state}/interface.env
Restart=on-failure
RestartSec=5
KillSignal=SIGINT
KillMode=control-group
TimeoutStopSec=30
UMask=0077
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=strict
ReadWritePaths="{state}"
MemoryMax=512M
CPUQuota=100%

# Starting on boot is a separate operator action after HTTPS configuration.
[Install]
WantedBy=multi-user.target
'''
    pathlib.Path("/etc/systemd/system/ferrun-control-plane.service").write_text(unit)


def worker_service(bundle, state):
    """Run an enrolled worker under the account that owns its private state."""
    import pwd

    validate_paths(bundle, state)
    settings = json.loads((state / "settings.json").read_text())
    if not isinstance(settings.get("remote"), dict):
        raise ValueError(
            "Worker service requires state created by ferrun setup --server"
        )
    account = pwd.getpwuid(state.stat().st_uid)
    if account.pw_uid == 0:
        raise ValueError("Configure the worker as its execution account, not root")
    # Workflows use the execution account's permissions. Controller restrictions
    # must not silently override a worker account's approved sudo or tool access.
    unit = f'''# Ferrun owns this worker unit; administrator overrides belong in drop-ins.
[Unit]
Description=Ferrun worker
After=network-online.target
Wants=network-online.target

[Service]
User={account.pw_name}
ExecStart="{bundle}/ferrun" run --state-dir "{state}" --bin-dir "{bundle}"
WorkingDirectory={state}
EnvironmentFile=-{state}/worker.env
Restart=on-failure
RestartSec=5
KillSignal=SIGINT
KillMode=control-group
TimeoutStopSec=30
UMask=0077
NoNewPrivileges=false
ProtectSystem=false
ProtectHome=false

[Install]
WantedBy=multi-user.target
'''
    pathlib.Path("/etc/systemd/system/ferrun-runner.service").write_text(unit)


# Database utilities keep URI options while receiving passwords only through
# their environment. PostgreSQL's parser remains responsible for connection semantics.
def database_command(program, settings, *arguments):
    uri = urllib.parse.urlsplit(settings["database_url"])
    environment = dict(os.environ)
    if uri.username:
        environment["PGUSER"] = urllib.parse.unquote(uri.username)
    if uri.password:
        environment["PGPASSWORD"] = urllib.parse.unquote(uri.password)
    query = urllib.parse.parse_qsl(uri.query, keep_blank_values=True)
    for key, value in query:
        if key == "password":
            environment["PGPASSWORD"] = value
    public = uri._replace(
        netloc=uri.netloc.rsplit("@", 1)[-1],
        query=urllib.parse.urlencode(
            [(key, value) for key, value in query if key != "password"]
        ),
    ).geturl()
    return subprocess.run(
        [program, "--dbname", public, *arguments],
        env=environment,
        check=True,
        capture_output=True,
    )


def migrate(bundle, settings):
    """Run the bundled controller's explicit migration using private settings."""
    subprocess.run(
        [str(bundle / "control-plane"), "migrate"],
        env=dict(os.environ, DATABASE_URL=settings["database_url"]),
        check=True,
    )


# Disable enrollment in all pools before checking for runners and unfinished jobs.
# Enrollment locks the same pool rows, so a concurrent join must finish first.
def empty(state, settings):
    result = database_command(
        "psql",
        settings,
        "--no-align",
        "--tuples-only",
        "--quiet",
        "--set",
        "ON_ERROR_STOP=1",
        "--command",
        "UPDATE pools SET enrollment_hash=''; DELETE FROM enrollment_tokens; SELECT count(*) FROM executors WHERE mode!='removed'; SELECT count(*) FROM jobs WHERE state->>'phase' NOT IN ('succeeded','failed','canceled');",
    )
    counts = [
        int(value) for value in result.stdout.decode().splitlines() if value.strip()
    ]
    if len(counts) != 2 or any(counts):
        raise ValueError(
            "Remove enrolled machines and finish reporting before removing the server"
        )


# Keep the database dump, settings, and encryption key together in a private
# archive, while excluding older backups to avoid recursive archive growth.
def backup(state, settings):
    directory = state / "backups"
    directory.mkdir(mode=0o700, exist_ok=True)
    timestamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    dump = directory / (timestamp + ".dump")
    database_command("pg_dump", settings, "--format=custom", "--file", str(dump))
    archive = directory / ("ferrun-" + timestamp + ".tar.gz")
    with tarfile.open(archive, "w:gz") as output:
        output.add(dump, arcname="database.dump")
        for path in state.iterdir():
            if path != directory and path.name != "launcher.lock":
                output.add(path, arcname="state/" + path.name)
    archive.chmod(0o600)
    dump.unlink()
    print("Backup: " + str(archive))


# Deployment rollback restores only a backup of this dedicated Ferrun database.
def restore(state, settings, archive):
    archive = pathlib.Path(archive).resolve()
    if archive.parent != (state / "backups").resolve():
        raise ValueError("Restore requires an installation-owned backup")
    with (
        tarfile.open(archive) as backup,
        tempfile.TemporaryDirectory(dir=state) as temporary,
    ):
        dump = pathlib.Path(temporary) / "database.dump"
        with (
            backup.extractfile("database.dump") as source,
            dump.open("wb") as destination,
        ):
            shutil.copyfileobj(source, destination)
        # Replace only this dedicated application's tables; unrelated public data grants no cleanup authority.
        result = database_command(
            "psql",
            settings,
            "--no-align",
            "--tuples-only",
            "--quiet",
            "--command",
            "SELECT tablename FROM pg_tables WHERE schemaname='public'",
        )
        tables = set(result.stdout.decode().splitlines())
        if not tables <= {
            "state_format",
            "connections",
            "pools",
            "pool_connections",
            "enrollment_tokens",
            "enrollment_receipts",
            "auth_accounts",
            "auth_tokens",
            "auth_devices",
            "controller_settings",
            "executors",
            "executor_liveness",
            "controllers",
            "controller_partitions",
            "github_registrations",
            "jobs",
            "job_events",
            "acquisition_intents",
            "native_runs",
            "native_invocations",
            "native_commands",
            "native_locks",
        }:
            raise ValueError(
                "Database contains tables outside this Ferrun installation"
            )
        database_command(
            "psql",
            settings,
            "--set",
            "ON_ERROR_STOP=1",
            "--command",
            "DROP TABLE IF EXISTS pool_connections, github_registrations CASCADE; ALTER TABLE jobs DROP CONSTRAINT IF EXISTS jobs_connection_id_fkey;",
        )
        database_command(
            "pg_restore",
            settings,
            "--exit-on-error",
            "--single-transaction",
            "--clean",
            "--if-exists",
            "--no-owner",
            str(dump),
        )


# Importing the helper cannot change systemd, query an installation, or read keys.
if __name__ == "__main__":
    operation, bundle, state, *arguments = sys.argv[1:]
    bundle, state = pathlib.Path(bundle), pathlib.Path(state)
    if operation == "paths":
        validate_paths(bundle, state)
    elif operation == "service":
        service(bundle, state)
    elif operation == "worker-service":
        worker_service(bundle, state)
    else:
        settings = json.loads((state / "settings.json").read_text())
        if operation == "backup":
            backup(state, settings)
        elif operation == "migrate":
            migrate(bundle, settings)
        elif operation == "version":
            result = database_command(
                "psql",
                settings,
                "--no-align",
                "--tuples-only",
                "--quiet",
                "--command",
                "SELECT version FROM state_format",
            )
            print(int(result.stdout))
        elif operation == "restore":
            restore(state, settings, arguments[0])
        elif operation == "empty":
            empty(state, settings)
        else:
            raise ValueError("Unknown native maintenance operation")
