<!--
Copyright (c) 2026 Ferrun contributors. All rights reserved.

Responsibility: Define distributed archive manifests and verification records.
Connections: release-tool, installation scripts, and website generation validate
releases against this contract.
-->

# Native release manifest

## Ownership and dependencies

Release tooling owns packaging, signing and publication. The update library owns
downloads, signature checks and recoverable changes to installed programs. Neither
owns a component's data layout. The executor owns its journals and credentials;
the control plane owns PostgreSQL backups and schema migrations.

The CLI supplies commands and prompts, selects an installation, and starts its
services. It passes configured component processes to the updater. Credentials
stay in those process configurations; the update record contains release identities
and progress, not database passwords or worker tokens.

| Owner                                     | Contract with other components                                                                                                                        |
| ----------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| Release tooling (`devtools/release-tool`) | Publish immutable files and signed manifests using `ferrun-artifacts`. Key storage and hosting are publisher choices.                                 |
| Update library (`libs/ferrun-update`)     | Accept a release source and component processes. Download and verify files, checkpoint an update, switch programs, and recover an interrupted switch. |
| Executor (`apps/executor`)                | Check upgrade support, drain its machine, back up and migrate its state, and restore or resume the same machine.                                      |
| Control plane (`apps/control-plane`)      | Check upgrade support, pause admissions, back up and migrate its database, and restore or resume its own installation.                                |
| CLI (`apps/ferrun`)                       | Resolve user choices and credentials, construct component processes, and report their results.                                                        |

Component maintenance uses a versioned request and response contract. Its
operations are check, drain, backup, migrate, restore, resume and readiness.
Requests carry one update identity and installation-owned paths. Repeating an
operation must not create a second backup, consume another enrolment, or resume a
pause belonging to someone else. Unsupported state formats fail during the check,
before admission or running services change.

The updater must not import controller storage or executor runtime code. In
particular, it must not contain SQL, PostgreSQL utility commands, journal filenames,
or GitHub authentication. Component teams can change those internals without
changing the update library, provided they preserve the maintenance contract.

The candidate component checks whether it can upgrade existing state and restore
its backup. After verification and draining, the launcher stops only its owned
processes. The updater records the backup before migration and records the switch
before restarting. Readiness must pass before admission resumes. Once admission
has resumed, recovery moves forward; it must not restore an older snapshot over
new work.

Unsupported protocol versions must fail before services stop.

Publication must qualify Cloud device sign-in and enrolment before advertising
that setup flow. Default endpoint selection alone does not establish that it works.

The workspace check enforces dependency direction: `ferrun-update` may depend on
`ferrun-artifacts` and `native-host`, while release contracts may not import other
Ferrun packages. This keeps implementation changes inside the owning component
without importing service storage or execution code into the updater.

The controller reserves its selected PostgreSQL schema for Ferrun. Its connection
role must own that schema; first setup rejects a populated, unversioned schema.
Backups include the selected schema without maintaining another list of its objects.
External dependencies on those objects are outside this storage contract.

`migration.rs` owns the explicit transactional transitions and the `state_format`
record. Managed updates currently permit only format 6 to format 6. Application
rollback therefore retains PostgreSQL data and checks that its format is unchanged.
It does not replay a schema dump or remove objects created after a backup. Adding a
managed schema transition requires a controller-owned recovery policy and tests of
that real transition, interrupted recovery and startup against recovered state.

Services restart from the selected release's immutable component directory. The
shared `ferrun` command is replaced only after the candidate is ready. Rolling back
one installation must not replace a command installed by another installation.
When a controller and worker belong to the same local installation, the controller
pauses admission for both; a remote worker pauses only its own machine.

Each native bundle includes `manifest.json`. Use [installation](install.md) to select a version and native target from [Releases](https://github.com/varunchopra/github-api-control-plane/releases), then verify its matching checksum. These JSON-pointer explanations document the generated fields without adding illegal JSON comments.

| JSON pointer                             | Meaning and necessity                                                                                                                                                                                              |
| ---------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `/format`                                | Manifest schema version. This table describes format `1`; consumers must not assume an unknown format has identical meaning.                                                                                       |
| `/version`                               | Ferrun version reported by the packaged launcher.                                                                                                                                                                  |
| `/target`                                | Rust host triple identifying the actual native OS and architecture used for the build.                                                                                                                             |
| `/runner_version`                        | Explicit GitHub runner compatibility version advertised by the controller; not Ferrun's own version.                                                                                                               |
| `/source_commit`                         | Source checkout's commit at build time, for identifying the candidate.                                                                                                                                             |
| `/source_dirty`                          | Whether tracked or untracked changes were present; a commit alone cannot identify a dirty build's source.                                                                                                          |
| `/checks`                                | Checks performed while packaging. Rust and database test evidence belongs to the separate suite reports; packaging does not rerun those tests.                                                                     |
| `/checks/source_comment_coverage_passed` | The structural comment audit passed for logical source blocks. Existing trailing explanations are accepted during migration; human review must still verify meaningful explanations and the style of changed code. |
| `/checks/consumer_openapi_exported`      | The packaged controller exported a parseable consumer API containing the expected connection endpoint.                                                                                                             |
| `/checks/live_qualification_passed`      | The builder sets this to `false`; compilation and unit tests do not prove live GitHub compatibility. Separate qualification evidence must identify the exact archive.                                              |
| `/sha256/<relative-path>`                | SHA-256 of each declared payload file, excluding the manifest itself. This binds extraction to the package inventory.                                                                                              |

The adjacent `<archive>.sha256` file covers the completed archive, including its manifest. A checksum detects different bytes; release provenance and live qualification are separate evidence. Do not edit a built archive or manifest after qualification and retain its old verdict.

GitHub's release assets list is the download inventory. The website reads its asset names, sizes, and digests, then checks downloaded bytes and each native bundle's manifest before generating links. It publishes packages and their checksum files.

The release workflow retains shared checks, native test reports, and live qualification evidence as Actions artifacts. `make release-assets` requires evidence for every selected worker before the publication action can expose the release. Website rendering does not rerun qualification or infer it from a package checksum.
