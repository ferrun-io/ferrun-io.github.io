<!--
Copyright (c) 2026 Ferrun contributors. All rights reserved.

Responsibility: Define current durable state, recovery, and machine quarantine
boundaries.
Connections: Connects controller fencing and admission records to executor journals
and native-host recovery checks.
-->

# Native Ferrun installation state

`ferrun setup` stores private JSON under the platform-native state directory or the explicit `--state-dir`. These keyed explanations keep JSON valid while documenting each generated entry. Do not commit or distribute the directory as source or a release artifact.

## Operator local and server settings

| JSON pointer                   | Meaning and necessity                                                                                                                                      |
| ------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `/mode`                        | `local` starts the controller and an owned executor; `server` starts only the company control plane.                                                       |
| `/selection/repository`        | Optional initial GitHub repository; absent when the controller is configured before GitHub.                                                                |
| `/selection/label`             | Stable GitHub workflow routing label for the configured pool.                                                                                              |
| `/selection/port`              | Loopback consumer API port used by this installation.                                                                                                      |
| `/selection/database_port`     | Loopback port used only for managed PostgreSQL.                                                                                                            |
| `/selection/capacity`          | Pool admission quota; defaults to one for local mode and ten for server mode.                                                                              |
| `/database_password`           | Random credential for the installation's managed PostgreSQL role.                                                                                          |
| `/database_url`                | Connection string for the selected PostgreSQL database; may contain credentials.                                                                           |
| `/managed_database`            | Whether Ferrun owns the selected Docker database lifecycle; external databases remain operator-owned.                                                      |
| `/container`                   | Stable installation-owned Docker container name, checked against its ownership label before reuse.                                                         |
| `/runner_version`              | Explicit or packaged GitHub compatibility selection; may be empty on a controller without GitHub.                                                          |
| `/encryption_key`              | Base64-encoded 32-byte key required to read this controller's encrypted database records.                                                                  |
| `/management_token`            | Ferrun administrator credential; never an employee or executor credential.                                                                                 |
| `/executor_name`               | Persisted random local executor name, avoiding collisions between hosts with identical filesystem layouts.                                                 |
| `/github_app/id`               | Administrator-configured App identity; present only for App-authorized setup.                                                                              |
| `/github_app/private_key_file` | Logical absolute path to the server's private PEM, allowing secret-manager replacement without changing the installation. The PEM is not copied into JSON. |
| `/connection_id`               | Server-issued repository connection checkpoint, written only after creation succeeds.                                                                      |
| `/pool/pool/id`                | Server-issued pool identity used for executor enrollment.                                                                                                  |
| `/pool/pool/name`              | Operator-visible machine group name.                                                                                                                       |
| `/pool/pool/labels`            | Custom routing labels added to each machine's automatic implementation and platform labels.                                                                |
| `/pool/pool/capacity`          | Maximum admitted executor count, selected when the pool is created.                                                                                        |
| `/pool/enrollment_token`       | Pool-scoped bootstrap credential for authorized employee machines; kept privately for provisioning and recovery.                                           |

A GitHub App connection stores its credential kind under the database's existing encryption; its signing key remains in the operator-managed file.

## Employee settings

| JSON pointer               | Meaning and necessity                                                                 |
| -------------------------- | ------------------------------------------------------------------------------------- |
| `/remote/url`              | Company control-plane HTTPS endpoint, revalidated before credentials are sent.        |
| `/remote/pool_id`          | The only pool selected by this installation's bootstrap authority.                    |
| `/remote/enrollment_token` | Company-issued Ferrun enrollment credential; not a GitHub token.                      |
| `/remote/name`             | Persisted name of this machine, chosen explicitly or generated uniquely during setup. |
| `/labels`                  | Nonsecret routing labels read from the authorized pool.                               |

Employee settings contain no App key, database URL, or management credential.

## Executor state and recovery

`executor-state/credentials.json` retains the server-issued `/executor_id` and scoped `/access_token`. Reusing them prevents a restart from consuming another pool slot. Each attempt has a current-format journal directory under `executor-state/events/`. Keep the private `events/key` with its journals so they remain decryptable. `control` contains two reserved, authenticated checkpoint banks and admission-receipt slots. `bulk-*` files contain encrypted output payloads; durable receipts permit their reclamation. Unacknowledged observations replay with their original sequence and capture timestamp. A zero commit length marks an unfinished frame, whose body grants no recovery authority.

A replacement reconstructs the attempt cursor from its checkpoint and control records. It labels interrupted log records, closes unfinished steps, and reports a lost attempt as failed without running user effects again. Cancellation retains an existing attempt cursor; a canceled job that never started uses revision zero. The executor rejects old `.jsonl` journals and `pending-event.json` without changing them.

The journal's `format.json` has one current layout. Its fields are:

| JSON pointer                 | Meaning                                                                                      |
| ---------------------------- | -------------------------------------------------------------------------------------------- |
| `/version`                   | Current journal format, `2`. Other values stop recovery before execution.                    |
| `/attempt`                   | Job ID and epoch joined by `:`; both must match the assignment.                              |
| `/namespace`                 | Random UUID used to give the guardian stable identities for this journal's bulk allocations. |
| `/limits/control_bytes`      | Allocated control extent containing both checkpoint banks and receipt slots.                 |
| `/limits/segment_bytes`      | Allocated size of each bulk file, including its header.                                      |
| `/limits/initial_bulk_bytes` | Bulk capacity reserved before user code starts.                                              |

Each encrypted control-bank header contains `/generation`, `/through`, and
`/checkpoint`. Generation selects the newest committed bank; through identifies
the exact admitted sequence represented by the encrypted recovery checkpoint.
Each following control frame contains `/sequence`, `/metadata`, and an optional
`/payload` reference. Metadata is an encrypted observation with output text
removed. Payload references contain `/segment`, `/offset`, and `/bytes`; they
select an encrypted range within one owned bulk file. Receipt slots authenticate
their replacement generation and admitted sequence separately from bank rotation.

Missing published control state stops recovery; it never creates a fresh attempt.
An interrupted bulk allocation can be deleted only when no unacknowledged frame
requires it. Damage to required payloads remains a visible recovery failure.

`ownership.json` records the current guardian generation, boot identity, and dirty state. `guardian.lock` permits one guardian per installation. Dirty evidence is durable before child creation. A surviving guardian stops user roots and its supervisor group, verifies release, and records a clean receipt before a replacement can start. A dirty generation on the same boot quarantines the installation. Linux and macOS can accept a verified different boot identity; Windows requires a clean receipt because its boot identity has not been qualified. Saved PIDs grant no recovery authority.

Run one guardian installation per execution environment. A fresh state directory does not prove that an environment with lost ownership is safe to reuse. [Process ownership](execution-architecture.md).

When reporting formats are incompatible, deploy the controller and executor from the same artifact with a fresh database and executor-state directory. Aggregated summaries cannot be converted into missing invocation boundaries. Drain unfinished jobs with binaries that understand their stored format first. Startup checks the database schema marker against the selected binary's expected format; restarting with a matching format is supported. See [reporting state and recovery](reporting.md) for the protocol guarantees.

`postgres/` holds the managed database's persistent data. Private `*.next-UUID` files are temporary atomic JSON replacements. `control-plane.log` and `executor.log` retain service diagnostics across restarts.

`launcher.lock` prevents concurrent launchers from sharing one installation. Private log files retain operational errors across restarts. Windows uses a protected owner ACL; Unix uses owner-only modes. Keep operator private state on the trusted server, separately from employee-controlled machines.

Server state format 5 separates machine pools, GitHub registrations, and job origins. `pool_connections` binds pools to connections. `github_registrations` retains each machine's identities and sessions for those connections. `executors.active_job_id` reserves one job through final reporting; other acquired jobs wait with their own connection and repository recorded.

Normal startup requires format 5. After stopping every controller, `control-plane migrate` upgrades format 4 to 5 transactionally using `DATABASE_URL`. The migration preserves machine credentials, GitHub registrations, job history, and event cursors. It refuses active format 4 owners, experimental native execution state, and unsupported versions. Existing GitHub workers retain their `/api/v1` endpoints after the controller upgrade. The older `/v1` protocol remains unsupported. This database migration does not convert incompatible executor journals.

`executors.mode` records `active`, `draining`, `removing`, or `removed`. Draining
permits assigned work and event delivery but prevents the controller from claiming new jobs for that runner. Removing
rejects work and event credentials while retaining the runner registration for
cleanup. Removed rows retain job history and no longer reserve their pool name
or capacity. The old machine credential can inspect or retry only its own
cleanup, allowing recovery when a removal response was lost.

`disconnected.json` records `/executor_id` after the server confirms removal.
It contains no credential and lets `ferrun leave` resume local cleanup. The
command deletes `settings.json` and `executor-state/credentials.json`, retaining
workspaces, journals, and journal keys. Setup and run reject disconnected state
so another runner cannot reuse the saved journals of an interrupted job.
