<!--
Copyright (c) 2026 Ferrun contributors. All rights reserved.

Responsibility: Define distributed archive manifests and verification records.
Connections: release-tool, installation scripts, and website generation validate
releases against this contract.
-->

# Native release manifest

Each native bundle includes `manifest.json`. Use [installation](install.md) to select a version and native target from [Releases](https://github.com/varunchopra/github-api-control-plane/releases), then verify its matching checksum. These JSON-pointer explanations document the generated fields without adding illegal JSON comments.

| JSON pointer                             | Meaning and necessity                                                                                                                                                                                              |
| ---------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `/format`                                | Manifest schema version. This table describes format `1`; consumers must not assume an unknown format has identical meaning.                                                                                       |
| `/version`                               | Ferrun version reported by the packaged launcher.                                                                                                                                                                  |
| `/target`                                | Rust host triple identifying the actual native OS and architecture used for the build.                                                                                                                             |
| `/runner_version`                        | Explicit GitHub runner compatibility version advertised by the controller; not Ferrun's own version.                                                                                                               |
| `/source_commit`                         | Source checkout's commit at build time, for identifying the candidate.                                                                                                                                             |
| `/source_dirty`                          | Whether tracked or untracked changes were present; a commit alone cannot identify a dirty build's source.                                                                                                          |
| `/checks`                                | Checks performed while packaging. Rust and database test evidence belongs to the separate suite reports; packaging does not rerun those tests.                                                                     |
| `/checks/source_comment_coverage_passed` | The structural comment audit passed for logical source blocks. Existing trailing explanations are accepted during migration; human review must still verify meaningful explanations and the style of changed code. |
| `/checks/consumer_openapi_exported`      | The packaged controller exported a parseable consumer API containing the expected connection endpoint.                                                                                                             |
| `/checks/live_qualification_passed`      | The builder sets this to `false`; compilation and unit tests do not prove live GitHub compatibility. Separate qualification evidence must identify the exact archive.                                              |
| `/sha256/<relative-path>`                | SHA-256 of each declared payload file, excluding the manifest itself. This binds extraction to the package inventory.                                                                                              |

The adjacent `<archive>.sha256` file covers the completed archive, including its manifest. A checksum detects different bytes; release provenance and live qualification are separate evidence. Do not edit a built archive or manifest after qualification and retain its old verdict.

GitHub's release assets list is the download inventory. The website reads its asset names, sizes, and digests, then checks downloaded bytes and each native bundle's manifest before generating links. It publishes packages and their checksum files.

The release workflow retains shared checks, native test reports, and live qualification evidence as Actions artifacts. `make release-assets` requires evidence for every selected worker before the publication action can expose the release. Website rendering does not rerun qualification or infer it from a package checksum.
