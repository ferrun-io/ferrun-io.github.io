<!--
Copyright (c) 2026 Ferrun contributors. All rights reserved.

Responsibility: Explain prepared native guest testing and operator diagnostics.
Connections: Uses farm and UTM entry points with qualification receipts and explicit
guest ownership.
-->

# Test Ferrun on the local farm

Run `make build` to validate the platforms selected by the GitHub Actions workflow
on registered Ferrun workers. `make test-farm` is an alias for that command. Use
a platform-specific target such as `make build-macos-arm64` for one platform.
These commands require a clean, pushed checkout and GitHub CLI authentication.

Image preparation and local guest diagnostics are separate operations, exposed
through `devtools/scripts/farm-test.sh --help`; `devtools/scripts/utm-test.sh` is
an alias. Preparing an image does not register a permanent CI runner.

Full tests of prepared images inject a stale guest clock, then use a confirmed 45-second VM pause and a
bounded clock-recovery check. The host stays awake; only the disposable guest
owned by that invocation is paused. Its temporary management port is separate
from a registered worker's port. The resulting `clock-recovery.json` records the
measured difference and recovery duration, rather than trusting a service's
enabled flag.

Linux and macOS use the verified media pinned in [farm defaults](../devtools/scripts/farm_media.py). For Windows, complete the [ISO download steps](#windows-media-acquisition) before first preparation.

Farm state lives in `~/Library/Application Support/Ferrun/farm`, outside source
worktrees and build caches. `FERRUN_FARM_DIR` selects another location. To move an
existing checkout-local farm, stop its VMs and run
`devtools/scripts/farm-test.sh migrate`. The command moves existing disks,
credentials and identities on the same filesystem, updates their paths and
resumes an interrupted relocation when repeated. It rebuilds disposable Python
tooling at the new path while preserving the prepared images and credentials.
It refuses active VMs and
conflicting destinations. Existing custom media selections remain authoritative.

The harness starts an installed guest and connects through SSH or WinRM. Native
test operations transfer the checkout and collect results. Runner installation
with `--artifact` verifies the bundle and enrolls it using a pool credential;
GitHub authentication stays on the Mac. To restart an existing runner, omit
`--artifact` and put its installed executable directory in the profile's `path`.
The `runner` command starts a permanent host service and returns after starting
the guest's runner service. Closing that management command does not stop either
service. Use `runner status` or `runner stop` with the same profile, server and
pool arguments to inspect or stop it. Stop waits for the guest runner to finish
its current jobs before shutting down the VM. Restart retains its enrollment and
instance disk without transferring source or consuming another enrollment token.

The farm is our own infrastructure implementation. Its Packer recipes and host
service are development tooling, separate from the customer binary. Disposable
tests borrow neither a permanent worker's disk nor its lifecycle ownership.
`test --suite services` runs real native service installation, reboot and shutdown tests
inside its disposable guest; `--suite all` includes those checks. They require
the prepared guest's service-installation authority and never install a service
on the operator's workstation.

The Linux image enables time synchronisation and caps its polling interval at one
minute. A VM can pause both its wall clock and its monotonic clock when the host
sleeps; neither guest clock can measure that missing time on its own. The guest
therefore samples an external time source automatically after resuming. NTP must
remain reachable. This is image configuration, not a privileged operation in the
Ferrun worker. Other hosts use their operating system's time service.

All workflow runs are manual. GitHub-hosted execution requires `--workflow-ref main` in the canary repository, regardless of the controller checkout's branch. A local hosted-reference request requires both `--reference-kind github-hosted` and `--allow-hosted`. Saved observations can be reused when their workflow, suite, OS, and architecture match. Native tests and ad hoc commands do not contact GitHub.

## Windows media acquisition

1. Open [Microsoft's Windows ARM64 download page](https://www.microsoft.com/en-us/software-download/windows11arm64) and choose **English (United States), ARM64**.
2. Save the completed ISO in `~/Downloads`. Keep Microsoft's filename and retain the file for image rebuilds.
3. Prepare the Windows image with `devtools/scripts/farm-test.sh prepare --target windows-arm64`. For publication, follow [the release steps](#publish-a-github-release).

Image preparation checks the media, configures the guest and retains the prepared
image. Run guest tests separately; preparation alone does not establish that a
release works on that platform.

## Publish a GitHub release

Release publication uses the platforms selected by the GitHub Actions workflow.
Preparing a local image does not add that platform to release coverage.

1. Set a new workspace version, merge the release changes, and update a clean
   `main` checkout.
2. Run `make release`. It builds the selected platforms, checks the packages,
   runs the live comparisons and publishes the release and website downloads.
3. If a job fails, fix its cause and run the command again. For the same commit,
   successful jobs are retained and only failed jobs are retried.

Authenticate `gh` for the source repository. Releases and tags belong to that
repository. `make qualify` runs qualification without publication when that is
needed separately. The [qualification guide](qualification.md) describes the
workflow and its checks.

For a single-platform packaging check without GitHub publication, use `devtools/scripts/farm-test.sh test --profile "$(python3 -B devtools/scripts/farm_paths.py)/macos-arm64/profile.json" --suite all --package-output /path/to/new/output`. The output directory must not exist. The same packaging, full-suite, and native identity checks run before collection.

## Custom media and Packer preparation

Ordinary release and test commands obtain their default settings automatically. The commands below are optional overrides for operators selecting different verified installation media. `farm_paths.py` prints the actual selected directory, including overrides or an existing checkout-local farm.

The controller needs Homebrew and `uv`. Windows preparation also uses the ARM Secure Boot firmware supplied by an installed UTM application; ordinary Homebrew QEMU firmware was rejected by Windows Setup. `tools` installs Packer, Ansible, their pinned plugins, and missing QEMU/TPM dependencies. Linux and Windows use QEMU with native hardware virtualization; macOS uses Tart and Apple's restore image. Ansible installs the guest prerequisites. macOS preparation requires both a macOS 27+ host and guest: Apple's `VZMacGuestProvisioningOptions` creates the account and enables SSH on the first boot after restore. The recipe disables VNC and needs no desktop interaction, screen capture, or audio access.

Apple documents the [first-boot provisioning API](https://developer.apple.com/documentation/virtualization/vzmacguestprovisioningoptions), and [Tart checks the host version](https://github.com/openai/tart/blob/2.39.0/Sources/tart/Commands/Run.swift) before starting it. Older guest versions ignore these provisioning options, so this recipe does not support them.

```sh
devtools/scripts/farm-test.sh tools # Install the controller tools once and reuse them on later runs.
devtools/scripts/farm-test.sh prepare --target linux-arm64 --source-image /path/to/ubuntu-arm64.img --source-sha256 SUPPLIER_SHA256 # Verify Canonical media and prepare the guest unattended.
devtools/scripts/farm-test.sh prepare --target windows-arm64 --source-image /path/to/windows-arm64.iso --source-sha256 SUPPLIER_SHA256 --windows-driver /path/to/NetKVM --windows-language en-US --windows-image-index 3 # Use the language and Pro image index present in your Microsoft ISO.
devtools/scripts/farm-test.sh prepare --target macos-arm64 --source-image https://updates.cdn-apple.com/2026FallFCS/afcfc88e-bbe6-44bf-a5da-07c56eebc06c/UniversalMac_27.0_26A428_Restore.ipsw --source-sha256 2a5d3c695d501022b7fad9adaffcf2627bcb867d993fb5662dcd41bac99a2836 # Verify Apple's published content digest before restoring macOS 27 and creating its account through the first-boot API.
# Run native checks in a disposable guest. Shared database tests run in CI.
devtools/scripts/farm-test.sh test \
  --profile "$(python3 -B devtools/scripts/farm_paths.py)/linux-arm64/profile.json" \
  --suite all
```

Windows media and its WIM index must agree; the index is not interchangeable between ISO releases. The `NetKVM` directory contains the signed ARM64 network driver from UTM's driver media. It is the only driver installed from that package. The guest agent is not installed.

The Windows recipe sets PowerShell execution policy to `RemoteSigned` for the generated guest account. Windows 11's default `Restricted` policy prevents locally generated workflow scripts from running. Machine and domain policies remain in effect. Both runner implementations use the same guest account and prerequisites.

Preparation creates its account, SSH key or WinRM certificate, and profile under `FARM_DIR/TARGET`, where `FARM_DIR` is the directory selected above. Keep that directory private. No GitHub token or Ferrun pool credential is baked into an image. `prepare --validate-only` checks a recipe without booting; other operations reject that flag; `--rebuild` explicitly replaces that target's prepared image. A completed manifest permits reuse only when the media and recipe still match. An image-build success does not mean its native tests or runner comparisons passed.

macOS installer downloads resume from `FARM_DIR/downloads/` after an interrupted connection. The script verifies the complete SHA-256 before handing the local file to Packer; Apple Virtualization also verifies the restore signature. To change media, supply both source arguments with `--rebuild`.

Automatic refresh replaces an interrupted owned disk that has no completed-image receipt. A verified macOS installer already in storage reduces the future-download part of the space estimate; the ten-GiB reserve remains required. Space failures report the requested target, available GiB, and required GiB, so an interrupted attempt does not unnecessarily demand room for a second copy of its retained installer.

Prepared-image fingerprints include executable recipes, firmware, and Windows locale/edition choices; Markdown edits do not request a new OS installation. Legacy receipts migrate only when their complete original hash matches those same inputs, including the observed pre-Windows-checksum-note README variant. The migrated Packer `/builds/*/custom_data/legacy_recipe_sha256` retains the original build fingerprint; `/recipe_sha256` records the equivalent identity without documentation. Migration preserves the completed build, source-media identity, and disk; an actual recipe, firmware, locale, or edition change still requires refresh.

Formatting migrations require an explicitly reviewed pair of complete fingerprints. The [migration evidence](../devtools/tests/fixtures/farm-formatting-migration.md) records source revisions, firmware hashes, Windows selections, and reproduction commands for the admitted pairs. Preparation accepts an old receipt only when the current fingerprint matches its reviewed equivalent, the target and installation media match, and the prepared disk still exists. It retains the original fingerprint in the receipt and reuses the image before checking rebuild space. Unknown differences still require refresh.

To recover physical storage from a **stopped, successfully prepared Linux or Windows image**, run `devtools/scripts/farm-test.sh compact --target windows-arm64` (or `linux-arm64`). It stages a compressed QCOW2 copy, checks its structure and virtual size, compares every logical sector, and replaces the original only if it uses less physical storage. Verification failures preserve the original disk. Credentials, image receipts, and installers remain available. Run this only after its guest has stopped; [QEMU documents that offline image tools must not modify disks used by running VMs](https://www.qemu.org/docs/master/tools/qemu-img.html).

To install missing prerequisites, run `devtools/scripts/farm-test.sh provision --target windows-arm64` (or the Linux/macOS target). This boots the existing image, reruns the same Ansible playbook used by Packer, and shuts it down. It preserves existing installations and the original image-build receipt. Package-version, installation-media, firmware, or unattended-setup changes require `prepare --rebuild`. Run the native tests afterward to check the updated image.

For the two Windows review fixes, run `devtools/scripts/farm-test.sh test --profile "$(python3 -B devtools/scripts/farm_paths.py)/windows-arm64/profile.json" --suite review`. It installs the pinned test dependencies, checks the selected tests against the unmodified scratch copy, then restores each old fault in an isolated source copy. A real JavaScript action must fail with the old path check; nested composite execution must fail with the old environment merge. Compilation errors do not count. The collected `mutations.json` is supplemental review proof, not the full release gate.

Run one guest workload at a time on the initial Mac. The three initial targets are ARM64; x64 qualification remains separate. Available disk space is checked before image creation. Prepared images stop after each invocation; `--keep-vm` applies only to existing UTM profiles.

On macOS, the command holds temporary sleep-prevention assertions through `caffeinate -is`. They end with the command and do not change system power settings. Keep the laptop open and connected to power during image creation and tests; forced sleep can interrupt the guest.

On prepared laptop images, `test` and `exec` use disposable storage. Linux and Windows write to a temporary disk layer under `FARM_DIR/runs/`; macOS uses a temporary local Tart clone. After collecting reports, the harness stops the VM and deletes that run's storage, including build outputs and test databases. The prepared image stays unchanged, and logs remain in `.cache/utm-devtools/tests/`. `provision` deliberately updates the prepared image. Enrolled `runner` and `integration` sessions preserve their existing pool identity, and existing UTM profiles keep their current behavior.

## Use an existing UTM guest

Existing UTM VMs can use the same execution commands without rebuilding their images. Use a disposable guest with a dedicated test account and put its UUID in a profile. Keep Linux, macOS, and Windows profiles separate, including separate profiles for ARM64 and x64.

This direct VM test helper invokes `devtools/scripts/utm/guest.py` inside the
guest, so its profile must identify an installed Python interpreter for the
guest's OS and architecture. It also uses Git and tar for source transfer.
These are requirements of this helper, not of the Ferrun runner. A VM enrolled
as an ordinary CI worker uses the workflow's setup actions; uv prepares Python
when Ferrun's tests need it.

The test commands prepare the repository's Rust toolchain, Node runtime, and
Python development environment from the maintained pins and `devtools/uv.lock`.
The guest still needs its native compiler prerequisites. Windows tests use
PowerShell 7, Git Bash, MSVC, and Clang; macOS tests use Xcode command line tools.
An optional `bootstrap` script prepares these prerequisites before source
transfer. It runs on every invocation and must be safe to repeat. Use PowerShell
on Windows and Bash on Unix, or prepare the tools in the VM image.

1. **Linux:** enable OpenSSH in the guest, install the test account's public key, and add a host SSH config alias. Verify its host key once. The harness uses `BatchMode=yes` and `StrictHostKeyChecking=yes`, so automation cannot stop at an interactive password or unknown-host prompt.
2. **macOS:** in the guest, open **System Settings → General → Sharing → Remote Login**, enable it for the test account, and configure the same SSH key and host alias. Use a macOS version compatible with the host's UTM virtualization support.
3. **Windows:** enable WinRM for the dedicated guest account. Limit its inbound firewall rule to the Mac's address on the VM network. Keep Basic authentication and `AllowUnencrypted` disabled. The harness uses NTLM authentication, verified TLS for HTTPS, and message encryption for HTTP. Use native ARM64 Python on an ARM64 Windows VM.

On the Mac, Windows support uses the pinned Ansible and pywinrm installation for transfers and command execution:

```sh
devtools/scripts/farm-test.sh tools # Install the isolated controller dependencies; the wrapper selects its Python automatically.
```

There is no dependency on UTM's guest agent, screen recording, audio recording, or a shared host directory. UTM controls lifecycle through its [documented CLI](https://docs.getutm.app/updates/v4.1/); [pywinrm documents encrypted NTLM transport](https://github.com/diyan/pywinrm#encryption).

Windows test and diagnostic commands use [Ansible background jobs](https://docs.ansible.com/projects/ansible/latest/playbooks_async.html). Ansible polls the saved result and rejects a failed command or an expired deadline. The guest still owns test-process cleanup, and the controller stops its VM after collecting reports.

For an `exec` script that runs `make test-services`, add `--service-reboot`. On Windows, the script receives the guest service password on standard input. It must leave the native test's `artifacts/service-reboot.json` in the transferred source checkout. The controller then runs the same reboot check used by `test --suite services`.

## Machine profiles

Put profiles in the ignored `.cache/utm/` directory. The following Unix example works for Linux; change `os`, `ssh`, and guest paths for macOS:

```json
{
  "vm": "YOUR-UTM-VM-UUID",
  "os": "Linux",
  "arch": "arm64",
  "root": "/home/ferrun/ferrun-lab",
  "ssh": "ferrun-linux",
  "python": "/usr/bin/python3.13",
  "path": ["/home/ferrun/.cargo/bin", "/opt/node24/bin"]
}
```

For Windows:

```json
{
  "vm": "YOUR-WINDOWS-VM-UUID",
  "os": "Windows",
  "arch": "arm64",
  "root": "C:/FerrunLab",
  "endpoint": "http://WINDOWS-GUEST-IP:5985/wsman",
  "user_env": "FERRUN_WINRM_USER",
  "password_env": "FERRUN_WINRM_PASSWORD",
  "python": "C:/Program Files/Python313/python.exe",
  "path": ["C:/Users/FerrunTest/.cargo/bin", "C:/Program Files/nodejs", "C:/Program Files/Git/cmd", "C:/Program Files/Git/bin", "C:/Program Files/PowerShell/7"]
}
```

Supply the two WinRM values through your provisioning or secret manager environment. They are guest account credentials, not GitHub credentials. Use a stable DHCP reservation or a maintained SSH alias; the harness does not guess an IP address from an unrelated VM.

Every profile field has a specific purpose:

| JSON pointer                 | Meaning                                                                                                                                                                  |
| ---------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `/vm`                        | Exact UTM UUID or name. UUIDs avoid ambiguity after renaming a VM.                                                                                                       |
| `/os`                        | Expected native OS: `Linux`, `macOS`, or `Windows`. The worker checks its own OS.                                                                                        |
| `/arch`                      | Expected native interpreter architecture: `arm64` or `x64`.                                                                                                              |
| `/root`                      | Dedicated absolute guest scratch directory. Use forward slashes and ordinary path components.                                                                            |
| `/ssh`                       | Unix SSH destination or host-config alias; SSH config owns ports, keys, and host verification.                                                                           |
| `/ssh_config`                | Optional local OpenSSH config for the lab's dedicated key and known-host file. Relative paths resolve beside the profile; the operator's global SSH config is untouched. |
| `/endpoint`                  | Windows WinRM URL, ending in `/wsman`, without embedded credentials.                                                                                                     |
| `/user_env`, `/password_env` | Names of host environment variables holding the dedicated Windows account login.                                                                                         |
| `/python`                    | Native guest Python executable; defaults to `python3` on Unix and `python` on Windows.                                                                                   |
| `/path`                      | Optional guest tool directories to prepend for tests and Ferrun. It never copies the Mac's PATH.                                                                         |
| `/bootstrap`                 | Optional local prerequisite script. Relative paths resolve beside the profile. Its output is saved as `bootstrap.log`.                                                   |
| `/farm`                      | Optional private Packer preparation directory. Selects the prepared-image lifecycle and generated guest account instead of UTM.                                          |
| `/ca_trust_path`             | Optional PEM certificate bundle for verified WinRM HTTPS. Preparation pins the new guest's public certificate.                                                           |

## Ad hoc commands and native tests

```sh
bash devtools/scripts/utm-test.sh exec --profile .cache/utm/linux.json --script /path/to/check.sh # Run an existing Bash diagnostic in the transferred source checkout and retain its exit status.
bash devtools/scripts/utm-test.sh exec --profile .cache/utm/windows.json --script /path/to/check.ps1 # Run a PowerShell diagnostic through encrypted WinRM without desktop automation.
bash devtools/scripts/utm-test.sh test --profile .cache/utm/macos.json --suite unit
bash devtools/scripts/utm-test.sh test --profile .cache/utm/windows.json --suite mutations
```

`--suite all` runs native runtime tests, installed SDK checks, and platform mutation checks through `devtools/scripts/test.sh platform`. `unit` runs native Rust tests only; `mutations` runs platform mutation checks. Controller and database integration tests run once in the shared CI job. Guest test reports therefore record `database_tests` as `not_run`.

Run the same command once per OS profile from your own script or CI scheduler. Run at most one invocation per VM at a time; on a memory-limited Mac, run the profiles sequentially too. `--timeout` bounds the test suite or guest runner lifetime, with a maximum of four hours. Shell failures remain failures: Bash scripts run with `-e`; PowerShell scripts must explicitly throw or exit nonzero when a native program fails.

### Diagnose macOS dependency connections

Use the maintained probes before changing dependency acquisition or guest networking:

```sh
devtools/scripts/farm-test.sh exec --profile "$(python3 -B devtools/scripts/farm_paths.py)/macos-arm64/profile.json" --script devtools/scripts/farm-network-check.sh --timeout 240 # Compare guest DNS, routes, TCP, TLS, and the exact failed public resource paths in a disposable clone.
devtools/scripts/farm-test.sh exec --profile "$(python3 -B devtools/scripts/farm_paths.py)/macos-arm64/profile.json" --script devtools/scripts/farm-dependency-check.sh --timeout 600 # Reproduce the hash-pinned online pip install and native locked Cargo fetch without changing host network settings.
```

Read `guest.log` in the printed evidence directory. The network script records failed probes and continues; a successful `exec` result means the diagnostic finished, not that every connection passed. The dependency script stops on an actual acquisition failure. Its shorter diagnostic retry limits do not change ordinary test or release commands. Both commands discard guest writes and retain the prepared image.

A connection timeout does not establish an invalid dependency pin. Successful DNS or a TLS handshake also does not establish that the package manager can download its required resources. Compare the exact online acquisition commands and capture the failing guest's state before assigning a cause; working fresh clones do not prove which event interrupted an earlier VM.

## Set up a runner and compare integration cases

Use the [company setup flow](company-setup.md) to obtain the HTTPS control-plane URL, pool ID, and pool enrollment credential. Give the test VM a dedicated `ferrun-*` pool label and enough capacity for its one persistent identity. Bind the pool to the repository selected by `--repo` below. An employee operating the VM needs no repository administration role. The Mac's `gh` identity needs workflow dispatch and observation access to the private canary repository.

A trusted farm controller can add `--install-reference` to an integration command with `--reference-kind official-self-hosted` and a `ferrun-reference-*` label. This downloads the official native runner, verifies its published checksum, configures it beside Ferrun, and removes its registration afterward. This optional operation needs repository runner-administration authority on the controller. It mints a short-lived registration token through GitHub's API; it does not export the controller's existing token. Employee-only commands can continue using an already provisioned reference.

For a standalone executor session:

Download and verify the matching [release archive](install.md#download-and-check-the-bundle), then set `FERRUN_RELEASE_ARCHIVE` to that local file's path. Use the selected release's inventory to match the guest OS and architecture. These diagnostic sessions can use released binaries without compiling Ferrun on the controller.

```sh
bash devtools/scripts/utm-test.sh runner --profile .cache/utm/windows.json --artifact "${FERRUN_RELEASE_ARCHIVE:?set the verified native archive path}" --server https://ferrun.example.com --pool POOL_ID --timeout 1800 # Verify the selected release, configure the guest with FERRUN_ENROLLMENT_TOKEN, and supervise a thirty-minute runner session.
```

Setup reads `FERRUN_ENROLLMENT_TOKEN` from the Mac's environment, or the variable named by `--token-env`. It transmits only that pool credential. Each VM/server/pool combination reuses its private runner identity between runs so repeated tests do not consume new pool slots. Concurrent sessions using that identity are rejected by Ferrun's existing installation lock. Ctrl-C stops the supervised session.

For a candidate comparison against saved hosted observations:

```sh
bash devtools/scripts/utm-test.sh integration --profile .cache/utm/windows.json --artifact "${FERRUN_RELEASE_ARCHIVE:?set the verified native archive path}" --server https://ferrun.example.com --pool POOL_ID --repo acme/ferrun-canary --candidate-label ferrun-windows-test --workflow-ref canary-fixtures --reference-dir /path/to/hosted/evidence --case semantics # Start the selected release's guest runner and compare this case without dispatching another hosted reference.
```

Omit `--case` to run all ten existing integration cases, or repeat it for a focused selection. Both runners receive the same fixture commit. The harness checks every workflow and nested action against the local fixture bytes before dispatch and rejects branch movement afterward. The candidate observer checks the actual GitHub runner name against the guest's enrolled executor identity.

Existing evidence must contain the native and environment fields emitted by the updated `live-canary.py`. Older or stale evidence is rejected before any candidate dispatch. This is intentional: renaming an old JSON file cannot establish that two runs tested the same code.

When a new hosted baseline is authorized, replace `--reference-dir` with `--reference-label windows-11-arm --reference-kind github-hosted --allow-hosted`. This dispatches paid hosted work. Matching labels for the other profiles are `windows-2025`, `ubuntu-22.04`, `ubuntu-22.04-arm`, `macos-15`, and `macos-15-intel`, as defined by the existing qualification matrix. No hosted runs were required to test the harness itself.

An already registered official runner can be used with `--reference-label ferrun-reference-NAME --reference-kind official-self-hosted`. It must match the profile's OS and architecture. This path does not install the official runner or claim that its environment is a GitHub-hosted image. The report labels it separately.

Compare saved results again without starting a VM or contacting GitHub:

```sh
bash devtools/scripts/utm-test.sh compare --candidate-dir .cache/utm-devtools/tests/RUN/candidate/evidence --reference-dir /path/to/hosted/evidence --case semantics # Reject mismatched identity or outputs and return a nonzero exit status when comparison fails.
```

## Results and cleanup

Each invocation prints its private `.cache/utm-devtools/tests/run-UUID` output directory. It contains the worker result, command logs, and available executor diagnostics. Integration runs also retain GitHub's raw logs and job metadata, normalized observations from the existing canary oracle, dispatch ownership receipts, and `comparison.json`.

Comparison checks source, suite, OS, architecture, expected conclusions, and normalized semantic observations. It retains both observation values when they differ. Raw log byte equality is not meaningful across independent run IDs, timestamps, and OS paths, so the unchanged canary oracle defines the comparison. A failing observer leaves raw diagnostics and a nonzero command exit; it does not manufacture passing evidence.

These reports are diagnostic results. They do not replace `verify-local.py`, its mutation requirements, or its candidate transport-receipt checks. A passing UTM comparison does not authorize a release.

The harness cancels only its recorded, still-active GitHub runs and stops its supervised Ferrun process. Existing UTM guests that were already running stay running; `--keep-vm` retains a UTM guest started by the command. Prepared-image runs own their hypervisor process and request a guest shutdown before waiting for it to exit. If management is unavailable during failed startup, cleanup terminates that owned process. Source and logs remain in the guest scratch directory. Pool credentials remain under `root/runners/IDENTITY` and are never collected as evidence. Recreating that identity also requires server-side enrollment cleanup because pool capacity counts durable enrollments.

### Generated data fields

The private guest `request.json` is deleted as soon as the worker reads it. Its `/operation`, `/suite`, and `/timeout` select bounded work; `/os` and `/arch` declare the required native host; `/source_commit` and `/source_sha256` identify the committed revision and exact transferred archive; `/suite_sha256` binds the transferred verifier and fixtures to the host's frozen expectations; `/path` selects guest tools. `/environment` carries explicitly supplied runner enrollment authority. Runner requests additionally carry `/server`, `/pool`, `/name`, `/state_dir`, and `/artifact_sha256` to bind enrollment, private restart state, and the installed native archive. In the separate `runner-ready` JSON, `/runner_name` is the public GitHub registration name derived from the enrolled executor ID, and `/pool_labels` confirms the configured routing labels. Neither field contains an executor token.

`result.json` records `/operation`, `/os`, `/arch`, `/source_commit`, `/source_sha256`, `/suite_sha256`, `/artifact_sha256`, and optional `/suite`. Native test results additionally include `/rustc` and `/node`, which record the compiler identity and Node version after checking the native compiler target and required Node major. `/passed` becomes true only after the requested commands and process cleanup succeed. `/database_tests` distinguishes `not_run`, `requested`, and `passed`. `/error` describes an execution failure without serializing the request environment. A missing report is an infrastructure failure, not a passing test.

Packaging requests add `/package` (requires the complete `all` suite) and `/runner_version` (the explicit GitHub compatibility version passed to the existing builder). Successful packaging results add `/release_archive`, the single native archive's basename, and set `/artifact_sha256` to its compressed bytes. The release's `TARGET-tests.json` assets use this same result schema and exclude private logs.

An explicitly installed reference adds private request `/reference` fields: `/url` and `/sha256` select verified supplier bytes; `/token` supplies short-lived runner registration; `/repository`, `/name`, and `/label` bind its routing and cleanup identity. The worker deletes the request after reading it and gives the setup token only to the official configuration process. Result `/reference_artifact_sha256` records the binary actually verified. Credential files are not collected.

`comparison.json` uses `/kind: utm-diagnostic-comparison` and `/release_qualification: false`. `/matched` is the aggregate result; `/reference_environment` distinguishes hosted and official self-hosted execution; `/suite_sha256` identifies the current comparison policy. `/cases/*` records `/case`, `/matched`, independent `/candidate_run` and `/reference_run` IDs, and both `/candidate_observations` and `/reference_observations` from the existing oracle. The live records' additional `/runner_os`, `/runner_arch`, and `/execution_environment` declare the requested native environment; `/runner_name` and `/runner_labels` preserve GitHub's observed scheduling metadata. These declarations do not assert identical preinstalled software images.
