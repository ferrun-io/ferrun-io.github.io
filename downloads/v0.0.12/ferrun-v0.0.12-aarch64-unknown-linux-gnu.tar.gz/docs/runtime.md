<!--
Copyright (c) 2026 Ferrun contributors. All rights reserved.

Responsibility: State verified GitHub Actions support and visible unsupported
behavior.
Connections: Guides workflow adoption and target compilation using implementation
evidence and live compatibility qualification.
-->

# Runtime and support

Use this guide to check whether a workflow fits Ferrun's current executor. For setup commands, start with [release installation](install.md) and [company or employee setup](company-setup.md). Contributors can use the README's [source workflow](../README.md#build-and-run-from-source).

This guide covers jobs assigned by GitHub. The [native function path](native-ci.md) has separate authoring, controller, and execution entry points. Its qualification limits are recorded in [implementation evidence](implementation-evidence.md). Programmatic cache services and broader integrations follow [product direction](product-direction.md).

## Execution and tools

Ferrun runs workflow commands directly as the executor's OS user. A job gets a working directory and a filtered environment, but no workload sandbox or isolation from other customers. Use trusted workflows and protect the host's files and credentials. [Security boundaries](../SECURITY.md).

Jobs inherit the worker account's configured home, profile directories, executable
search path, and tool settings. This applies equally to physical machines and VM
guests. A service uses its service manager's environment; Ferrun does not load an
interactive shell profile. Install and configure tools for that execution account.

Ferrun excludes inherited service credentials, controller settings, and outer
Actions job metadata before applying the current workflow's environment. Explicit
job and step variables retain their normal precedence, including an application
`DATABASE_URL`. `GITHUB_PATH` additions extend the step's selected `PATH`.
Checkout, temporary files, and Actions command files belong to the job; the
account's home and installed tools do not. Workspace cleanup never owns the home.

Source/build targets and downloadable bundle coverage are distinct. Use the selected release's inventory for available OS/architecture combinations and the [CI workflow](../.github/workflows/ci.yml) for configured build coverage. The executor implements Bash, sh, PowerShell, and cmd shell selection, Node 20/24 actions, and local or repository composite actions. Windows defaults to PowerShell; Unix defaults to Bash with an sh fallback. The requested interpreter and workflow tools must exist on the executor. See [shell selection](../libs/ferrun-actions-runtime/src/launch.rs) and [action loading](../libs/ferrun-actions-runtime/src/actions.rs).

Current release archives still require live qualification. An implemented shell or build target does not establish compatibility with arbitrary workflows or installed toolchains. The [qualification guide](qualification.md) defines what a successful run establishes.

PostgreSQL stores control-plane state. Ferrun can start it through Docker, or use an existing database supplied through `DATABASE_URL` before setup. This Docker use does not provide workflow isolation. Job/service containers and container resources are rejected by the [acquisition parser](../libs/github-api/src/lib.rs); automatic host provisioning and VM execution adapters are not implemented.

| Executor setting                     | Purpose                                                     |
| ------------------------------------ | ----------------------------------------------------------- |
| `EXECUTOR_NODE24`, `EXECUTOR_NODE20` | Select the matching Node executable when it is not on PATH. |
| `EXECUTOR_TOOL_CACHE`                | Select persistent storage for tools installed by actions.   |
| `EXECUTOR_ACTION_CACHE`              | Select the immutable action-source cache.                   |

These are executor-host paths. A control-plane provider setting cannot install a tool on a customer's machine.

### macOS setup-python prerequisite

For the [referenced setup-python revision](https://github.com/actions/setup-python/blob/5fda3b95a4ea91299a34e894583c3862153e4b97/docs/advanced-usage.md#macos), downloaded macOS Python binaries have fixed library paths under `/Users/runner/hostedtoolcache`. Prepare the paths and permissions required by the action revision your workflow selects, giving the executor's OS user the necessary write access. Adding a setup step to YAML does not grant host permissions.

## Job delivery and labels

1. The control plane opens outbound HTTPS requests to GitHub, waits for work, and downloads assignments.
2. Executors poll the control plane for assignments and send execution events back.
3. The control plane sends job results, logs, summaries, outputs, and post-hook results to GitHub.

Executors need no public inbound job-delivery port. When the control plane is on another machine, its API must be reachable over HTTPS. Local Ferrun setup uses `127.0.0.1:8788`. [GitHub client implementation](../libs/github-api/src/native.rs) · [Reporting and recovery](reporting.md).

`runs-on` selects registered execution capacity. Ferrun sends its implementation label, the machine's OS and architecture, and the pool's custom labels to GitHub; changing a label to `ubuntu-latest` does not install Ubuntu, allocate a VM, or replace the executor's tools. Customer-owned machines are reused across jobs unless an external provisioning system replaces them.

GitHub's hosted infrastructure supplies the image behind its hosted labels. Standard hosted runners receive fresh VMs; the single-CPU `ubuntu-slim` offering uses a container. Those are GitHub's documented hosting behaviors, not Ferrun capabilities or evidence about the private scheduler's implementation. [GitHub-hosted runner reference](https://docs.github.com/en/actions/reference/runners/github-hosted-runners).

The workflow's optional `container` setting chooses an execution environment inside the selected host. GitHub's container-related `env`, `ports`, `volumes`, and `options` configure that container, not the host selected by `runs-on`. Ferrun currently rejects these container workloads. [GitHub container documentation](https://docs.github.com/en/actions/how-tos/write-workflows/choose-where-workflows-run/run-jobs-in-a-container).

For current account and storage charges, consult [GitHub Actions billing](https://docs.github.com/en/billing/concepts/product-billing/github-actions).

## Concurrent jobs and scheduling

Set **Maximum concurrent jobs** on a runner's details page. This controls how many
jobs that machine may execute; the pool's **Maximum enrolled machines** remains a
separate limit. Lowering concurrency lets current jobs finish and stops new
admissions until the machine is below its new limit.

The pool's **Job placement** setting selects one policy:

| Policy        | Placement                                           |
| ------------- | --------------------------------------------------- |
| Least loaded  | Prefer the smallest fraction of occupied job slots. |
| Round robin   | Rotate eligible machines in stable ID order.        |
| Pack machines | Prefer the largest fraction of occupied job slots.  |

Permissions, routing labels, platform, connectivity and machine mode determine
eligibility before placement. A provider offer reserves capacity before GitHub
can assign work. An uncertain claim keeps its reservation until reconciled;
pausing, reconnecting or changing a limit cannot discard that uncertainty.

Each parallel attempt has its own workspace, process scope, cancellation and
encrypted event journal. Tools and immutable action sources keep using the
machine's shared caches. Execution capacity does not grant additional OS
privileges or turn host jobs into isolated containers.

The CLI uses the same authorised operations:

```sh
ferrun machine update "$machine_id" --concurrent-jobs 4
ferrun machine capacity "$machine_id"
ferrun pool update "$pool_id" --policy least-loaded
ferrun pool scheduling "$pool_id"
```

Older workers retain their one-job HTTP protocol and show an effective limit of
one. Capable workers negotiate their own session and slot-bound delivery routes;
older controllers continue serving their existing contracts alongside them.
Explicit `ferrun update` remains the only way to upgrade an installation. The
experimental native execution profile still runs one invocation at a time.

During a protocol upgrade, Ferrun withdraws the old GitHub connections before
advertising new job slots. Session creation remains recorded until withdrawal is
confirmed, including a late response handled by an older controller. Recovery
preserves running jobs and operator pauses; it does not require manual draining.

## Action restrictions

Configure allowed actions and commit-SHA requirements in GitHub under **Repository settings → Actions → General → Actions permissions**. Ferrun sends repository-action references to GitHub's resolver before consulting its local cache. It does not maintain another allowlist. Live validation of policy rejection through this client remains outstanding. [GitHub's action settings](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository).

GitHub's selected-action rules still allow local actions, and its full-SHA requirement permits reusable workflows to use tags. Action restrictions do not block arbitrary shell commands in `run:` steps; the host execution boundary still applies.

## Implementation and qualification

The GitHub wire client is handwritten Rust informed by reference-runner source and live probes. The earlier C# extractor and generated protocol crates were removed; their research remains in Git history at `767c7d7`. Automatic generation or repair from vendor source is not required; vendor protocol work can be manual. This does not change the plan to generate Ferrun's own SDKs from our contracts.

The OpenAPI document at `/openapi.json` is generated from Ferrun's Rust consumer API declarations. It describes Ferrun's management and executor interface, not GitHub's private API. `Cargo.lock` pins dependencies; its data fields are explained in [dependency-lock.md](dependency-lock.md).

The [qualification gate](qualification.md) requires ten live workflow cases and sensitivity to 26 deliberate faults. The independent observer checks GitHub conclusions and stored logs. Earlier successful builds do not qualify later source changes. [Implementation evidence](implementation-evidence.md) records reachable entry points and remaining gaps.

The extra `build` canary in `devtools/tests/live/canary.yml` is a development-Mac workload with explicit checkout and toolchain paths. It runs Rust tests, an optimized build, and a consumer API check using local caches. It is not a portable provisioning recipe. Temporary outputs and acknowledged job workspaces are cleaned up; ownership markers and durable job records remain for replay protection.

Instrumented applications own their observation lifecycle. Reports, measurements, and old builds remain until manually removed; there is no automatic retention quota. Unit/synthetic, real-canary, and ordinary-runtime evidence remain separate. [Observation setup and cleanup](observability.md).

## Historical observations

These records preserve the earlier investigation. They were not rerun for this documentation change and do not establish current release compatibility.

| Record                                                                                                                           | What it established at the time                                                                                                                                                                                 |
| -------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `actions/runner` source at `759385a3510197a58b5c08dc1f373b74b9f4643b`                                                            | The recorded search found no literal `ubuntu-latest` in `src/`, though workflows used it. This cannot locate or characterize GitHub's private scheduler.                                                        |
| Local network inspection, 2026-09-13                                                                                             | The controller had a loopback listener and an outbound port-443 connection. Other processes and firewall rules were not audited.                                                                                |
| Native CI, recorded in the README at `0a6d8b3`                                                                                   | Build and test checks had passed on all six native targets. Those results did not qualify the current release archives for live GitHub use.                                                                     |
| [Live build 34714352804](https://github.com/varunchopra/runner-controlplane-canary-20260912/actions/runs/34714352804)            | GitHub delivered a job for the custom `api-local-v1` label to the development Mac. Rust tests, build, and consumer API checks passed; hosted Ubuntu provisioning was not tested.                                |
| [Pre-review action run 34767200959](https://github.com/varunchopra/runner-controlplane-canary-20260912/actions/runs/34767200959) | The standard action sequence, dependent job outputs, and setup-uv with Python 3.13 passed. Later review required additional semantic and reporting checks. See the [workflow survey](workflow-usage-survey.md). |
