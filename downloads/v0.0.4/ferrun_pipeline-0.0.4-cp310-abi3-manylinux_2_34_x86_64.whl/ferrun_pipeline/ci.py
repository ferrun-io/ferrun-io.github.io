# Copyright (c) 2026 Ferrun contributors. All rights reserved.
#
# Responsibility: Define the generated Python native project authoring and dispatch
# facade.
# Connections: ferrun-sdk-codegen emits ferrun_pipeline.ci, which delegates contracts
# and runtime protocols to the Rust PyO3 binding.

# Experimental native authoring has its own import namespace and loaded Rust capability.
import asyncio
import inspect
import typing
import ferrun_pipeline._native as _native

PipelineError: typing.TypeAlias = _native.PipelineError

# Deferred references remain invariant in their declared schema type.
T = typing.TypeVar("T")

# Artifacts are managed native values; storage, verification, and codecs stay in Rust.
Artifact: typing.TypeAlias = _native.Artifact
NativeValue: typing.TypeAlias = typing.Union[
    bool,
    int,
    float,
    str,
    None,
    Artifact,
    typing.List["NativeValue"],
    typing.Dict[str, "NativeValue"],
]


# This context supplies only one registered invocation's values and artifact authority.
class Invocation:
    def __init__(self, native: _native.Invocation) -> None:
        """Retain the Rust handle for the lifetime of this wrapper."""
        self._native = native

    @property
    def function(self) -> str:
        """Expose the registered entry point or function selected by the host."""
        return self._native.function

    @property
    def inputs(self) -> typing.Dict[str, NativeValue]:
        """Return input values already validated by Rust."""
        return self._native.inputs

    @property
    def absent(self) -> typing.Dict[str, str]:
        """Report why an optional producer value is unavailable."""
        return self._native.absent

    # The native extension verifies complete artifact bytes and returns an opaque value.
    def artifact(self, path: str) -> Artifact:
        """Seal a file into the current run namespace through Rust."""
        return self._native.artifact(path)

    # User implementations can use the verified path with ordinary Python file APIs.
    def artifact_path(self, artifact: Artifact) -> str:
        """Return a path after Rust verifies ownership and artifact content."""
        return self._native.artifact_path(artifact)


# Loading and awaiting the selected function are high-level calls; Rust validates and publishes its result.
def run_registered(
    functions: typing.Mapping[
        str,
        typing.Callable[
            [typing.Mapping[str, NativeValue], Invocation],
            typing.Union[
                typing.Mapping[str, NativeValue],
                typing.Awaitable[typing.Mapping[str, NativeValue]],
            ],
        ],
    ],
) -> None:
    """Execute one host-selected registration and publish its checked result."""
    context = Invocation(_native.Invocation.open())
    try:
        result = functions[context.function](context.inputs, context)
        if inspect.isawaitable(result):

            async def wait(
                pending: typing.Awaitable[typing.Mapping[str, NativeValue]],
            ) -> typing.Mapping[str, NativeValue]:
                """Await the implementation before output publication."""
                return await pending

            # Bind the awaitable explicitly so later assignment cannot change a captured result.
            result = asyncio.run(wait(result))
        context._native.complete(dict(result))
    except Exception as error:
        context._native.fail(str(error))


# Native deferred values retain their graph and schema inside Rust.
class NativeOutput(typing.Generic[T]):
    def __init__(self, native: _native.NativeOutput) -> None:
        """Retain the Rust handle for the lifetime of this wrapper."""
        self._native = native

    def optional(self) -> "NativeOutput[typing.Optional[T]]":
        """Allow absent producer results when binding an optional input."""
        return NativeOutput(self._native.optional())


# A native pipeline schedules registered functions rather than GitHub steps.
class NativePipeline:
    def __init__(self, name: str) -> None:
        """Retain the Rust handle for the lifetime of this wrapper."""
        self._native = _native.NativePipeline(name, 2)

    def project(self, name: str, manifest: str) -> "NativeProject":
        """Read a project manifest path through Rust without executing task bodies."""
        return NativeProject(self._native.project(name, manifest))

    def compile(self) -> str:
        """Validate native intent and emit a plan without submitting work."""
        return self._native.compile()


# The descriptor supplies the complete project and its Rust-validated function schemas.
class NativeProject:
    def __init__(self, native: _native.NativeProject) -> None:
        """Retain the Rust handle for the lifetime of this wrapper."""
        self._native = native

    def function(self, name: str) -> "NativeFunction":
        """Expose the registered entry point or function selected by the host."""
        return NativeFunction(self._native.function(name))


# High-level argument mappings and handles are converted and checked in Rust.
class NativeFunction:
    def __init__(self, native: _native.NativeFunction) -> None:
        """Retain the Rust handle for the lifetime of this wrapper."""
        self._native = native

    def invoke(
        self,
        name: str,
        arguments: typing.Mapping[
            str, typing.Union[NativeValue, NativeOutput[typing.Any]]
        ],
        when: typing.Optional[NativeOutput[bool]] = None,
        timeout_seconds: int = 300,
        cpu_millis: int = 1000,
        memory_bytes: int = 268435456,
        locks: typing.Optional[typing.List[str]] = None,
    ) -> "NativeCall":
        """Record an invocation whose values and ownership Rust checks."""
        return NativeCall(
            self._native.invoke(
                name,
                dict(arguments),
                when._native if when else None,
                timeout_seconds,
                cpu_millis,
                memory_bytes,
                locks or [],
            )
        )


# Native calls expose ports and explicit success or completion barriers.
class NativeCall:
    def __init__(self, native: _native.NativeCall) -> None:
        """Retain the Rust handle for the lifetime of this wrapper."""
        self._native = native

    def output(self, name: str) -> NativeOutput[typing.Any]:
        """Return a deferred reference to a declared output port."""
        return NativeOutput(self._native.output(name))

    def after(
        self, producer: "NativeCall", require_success: bool = True
    ) -> "NativeCall":
        """Declare producer ordering without executing either function."""
        self._native.after(producer._native, require_success)
        return self
