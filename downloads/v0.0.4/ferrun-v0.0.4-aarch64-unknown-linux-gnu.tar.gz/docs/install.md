<!--
Copyright (c) 2026 Ferrun contributors. All rights reserved.

Responsibility: Explain installation from a selected verified Ferrun release.
Connections: Uses release inventories and native archive verification before
launcher setup connects a machine.
-->

# Install Ferrun

## Install the CLI and connect a machine

Choose your platform on the [download page](https://ferrun-io.github.io/).
For releases that provide a standalone `ferrun` executable, use the command shown
beside that download. It downloads the CLI and starts `ferrun setup`.

For a company controller, use `ferrun setup --server URL --repo OWNER/REPO`.
Interactive sign-in requires device flow to be enabled for that controller's
GitHub App. Setup prints an approval URL and code; it does not open your browser.
An administrator can instead issue a join token with `ferrun pool token create
POOL_ID`. Supply that token through `FERRUN_ENROLLMENT_TOKEN` and run
`ferrun setup --server URL --pool POOL_ID`. The machine receives its own credential;
setup removes the join token from its saved settings after enrolment.

For automation, pipe a scoped token into `ferrun auth login --server URL
--token-stdin`, then supply the repository and pool arguments explicitly.
An interactive account can create these credentials with `ferrun auth token
create NAME --repo OWNER/REPO`. Automation tokens cannot administer other tokens.

Normal user setup installs the CLI in `~/.local/bin` and components in
`~/.local/share/ferrun`. Root setup uses `/usr/local/bin/ferrun`,
`/usr/local/lib/ferrun`, and `/var/lib/ferrun` for private state. Existing saved
locations remain in use. Select a separate installation with `--state-dir`.

Use `ferrun setup --mode server` to configure your own controller, or
`ferrun setup --mode local --repo OWNER/REPO` to run a controller and worker
together. The controller needs its own PostgreSQL database. Workers connected
to Cloud or a company controller do not run PostgreSQL.

## Update an installation

Ferrun does not install updates automatically. Run `ferrun update` on each worker
and control-plane installation you want to upgrade, adding `--state-dir` if it
uses a custom state directory. Publishing a release does not change running
installations.

Ferrun checks the selected publisher's signed metadata and downloads
only the components this installation uses. It pauses new jobs and waits for
execution and reporting before stopping its services.

The CLI backs up its settings and worker state before selecting the new release.
If startup fails, it restores those files and selects the previous release. An
installation that was running attempts to restart its previous services; a stopped
installation stays stopped after recovery. Job caches are excluded from backups.

Managed controller updates require an unchanged database format. They keep database
data in place during application rollback and refuse recovery if that format has
changed. The explicit controller migration command is a separate operation.
Once admission resumes, recovery cannot rewind earlier state over new work.

Repository operators can update several local installations owned by the same
account with `bash devtools/scripts/update-ferrun.sh ferrun STATE_DIR ...`.
Replace `ferrun` with its executable path if it is not on PATH. Run the script
on each target host as the account that owns those state directories. It stops
on the first failure and does not connect to other hosts, so a VM does not need
inbound network access to run it.

The controller uses `pg_dump` to snapshot its dedicated PostgreSQL schema.
Docker-managed databases supply this utility inside their container; external
database installations need it on the controller's PATH. The connection role must
own a schema reserved for Ferrun, and first setup requires that schema to be empty.
Other applications must use separate schemas and must not depend on Ferrun's tables.

Startup checks and a running launcher's daily checks only print update notices;
they never initiate an upgrade or restart services. Windows self-update and
migration of legacy event files are not supported by this implementation; an
unsupported migration stops before changing the installation.

## Choose company releases

A controller administrator can run:

```sh
ferrun release set --url https://releases.example.com/ferrun/ --public-key release-key.pem
```

The release URL must end with `/`. It serves a signed `stable.json` and the
executable files named in it under `downloads/vVERSION/`. Companies can mirror
Ferrun's signed files or sign their own releases and configure the corresponding
public verification key.
No source build is needed on customers' machines.

Workers obtain this policy from their controller. A failed company download
does not fall back to Ferrun's public website. Add `--checks manual` to suppress
startup checks, or `--checks disabled` to prohibit component downloads and updates.
Use `ferrun release get` to inspect the configured source.

HTTP requests use the platform's certificate store and reqwest's proxy support,
including standard proxy environment variables. Configure these for the account
or service that runs Ferrun; credentials do not belong in the release URL.

## Install a release bundle

Use the [release site](https://ferrun-io.github.io/) to find available downloads.
Ferrun is proprietary software. Download the binaries from the website; GitHub
sign-in and source-repository access are not required.

Choose a version from the release site, or use the version your company specifies. Check its release metadata for downloads that match your operating system and processor. Read the release notes to see which GitHub Actions workflows have been tested.

Running the downloaded Ferrun programs does not require Rust or Python. Keep the
documentation and manifest with the programs. Optional host-service adapters and
the workflows themselves have their own prerequisites, described below.

## Windows runtime prerequisite

Ferrun's Windows programs need Microsoft's Visual C++ v14 Redistributable, which supplies `VCRUNTIME140.dll`. Download the version for your Ferrun download's processor type from [Microsoft](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist) and install it before running Ferrun. Your IT team may already provide it.

1. Open that Microsoft page and select the architecture matching your chosen Windows bundle, such as **ARM64** or **X64**.
2. Open the downloaded `vc_redist` installer, review and accept its license terms, and choose **Install**. Use your normal Windows administrator or IT approval process if prompted.
3. Follow any restart instruction, then continue with the Ferrun checksum and extraction steps below. If your company already supplies a compatible runtime, another installation is unnecessary.

IT administrators can also install the runtime without an interactive wizard. Run this with Windows administrator privileges, using the installer downloaded for the matching processor type:

```powershell
# Replace this path with the downloaded Microsoft installer.
$installer = '.\PATH_TO_MATCHING_REDISTRIBUTABLE.exe'
$installation = Start-Process $installer -ArgumentList '/install', '/quiet', '/norestart' -Wait -PassThru

# Code 3010 means installation succeeded but Windows must restart.
if ($installation.ExitCode -notin @(0, 3010)) {
    throw "Visual C++ runtime setup failed with code $($installation.ExitCode)"
}
if ($installation.ExitCode -eq 3010) {
    Write-Output 'A Windows restart is required before continuing.'
}
```

Microsoft documents these [installer options and version checks](https://learn.microsoft.com/en-us/cpp/windows/redistributing-visual-cpp-files#command-line-options-for-the-redistributable-packages). Keep a newer runtime if one is already installed.

## Download and check the bundle

1. Open the [release site](https://ferrun-io.github.io/) and read the release notes before choosing a platform.
2. Download the archive listed for your machine and its **Checksum** file. Keep both in the same folder.
3. Verify the checksum using the command for your OS below. Stop if verification fails.
4. Extract the archive into a directory where your account can run programs. Keep `ferrun`, `control-plane`, `executor`, and `manifest.json` together; Windows names end in `.exe`.
5. Open a terminal in that directory and run `./ferrun --version`, or `.\ferrun.exe --version` in PowerShell. The version must match your selected release and the bundle's `manifest.json`.

| Release metadata       | What to check                                                                      |
| ---------------------- | ---------------------------------------------------------------------------------- |
| GitHub release assets  | Available archives and SDK packages for that release.                              |
| `<archive>.sha256`     | SHA-256 checksum of the downloaded archive.                                        |
| Bundle `manifest.json` | Ferrun version, platform, selected GitHub runner version, file hashes, and checks. |

On Linux, use `uname -m` to identify the processor type (`aarch64`/`arm64` or `x86_64`). On macOS, use **Apple menu → About This Mac**. On Windows, use **Settings → System → About → System type**. Check the computer's hardware, which may differ from the type reported by an emulated terminal. Choose a matching download from the release. If none is listed, that release has no download for your computer.

In the examples below, replace the archive variable with the exact filename you downloaded. Run them from the folder containing both that archive and its checksum.

Linux:

```sh
# Replace the filename with your download and check it before extracting.
archive='PASTE_DOWNLOADED_ARCHIVE_NAME.tar.gz'
sha256sum -c "$archive.sha256"

# Use a new directory so files from different releases cannot mix.
bundle_dir="${archive%.tar.gz}"
mkdir "$bundle_dir"
tar -xzf "$archive" -C "$bundle_dir"
cd "$bundle_dir"

# Print the version without starting services or connecting the computer.
./ferrun --version
```

macOS:

```sh
# Replace the filename with your download and check it before extracting.
archive='PASTE_DOWNLOADED_ARCHIVE_NAME.tar.gz'
shasum -a 256 -c "$archive.sha256"

# Use a new directory so files from different releases cannot mix.
bundle_dir="${archive%.tar.gz}"
mkdir "$bundle_dir"
tar -xzf "$archive" -C "$bundle_dir"
cd "$bundle_dir"

# Print the version without starting services or connecting the computer.
./ferrun --version
```

Windows, in PowerShell:

```powershell
# Replace the filename with your download and check it before extracting.
$archive = 'PASTE_DOWNLOADED_ARCHIVE_NAME.zip'
$expected = ((Get-Content "$archive.sha256" -Raw).Trim() -split '\s+')[0]
if ((Get-FileHash $archive -Algorithm SHA256).Hash -ne $expected) {
    throw 'Archive checksum does not match'
}

# Use a new directory so files from different releases cannot mix.
$bundleDir = [IO.Path]::GetFileNameWithoutExtension($archive)
if (Test-Path $bundleDir) {
    throw 'Choose an empty destination for this bundle'
}
Expand-Archive -Path $archive -DestinationPath $bundleDir
Set-Location $bundleDir

# Print the version without starting services or connecting the computer.
.\ferrun.exe --version
```

If your computer blocks a downloaded program, ask your administrator to approve it through your company's usual process. Check the release's signing or notarization information. Publishing a download does not establish that it is signed. Keep endpoint protection enabled.

## Choose the role

| You are setting up…                   | Tools needed                                                                                            | Continue with…                                            |
| ------------------------------------- | ------------------------------------------------------------------------------------------------------- | --------------------------------------------------------- |
| A company control-plane server        | PostgreSQL, or Docker for managed PostgreSQL; HTTPS for remote machines; App key when connecting GitHub | [Company server](company-setup.md#prepare-the-controller) |
| An employee executor                  | Tools required by the workflows; controller URL, pool ID, and enrollment credential                     | [Connect a machine](company-setup.md#connect-a-machine)   |
| Both services for your own repository | Git, Node 24, PostgreSQL or Docker, plus your own authorized App or GitHub CLI login                    | Personal setup below                                      |

Use your organization's normal tool installation process for the shell and
JavaScript runtimes needed to start workflow steps. Set `EXECUTOR_NODE24` to the
Node 24 executable if `node` on PATH has a different major version. Workflows
declaring Node 20 actions need a separate Node 20 runtime through
`EXECUTOR_NODE20`. Windows defaults to PowerShell; explicit Bash steps need Bash.
Workflows can prepare additional build tools through setup actions and commands,
subject to the execution account's permissions.

Enroll and run the worker under the intended account with persistent private
state. Follow [worker supervision](company-setup.md#start-a-worker-under-a-supervisor)
to keep it running on your host. Systemd is one optional Linux integration;
`ferrun run` is the common foreground entry point on every supported platform.

## Personal setup

Use a repository you administer in your own account or organization. Your own Ferrun server needs its own GitHub credentials; a company enrollment token does not provide repository access.

For setup without an interactive login, follow [GitHub App setup](github-app-setup.md) for your account or organization, then run:

```sh
# Save the repository and App credentials used by your Ferrun server.
./ferrun setup --repo YOUR_OWNER/YOUR_REPO --app-id YOUR_APP_ID --app-key /private/path/ferrun.pem

# Start the server and local executor with the saved settings.
./ferrun run
```

Use `.\ferrun.exe` in PowerShell and a Windows key path. Local mode is the default; `--mode server` is for a control plane whose executors run elsewhere.

An optional interactive alternative uses the GitHub CLI installed and authenticated on your own machine:

```sh
# Log in on this computer with an account that can manage the repository's runners.
gh auth login
./ferrun setup --repo YOUR_OWNER/YOUR_REPO

# Start the server and local executor using the saved GitHub login.
./ferrun run
```

This personal alternative requires a login permitted to administer that repository's self-hosted runners. The company employee flow does not use it. Keep the computer awake and connected; use the printed `runs-on` label in the [first workflow check](company-setup.md#verify-a-workflow).

By default, local/server setup creates its own Docker PostgreSQL container. To use your own dedicated database, supply `DATABASE_URL` in the setup process's environment first. Setup saves that choice privately for subsequent runs. Use `--state-dir` for another independent installation; default locations and restart behavior are in [Private state](company-setup.md#keep-restart-state).
